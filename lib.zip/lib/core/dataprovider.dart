//
// import 'package:admin/config/environment.dart';
// import 'package:admin/config/network/realtime_manager.dart';
// import 'package:admin/core/data/appwrite/brands_repository.dart';
// import 'package:admin/core/data/appwrite/coupon_code_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/orders_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/products_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/sub_category_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/variant_types_repository.dart';
// import 'package:admin/core/data/appwrite/variants_repository.dart';
//
// import 'package:admin/utility/User_helper.dart';
// import 'package:admin/utility/snack_bar_helper.dart';
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/foundation.dart' hide Category;
//
//
// import '../../../models/category.dart';
// import '../../models/brand.dart';
// import '../../models/coupon.dart';
//
// import '../../models/order.dart';
// import '../../models/poster.dart';
// import '../../models/product.dart';
// import '../../models/sub_category.dart';
// import '../../models/variant.dart';
// import '../../models/variant_type.dart';
//
// import '../../utility/constants.dart';
// import 'dart:async';
//
//
// import 'appwrite/categories_repository.dart';
// import 'appwrite/poster_appwrite_service.dart';
//
//
//
//
//
// class DataProvider extends ChangeNotifier {
// // ================================================
// // Realtime برای سفارشات پرداخت شده
// // ================================================
//
//   StreamSubscription<RealtimeEvent<Order>>? _paidOrdersRealtimeSub;
//   final List<Order> _paidOrdersRealtime = []; // لیست جدا برای realtime (اختیاری)
//
//   Future<void> _subscribeToPaidOrdersRealtime() async {
//     await _paidOrdersRealtimeSub?.cancel();
//     _paidOrdersRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders, // همون کالکشن orders
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     // از همون stream سفارشات استفاده می‌کنیم (چون همه سفارشات در یک کالکشن هستن)
//     final stream = RealtimeManager.instance.subscribeCollection<Order>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//       fromJson: _orderFromRealtime,
//     );
//
//     _paidOrdersRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Order>(
//         event,
//         idOf: (o) => (o.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       final order = event.data;
//       if (order == null) return;
//
//       // فقط سفارشات این tenant
//       if ((order.phoneNumberCode ?? '').trim() != phoneCode) return;
//
//       // فقط اگر Paid باشه
//       if (!_isPaidStatus(order.orderStatus)) return;
//
//       if (_isDeleteEvent(event)) {
//         _paidOrders.removeWhere((o) => (o.sId ?? '').trim() == docId);
//       } else {
//         final idx = _paidOrders.indexWhere((o) => (o.sId ?? '').trim() == docId);
//         if (idx == -1) {
//           _paidOrders.insert(0, order); // جدید → اول لیست
//         } else {
//           _paidOrders[idx] = order; // آپدیت
//         }
//       }
//
//       // مرتب‌سازی جدیدترین اول
//       _paidOrders.sort((a, b) {
//         final aTime = a.updatedAt ?? a.createdAt ?? DateTime(0);
//         final bTime = b.updatedAt ?? b.createdAt ?? DateTime(0);
//         return bTime.compareTo(aTime);
//       });
//
//       _filteredPaidOrders = List.unmodifiable(_paidOrders);
//       _safeNotify();
//     });
//   }
//
//   bool _initialized = false;
//
//   // ================================================
//   // سفارشات در جریان (غیر Paid) — realtime کامل و robust
//   // ================================================
//   final List<Order> _inProgressOrders = [];
//   List<Order> get inProgressOrders => List.unmodifiable(_inProgressOrders);
//
//   StreamSubscription<RealtimeEvent<Order>>? _inProgressRealtimeSub;
//
//   // ================================================
//   // Realtime برای همه بخش‌ها
//   // ================================================
//   StreamSubscription<RealtimeEvent<Product>>? _productsRealtimeSub;
//   StreamSubscription<RealtimeEvent<Brand>>? _brandsRealtimeSub;
//   StreamSubscription<RealtimeEvent<Coupon>>? _couponsRealtimeSub;
//   StreamSubscription<RealtimeEvent<Poster>>? _postersRealtimeSub;
//   StreamSubscription<RealtimeEvent<Variant>>? _variantsRealtimeSub;
//   StreamSubscription<RealtimeEvent<VariantType>>? _variantTypesRealtimeSub;
//   StreamSubscription<RealtimeEvent<SubCategory>>? _subCategoriesRealtimeSub;
//   StreamSubscription<RealtimeEvent<Category>>? _categoriesRealtimeSub;
//
//   // ================================================
//   // Helperهای realtime — robust و نهایی
//   // ================================================
//
//   /// استخراج docId از events (fallback)
//   String? _extractDocIdFromEvents(List<String>? events) {
//     if (events == null || events.isEmpty) return null;
//     for (final e in events) {
//       final i = e.indexOf('.documents.');
//       if (i == -1) continue;
//       final tail = e.substring(i + '.documents.'.length);
//       final dot = tail.indexOf('.');
//       if (dot == -1) continue;
//       final id = tail.substring(0, dot).trim();
//       if (id.isNotEmpty) return id;
//     }
//     return null;
//   }
//
//   /// تشخیص delete (robust برای همه مدل‌ها)
//   bool _isDeleteEvent<T>(RealtimeEvent<T> event) {
//     return event.action == RealtimeAction.delete ||
//         event.events.any((e) => e.endsWith('.delete'));
//   }
//
//   /// docId نهایی با fallback سوم: از خود data.sId
//   String? _getDocumentIdGeneric<T>(
//       RealtimeEvent<T> event, {
//         required String Function(T data) idOf,
//       }) {
//     final direct = event.documentId?.trim();
//     if (direct != null && direct.isNotEmpty) return direct;
//
//     final fromEvents = _extractDocIdFromEvents(event.events);
//     if (fromEvents != null && fromEvents.isNotEmpty) return fromEvents;
//
//     final data = event.data;
//     if (data != null) {
//       final fallback = idOf(data).trim();
//       if (fallback.isNotEmpty) return fallback;
//     }
//
//     return null;
//   }
//
//   /// نرمالایز JSON realtime برای Order
//   Map<String, dynamic> _normalizeOrderRealtimeJson(Map<String, dynamic> json) {
//     final m = Map<String, dynamic>.from(json);
//     m['id'] ??= m[r'$id'];
//     m['sId'] ??= m['id'];
//     m['created'] ??= m[r'$createdAt'];
//     m['createdAt'] ??= m[r'$createdAt'];
//     m['updatedAt'] ??= m[r'$updatedAt'];
//     return m;
//   }
//
//   Order _orderFromRealtime(Map<String, dynamic> json) {
//     return Order.fromJson(_normalizeOrderRealtimeJson(json));
//   }
//
//   void _sortInProgressOrders() {
//     final epoch = DateTime.fromMillisecondsSinceEpoch(0);
//     _inProgressOrders.sort((a, b) {
//       final aTime = a.updatedAt ?? a.createdAt ?? epoch;
//       final bTime = b.updatedAt ?? b.createdAt ?? epoch;
//       return bTime.compareTo(aTime);
//     });
//   }
//
//   Future<void> getInProgressOrders({bool showSnack = false}) async {
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return;
//
//       final data = await ordersAppwriteService.fetchAllInProgress(
//         phoneNumberCode: phone.trim(),
//         batchSize: 200,
//       );
//
//       _inProgressOrders
//         ..clear()
//         ..addAll(data);
//
//       _sortInProgressOrders();
//       notifyListeners();
//     } catch (e) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('خطا در دریافت سفارشات در جریان');
//     }
//   }
//
//   // ================================================
//   // boot همه realtimeها
//   // ================================================
//   Future<void> _bootAllRealtime() async {
//     await _subscribeToInProgressRealtime();
//     await _subscribeToProductsRealtime();
//     await _subscribeToBrandsRealtime();
//     await _subscribeToCouponsRealtime();
//     await _subscribeToPostersRealtime();
//     await _subscribeToVariantsRealtime();
//     await _subscribeToVariantTypesRealtime();
//     await _subscribeToSubCategoriesRealtime();
//     await _subscribeToCategoriesRealtime();
//     await _subscribeToPaidOrdersRealtime();
//   }
//
//   // --- سفارشات در جریان ---
//   Future<void> _subscribeToInProgressRealtime() async {
//     await _inProgressRealtimeSub?.cancel();
//     _inProgressRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Order>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//       fromJson: _orderFromRealtime,
//     );
//
//     _inProgressRealtimeSub = stream.listen(
//           (event) {
//         final docId = _getDocumentIdGeneric<Order>(
//           event,
//           idOf: (o) => (o.sId ?? '').toString(),
//         );
//         if (docId == null || docId.isEmpty) return;
//
//         if (_isDeleteEvent(event)) {
//           _inProgressOrders.removeWhere((o) => (o.sId ?? '').trim() == docId);
//           _safeNotify();
//           return;
//         }
//
//         final order = event.data;
//         if (order == null) return;
//
//         if ((order.phoneNumberCode ?? '').trim() != phoneCode) return;
//
//         if (_isPaidStatus(order.orderStatus)) {
//           _inProgressOrders.removeWhere((o) => (o.sId ?? '').trim() == docId);
//           _safeNotify();
//           return;
//         }
//
//         final idx = _inProgressOrders.indexWhere((o) => (o.sId ?? '').trim() == docId);
//         if (idx == -1) {
//           _inProgressOrders.insert(0, order);
//         } else {
//           _inProgressOrders[idx] = order;
//         }
//
//         _sortInProgressOrders();
//         _safeNotify();
//       },
//       onError: (e, st) {
//         if (kDebugMode) debugPrint('Realtime error (orders): $e\n$st');
//       },
//       cancelOnError: false,
//     );
//   }
//
//   // --- محصولات ---
//   Future<void> _subscribeToProductsRealtime() async {
//     await _productsRealtimeSub?.cancel();
//     _productsRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdProducts,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Product>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdProducts,
//       fromJson: (json) => Product.fromJson(json),
//     );
//
//     _productsRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Product>(
//         event,
//         idOf: (p) => (p.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         removeProductById(docId);
//         return;
//       }
//
//       final product = event.data;
//       if (product == null) return;
//
//       if ((product.phoneNumberCode ?? '').trim() != phoneCode) return;
//
//       upsertProductToTop(product);
//     });
//   }
//
//   // --- برندها ---
//   Future<void> _subscribeToBrandsRealtime() async {
//     await _brandsRealtimeSub?.cancel();
//     _brandsRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdBrands,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Brand>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdBrands,
//       fromJson: (json) => Brand.fromJson(json),
//     );
//
//     _brandsRealtimeSub = stream.listen((event) async {
//       final docId = _getDocumentIdGeneric<Brand>(
//         event,
//         idOf: (b) => (b.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         removeBrandById(docId);
//         return;
//       }
//
//       final brand = event.data;
//       if (brand == null) return;
//
//       if ((brand.phoneNumberCode ?? '').trim() != phoneCode) return;
//
//       // hydrate نام ساب‌کتگوری برای realtime
//       await _ensureSubCategoriesLoadedForBrands();
//       await _ensureSubCategoryCacheForBrands(phoneCode, [brand]);
//       _hydrateBrandsWithSubCategoryNames([brand]);
//
//       upsertBrandToTop(brand);
//     });
//   }
//
//   // --- کوپن‌ها ---
//   Future<void> _subscribeToCouponsRealtime() async {
//     await _couponsRealtimeSub?.cancel();
//     _couponsRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCouponCode,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Coupon>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCouponCode,
//       fromJson: (json) => Coupon.fromJson(json),
//     );
//
//     _couponsRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Coupon>(
//         event,
//         idOf: (c) => (c.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allCoupons.removeWhere((c) => (c.sId ?? '').trim() == docId);
//         _applyCouponFilter();
//         _safeNotify();
//         return;
//       }
//
//       final coupon = event.data;
//       if (coupon == null) return;
//
//       if ((coupon.phoneNumberCode ?? '').trim() != phoneCode) return;
//
//       final idx = _allCoupons.indexWhere((c) => (c.sId ?? '').trim() == docId);
//       if (idx == -1) {
//         _allCoupons.insert(0, coupon);
//       } else {
//         _allCoupons[idx] = coupon;
//       }
//       _applyCouponFilter();
//       _safeNotify();
//     });
//   }
//
//   // --- پوسترها (بدون فیلتر phoneNumberCode — چون در مدل نداره) ---
//   Future<void> _subscribeToPostersRealtime() async {
//     await _postersRealtimeSub?.cancel();
//     _postersRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdPosters,
//     );
//
//     final stream = RealtimeManager.instance.subscribeCollection<Poster>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdPosters,
//       fromJson: (json) => Poster.fromJson(json),
//     );
//
//     _postersRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Poster>(
//         event,
//         idOf: (p) => (p.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allPosters.removeWhere((p) => (p.sId ?? '').trim() == docId);
//         _applyPosterFilter();
//         _safeNotify();
//         return;
//       }
//
//       final poster = event.data;
//       if (poster == null) return;
//
//       // بدون فیلتر tenant — Poster عمومی یا بدون tenant
//       upsertPosterToTop(poster);
//     });
//   }
//
//   // --- واریانت‌ها ---
//   Future<void> _subscribeToVariantsRealtime() async {
//     await _variantsRealtimeSub?.cancel();
//     _variantsRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariants,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     await _ensureVariantTypeMapForVariants(phoneCode);
//
//     final stream = RealtimeManager.instance.subscribeCollection<Variant>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariants,
//       fromJson: (json) => Variant.fromJson(json),
//     );
//
//     _variantsRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Variant>(
//         event,
//         idOf: (v) => (v.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allVariants.removeWhere((v) => (v.sId ?? '').trim() == docId);
//         _applyVariantFilter();
//         _safeNotify();
//         return;
//       }
//
//       final variant = event.data;
//       if (variant == null) return;
//
//       if ((variant.phoneNumberCode ?? '').trim() != phoneCode) return;
//
//       final idx = _allVariants.indexWhere((v) => (v.sId ?? '').trim() == docId);
//       if (idx == -1) {
//         _allVariants.insert(0, variant);
//       } else {
//         _allVariants[idx] = variant;
//       }
//
//       _hydrateVariantsTypeNames([variant]);
//       _applyVariantFilter();
//       _safeNotify();
//     });
//   }
//
//   // --- Variant Types ---
//   Future<void> _subscribeToVariantTypesRealtime() async {
//     await _variantTypesRealtimeSub?.cancel();
//     _variantTypesRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariantTypes,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<VariantType>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariantTypes,
//       fromJson: (json) => VariantType.fromJson(json),
//     );
//
//     _variantTypesRealtimeSub = stream.listen((event) async {
//       final docId = _getDocumentIdGeneric<VariantType>(
//         event,
//         idOf: (vt) => (vt.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allVariantTypes.removeWhere((vt) => (vt.sId ?? '').trim() == docId);
//         _applyVariantTypeFilter();
//
//         await _ensureVariantTypeMapForVariants(phoneCode);
//         _hydrateVariantsTypeNames(_allVariants);
//         _applyVariantFilter();
//
//         _safeNotify();
//         return;
//       }
//
//       final vt = event.data;
//       if (vt == null) return;
//
//       if ((vt.phoneNumberCode ?? '').trim() != phoneCode) return;
//
//       upsertVariantTypeToTop(vt);
//
//       await _ensureVariantTypeMapForVariants(phoneCode);
//       _hydrateVariantsTypeNames(_allVariants);
//       _applyVariantFilter();
//       _safeNotify();
//     });
//   }
//
//   // --- ساب‌کتگوری‌ها ---
//   Future<void> _subscribeToSubCategoriesRealtime() async {
//     await _subCategoriesRealtimeSub?.cancel();
//     _subCategoriesRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdSubcategories,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<SubCategory>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdSubcategories,
//       fromJson: (json) => SubCategory.fromJson(json),
//     );
//
//     _subCategoriesRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<SubCategory>(
//         event,
//         idOf: (sc) => (sc.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allSubCategories.removeWhere((sc) => (sc.sId ?? '').trim() == docId);
//         _applySubCategoryFilter();
//         _safeNotify();
//         return;
//       }
//
//       final sub = event.data;
//       if (sub == null) return;
//
//       if ((sub.phoneNumberCode ?? '').trim() != phoneCode) return;
//
//       upsertSubCategoryToTop(sub);
//     });
//   }
//
//   // --- کتگوری‌ها ---
//   Future<void> _subscribeToCategoriesRealtime() async {
//     await _categoriesRealtimeSub?.cancel();
//     _categoriesRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCategories,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Category>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCategories,
//       fromJson: (json) => Category.fromJson(json),
//     );
//
//     _categoriesRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Category>(
//         event,
//         idOf: (c) => (c.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allCategories.removeWhere((c) => (c.sId ?? '').trim() == docId);
//         _applyCategoryFilter();
//         _safeNotify();
//         return;
//       }
//
//       final cat = event.data;
//       if (cat == null) return;
//
//       if ((cat.phoneNumberCode ?? '').trim() != phoneCode) return;
//
//       final idx = _allCategories.indexWhere((c) => (c.sId ?? '').trim() == docId);
//       if (idx == -1) {
//         _allCategories.insert(0, cat);
//       } else {
//         _allCategories[idx] = cat;
//       }
//       _applyCategoryFilter();
//       _safeNotify();
//     });
//   }
//
//   // ================================================
//   // initAll
//   // ================================================
//   Future<void> initAll() async {
//     if (_initialized) return;
//     _initialized = true;
//
//     await Future.wait([
//       getAllProducts(),
//       getAllCategories(),
//       getAllSubCategories(),
//       getAllBrands(),
//       getAllVariantTypes(),
//       getAllVariants(),
//       getAllPosters(),
//       getAllCoupons(),
//     ]);
//
//     final bool isFullMenu = await _isFullMenu();
//
//     if (isFullMenu) {
//       await _bootOrders();
//       await _bootAllRealtime();
//     } else {
//       _inProgressOrders.clear();
//       _paidOrders.clear();
//       _filteredPaidOrders = const [];
//       _allCoupons.clear();
//       _filteredCoupons = const [];
//
//       await _inProgressRealtimeSub?.cancel();
//       _inProgressRealtimeSub = null;
//
//       RealtimeManager.instance.unsubscribeCollection(
//         databaseId: Environment.databaseIdMenuMita,
//         collectionId: Environment.collectionIdOrders,
//       );
//
//       notifyListeners();
//     }
//   }
//
//   Future<void> _bootOrders() async {
//     await getInProgressOrders(showSnack: false);
//     await loadInitialPaidOrders(showSnack: false);
//     await getAllCoupons(showSnack: false);
//   }
//
//   // ================================================
//   // dispose و logout
//   // ================================================
//   Timer? _notifyDebounce;
//
//   void _safeNotify() {
//     _notifyDebounce?.cancel();
//     _notifyDebounce = Timer(const Duration(milliseconds: 120), notifyListeners);
//   }
//
//   @override
//   void dispose() {
//     _inProgressRealtimeSub?.cancel();
//     _productsRealtimeSub?.cancel();
//     _brandsRealtimeSub?.cancel();
//     _couponsRealtimeSub?.cancel();
//     _postersRealtimeSub?.cancel();
//     _variantsRealtimeSub?.cancel();
//     _variantTypesRealtimeSub?.cancel();
//     _subCategoriesRealtimeSub?.cancel();
//     _categoriesRealtimeSub?.cancel();
//     _paidOrdersRealtimeSub?.cancel();
//     _notifyDebounce?.cancel();
//     super.dispose();
//   }
//
//   Future<void> logoutCleanup() async {
//     _inProgressRealtimeSub?.cancel();
//     _productsRealtimeSub?.cancel();
//     _brandsRealtimeSub?.cancel();
//     _couponsRealtimeSub?.cancel();
//     _postersRealtimeSub?.cancel();
//     _variantsRealtimeSub?.cancel();
//     _variantTypesRealtimeSub?.cancel();
//     _subCategoriesRealtimeSub?.cancel();
//     _categoriesRealtimeSub?.cancel();
//     _paidOrdersRealtimeSub?.cancel();
//     _notifyDebounce?.cancel();
//     _notifyDebounce = null;
//
//     _initialized = false;
//
//     _inProgressOrders.clear();
//     _paidOrders.clear();
//     _filteredPaidOrders = const [];
//     _allCoupons.clear();
//     _filteredCoupons = const [];
//     _allProducts.clear();
//     _filteredProducts = const [];
//     _allBrands.clear();
//     _filteredBrands = const [];
//     _allCategories.clear();
//     _filteredCategories = const [];
//     _allSubCategories.clear();
//     _filteredSubCategories = const [];
//     _allVariantTypes.clear();
//     _filteredVariantTypes = const [];
//     _allVariants.clear();
//     _filteredVariants = const [];
//     _allPosters.clear();
//     _filteredPosters = const [];
//
//     notifyListeners();
//   }
//
//   bool _isPaidStatus(String? s) => (s ?? '').trim().toLowerCase() == 'paid';
//
//
//   /// استخراج امن ID از Order
//   String _orderIdOf(Order o) => (o.sId ?? '').toString().trim();
//
//   // ================================================
// // سفارشات در جریان (غیر Paid) — realtime کامل و robust
// // ================================================
// //   final List<Order> _inProgressOrders = [];
// //   List<Order> get inProgressOrders => List.unmodifiable(_inProgressOrders);
// //
// //   StreamSubscription<RealtimeEvent<Order>>? _inProgressRealtimeSub;
// //
// //   /// استخراج امن ID از Order
// //   String _orderIdOf(Order o) => (o.sId ?? '').toString().trim();
// //
// //   /// استخراج docId از events (fallback)
// //   String? _extractDocIdFromEvents(List<String>? events) {
// //     if (events == null || events.isEmpty) return null;
// //
// //     for (final e in events) {
// //       final i = e.indexOf('.documents.');
// //       if (i == -1) continue;
// //
// //       final tail = e.substring(i + '.documents.'.length);
// //       final dot = tail.indexOf('.');
// //       if (dot == -1) continue;
// //
// //       final id = tail.substring(0, dot).trim();
// //       if (id.isNotEmpty) return id;
// //     }
// //     return null;
// //   }
//
//   /// docId نهایی با حداکثر fallback
//   String? _getDocumentId(RealtimeEvent<Order> event) {
//     final direct = event.documentId?.toString().trim();
//     if (direct != null && direct.isNotEmpty) return direct;
//
//     final fromEvents = _extractDocIdFromEvents(event.events);
//     if (fromEvents != null && fromEvents.isNotEmpty) return fromEvents;
//
//     final order = event.data;
//     if (order != null) {
//       final oid = _orderIdOf(order);
//       if (oid.isNotEmpty) return oid;
//     }
//     return null;
//   }
// //
// //   /// نرمالایز JSON realtime برای سازگاری با Order.fromJson
// //   Map<String, dynamic> _normalizeOrderRealtimeJson(Map<String, dynamic> json) {
// //     final m = Map<String, dynamic>.from(json);
// //
// //     m['id'] ??= m[r'$id'];
// //     m['sId'] ??= m['id']; // ✅ سازگاری بیشتر
// //
// //     m['created'] ??= m[r'$createdAt'];
// //     m['createdAt'] ??= m[r'$createdAt'];
// //     m['updatedAt'] ??= m[r'$updatedAt'];
// //
// //     return m;
// //   }
// //
// //   /// تبدیل JSON realtime به Order
// //   Order _orderFromRealtime(Map<String, dynamic> json) {
// //     return Order.fromJson(_normalizeOrderRealtimeJson(json));
// //   }
// //
// //   /// مرتب‌سازی: جدیدترین آپدیت اول (safe)
// //   void _sortInProgressOrders() {
// //     final epoch = DateTime.fromMillisecondsSinceEpoch(0);
// //     _inProgressOrders.sort((a, b) {
// //       final aTime = a.updatedAt ?? a.createdAt ?? epoch;
// //       final bTime = b.updatedAt ?? b.createdAt ?? epoch;
// //       return bTime.compareTo(aTime);
// //     });
// //   }
// //
// //   /// دریافت اولیه سفارشات در جریان
// //   Future<void> getInProgressOrders({bool showSnack = false}) async {
// //     try {
// //       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
// //       if (phone.trim().isEmpty) return;
// //
// //       final data = await ordersAppwriteService.fetchAllInProgress(
// //         phoneNumberCode: phone.trim(),
// //         batchSize: 200,
// //       );
// //
// //       _inProgressOrders
// //         ..clear()
// //         ..addAll(data);
// //
// //       _sortInProgressOrders();
// //       notifyListeners();
// //     } catch (e) {
// //       if (showSnack) {
// //         SnackBarHelper.showErrorSnackBar('خطا در دریافت سفارشات در جریان');
// //       }
// //     }
// //   }
// //
// //   /// realtime برای سفارشات در جریان — robust (بدون dynamic)
// //   Future<void> _subscribeToInProgressRealtime() async {
// //     // cancel قبلی
// //     await _inProgressRealtimeSub?.cancel();
// //     _inProgressRealtimeSub = null;
// //
// //     // unsubscribe از manager (جلوگیری از نشت)
// //     RealtimeManager.instance.unsubscribeCollection(
// //       databaseId: Environment.databaseIdMenuMita,
// //       collectionId: Environment.collectionIdOrders,
// //     );
// //
// //     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
// //     final phoneCode = phone.trim();
// //     if (phoneCode.isEmpty) return;
// //
// //     final stream = RealtimeManager.instance.subscribeCollection<Order>(
// //       databaseId: Environment.databaseIdMenuMita,
// //       collectionId: Environment.collectionIdOrders,
// //       fromJson: _orderFromRealtime,
// //     );
// //
// //     _inProgressRealtimeSub = stream.listen(
// //           (event) {
// //         final docId = _getDocumentId(event);
// //         if (docId == null || docId.isEmpty) return;
// //
// //         final bool isDelete = event.action == RealtimeAction.delete ||
// //             event.events.any((e) => e.endsWith('.delete'));
// //
// //         // DELETE
// //         if (isDelete) {
// //           _inProgressOrders.removeWhere((o) => _orderIdOf(o) == docId);
// //           _safeNotify();
// //           return;
// //         }
// //
// //         final order = event.data;
// //         if (order == null) return;
// //
// //         // فیلتر tenant
// //         if ((order.phoneNumberCode ?? '').toString().trim() != phoneCode) return;
// //
// //         // اگر Paid شد → حذف از لیست در جریان
// //         if (_isPaidStatus(order.orderStatus)) {
// //           _inProgressOrders.removeWhere((o) => _orderIdOf(o) == docId);
// //           _safeNotify();
// //           return;
// //         }
// //
// //         // CREATE/UPDATE → upsert
// //         final idx = _inProgressOrders.indexWhere((o) => _orderIdOf(o) == docId);
// //         if (idx == -1) {
// //           _inProgressOrders.insert(0, order);
// //         } else {
// //           _inProgressOrders[idx] = order;
// //         }
// //
// //         _sortInProgressOrders();
// //         _safeNotify();
// //       },
// //       onError: (Object e, StackTrace st) {
// //         if (kDebugMode) {
// //           debugPrint('Realtime error (in-progress orders): $e\n$st');
// //         }
// //       },
// //       cancelOnError: false,
// //     );
// //   }
// //
// //
// // // ================================================
// // // dispose و logout (کاملاً امن)
// // // ================================================
// //   @override
// //   void dispose() {
// //     _inProgressRealtimeSub?.cancel();
// //     _inProgressRealtimeSub = null;
// //
// //     RealtimeManager.instance.unsubscribeCollection(
// //       databaseId: Environment.databaseIdMenuMita,
// //       collectionId: Environment.collectionIdOrders,
// //     );
// //
// //     _notifyDebounce?.cancel();
// //     super.dispose();
// //   }
// //
// //   Future<void> logoutCleanup() async {
// //     _inProgressRealtimeSub?.cancel();
// //     _inProgressRealtimeSub = null;
// //
// //     RealtimeManager.instance.unsubscribeCollection(
// //       databaseId: Environment.databaseIdMenuMita,
// //       collectionId: Environment.collectionIdOrders,
// //     );
// //
// //     _notifyDebounce?.cancel();
// //     _notifyDebounce = null;
// //
// //     _initialized = false;
// //
// //     _inProgressOrders.clear();
// //     _paidOrders.clear();
// //     _filteredPaidOrders = const [];
// //     _allCoupons.clear();
// //     _filteredCoupons = const [];
// //
// //     // ... بقیه پاکسازی‌ها مثل قبل
// //
// //     notifyListeners();
// //   }
// //
// //   /// استخراج امن events از RealtimeEvent
// //   List<String> _getEvents(RealtimeEvent<Order> event) {
// //     return event.events;
// //   }
// //
// //
// //   bool _initialized = false;
// //
// //
//
//
//   // ================================================
//   // سفارشات پرداخت شده — pagination ۱۷ تایی
//   // ================================================
//   static const int _paidOrdersPageSize = 17;
//
//   final List<Order> _paidOrders = [];
//   List<Order> _filteredPaidOrders = [];
//   List<Order> get paidOrders => _filteredPaidOrders;
//
//   bool _paidOrdersLoading = false;
//   bool _paidOrdersHasMore = true;
//
//   bool get isPaidOrdersLoading => _paidOrdersLoading;
//   bool get hasMorePaidOrders => _paidOrdersHasMore;
//
//   Future<void> loadInitialPaidOrders({bool showSnack = false}) async {
//     _paidOrders.clear();
//     _filteredPaidOrders = const [];
//     _paidOrdersHasMore = true;
//     _paidOrdersLoading = true;
//     notifyListeners();
//
//     await _loadPaidOrdersPage(1, showSnack: showSnack);
//   }
//
//   Future<void> loadMorePaidOrders() async {
//     if (_paidOrdersLoading || !_paidOrdersHasMore) return;
//     await _loadPaidOrdersPage(_paidOrders.length ~/ _paidOrdersPageSize + 1);
//   }
//
//   Future<void> _loadPaidOrdersPage(int page, {bool showSnack = false}) async {
//     _paidOrdersLoading = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return;
//
//       final res = await ordersAppwriteService.fetchPaidPaged(
//         phoneNumberCode: phone.trim(),
//         page: page,
//         perPage: _paidOrdersPageSize,
//       );
//
//       if (page == 1) _paidOrders.clear();
//       _paidOrders.addAll(res.orders);
//
//       _paidOrders.sort((a, b) {
//         final aTime = a.updatedAt ?? a.createdAt ?? DateTime(0);
//         final bTime = b.updatedAt ?? b.createdAt ?? DateTime(0);
//         return bTime.compareTo(aTime);
//       });
//
//       _filteredPaidOrders = List.unmodifiable(_paidOrders);
//       _paidOrdersHasMore = res.hasMore;
//     } catch (e) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('خطا در دریافت سفارشات پرداخت شده');
//     } finally {
//       _paidOrdersLoading = false;
//       notifyListeners();
//     }
//   }
//
//   // ================================================
//   // چک menu_type
//   // ================================================
//   Future<bool> _isFullMenu() async {
//     try {
//       final info = await UserSaveHelper.getUserInfo(showError: false);
//       final menuType = (info?['menu_type'] ?? '').toString().trim().toLowerCase();
//       return menuType != 'menu_one';
//     } catch (_) {
//       return true;
//     }
//   }
//
//   // ================================================
//   // boot و init
//   // ================================================
//
//   DataProvider() {
//     _maybeInitOnStartup();
//   }
//
//   Future<void> _maybeInitOnStartup() async {
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false);
//     if (phone == null || phone.isEmpty) return;
//     await initAll();
//   }
//
//   Future<void> initAfterLogin() async {
//     await initAll();
//   }
// // ================================================
// // boot و init (فقط بخش مهم orders)
// // ================================================
// //   Future<void> initAll() async {
// //     if (_initialized) return;
// //     _initialized = true;
// //
// //     await Future.wait([
// //       getAllProducts(),
// //       getAllCategories(),
// //       getAllSubCategories(),
// //       getAllBrands(),
// //       getAllVariantTypes(),
// //       getAllVariants(),
// //       getAllPosters(),
// //     ]);
// //
// //     final bool isFullMenu = await _isFullMenu();
// //
// //     if (isFullMenu) {
// //       await _bootOrders();
// //     } else {
// //       _inProgressOrders.clear();
// //       _paidOrders.clear();
// //       _filteredPaidOrders = const [];
// //       _allCoupons.clear();
// //       _filteredCoupons = const [];
// //
// //       await _inProgressRealtimeSub?.cancel();
// //       _inProgressRealtimeSub = null;
// //
// //       RealtimeManager.instance.unsubscribeCollection(
// //         databaseId: Environment.databaseIdMenuMita,
// //         collectionId: Environment.collectionIdOrders,
// //       );
// //
// //       notifyListeners();
// //     }
// //   }
// //
// //   Future<void> _bootOrders() async {
// //     await getInProgressOrders(showSnack: false);
// //     await loadInitialPaidOrders(showSnack: false);
// //     await getAllCoupons(showSnack: false);
// //     await _subscribeToInProgressRealtime();
// //   }
// //
// //   // ================================================
// //   // dispose و logout (کاملاً امن)
// //   // ================================================
// //   Timer? _notifyDebounce;
// //
// //   void _safeNotify() {
// //     _notifyDebounce?.cancel();
// //     _notifyDebounce = Timer(const Duration(milliseconds: 120), notifyListeners);
// //   }
//
//
//
//   // ================================================
//   // شورت‌کات‌ها برای سازگاری با UI قدیمی
//   // ================================================
//   List<Order> get allsOrders => inProgressOrders;
//   List<Order> get orders => paidOrders;
//
//   bool get isOrdersLoading => isPaidOrdersLoading;
//   bool get hasMoreOrders => hasMorePaidOrders;
//
//   Future<void> getAllsOrders({bool showSnack = false}) async {
//     await getInProgressOrders(showSnack: showSnack);
//   }
//
//   Future<void> loadInitialOrders({bool showSnack = false}) async {
//     await loadInitialPaidOrders(showSnack: showSnack);
//   }
//
//   Future<void> loadMoreOrders() async {
//     await loadMorePaidOrders();
//   }
//
//   int calculateOrdersWithStatus({String? status}) {
//     if (status == null) return inProgressOrders.length;
//     return inProgressOrders.where((o) => o.orderStatus == status).length;
//   }
//
//   void filterAllOrders(String status) => notifyListeners();
//   void searchAllOrders(String query) => notifyListeners();
//   void searchOrders(String query) => notifyListeners();
//
//   final OrdersAppwriteService ordersAppwriteService = OrdersAppwriteService();
//
//
//
//
//
//
//   //////////////////////////////////////////////////ORDERS//////////////////////////////////////////////////
//
//
//
//   //////////////////////////////////////////////////ORDERS//////////////////////////////////////////////////
//
//   final CategoriesRepository categoriesRepoAppwrite = CategoriesRepository();
//
//   final BrandsRepository brandsRepoAppwrite = BrandsRepository();
//
//
//   final SubCategoryAppwriteService _subCategoryService = SubCategoryAppwriteService();
//
//
//   final VariantTypesRepository variantTypesRepoAppwrite = VariantTypesRepository();
//
//
//   final VariantsRepository variantsRepoAppwrite = VariantsRepository();
//
//   final ProductsAppwriteService _productsService = ProductsAppwriteService();
//
//   final PosterAppwriteService _posterService = PosterAppwriteService();
//
//
//   final CouponCodeAppwriteService _couponService = CouponCodeAppwriteService();
//
//
//   List<Category> _allCategories = [];
//   List<Category> _filteredCategories = [];
//
//   List<Category> get categories => _filteredCategories;
//
//   List<SubCategory> _allSubCategories = [];
//   List<SubCategory> _filteredSubCategories = [];
//
//   List<SubCategory> get subCategories => _filteredSubCategories;
//
//   List<Brand> _allBrands = [];
//   List<Brand> _filteredBrands = [];
//
//   List<Brand> get brands => _filteredBrands;
//
//   List<VariantType> _allVariantTypes = [];
//   List<VariantType> _filteredVariantTypes = [];
//
//   List<VariantType> get variantTypes => _filteredVariantTypes;
//
//   List<Variant> _allVariants = [];
//   List<Variant> _filteredVariants = [];
//
//   List<Variant> get variants => _filteredVariants;
//
//   List<Product> _allProducts = [];
//   List<Product> _filteredProducts = [];
//
//   List<Product> get products => _filteredProducts;
//
//   String _filteredProductsType = ALL_PRODUCTS;
//
//   String get productsType => _filteredProductsType;
//
//   List<Coupon> _allCoupons = [];
//   List<Coupon> _filteredCoupons = [];
//
//   List<Coupon> get coupons => _filteredCoupons;
//
//   List<Poster> _allPosters = [];
//   List<Poster> _filteredPosters = [];
//
//   List<Poster> get posters => _filteredPosters;
//
//
//
//
//
//
//
//
//
//
// //////////////////////////////////////////////////Product//////////////////////////////////////////////////
//   static const int _productsPageSize = 3;
//
//   bool _productsLoading = false;
//   bool _productsLoadingMore = false;
//   bool _productsHasMore = true;
//
//   String? _productsCursorAfter;
//   String _productKeyword = '';
//
//   bool get isProductsLoading => _productsLoading;
//   bool get isProductsLoadingMore => _productsLoadingMore;
//   bool get hasMoreProducts => _productsHasMore;
//
// // --- sort helper: newest updatedAt/createdAt first ---
//   DateTime _productTs(Product p) {
//     final u = (p.updatedAt ?? '').trim();
//     final c = (p.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllProducts() {
//     _allProducts.sort((a, b) => _productTs(b).compareTo(_productTs(a))); // DESC
//   }
//
//
//   void filterProductsByQuantity(String productQntType, {bool showSnack = false}) {
//     _filteredProductsType = productQntType.isEmpty ? ALL_PRODUCTS : productQntType;
//
//     if (_filteredProductsType == ALL_PRODUCTS) {
//       _filteredProducts = List<Product>.from(_allProducts);
//
//     } else if (_filteredProductsType == STOCK_OUT_PRODUCTS) {
//       _filteredProducts = _allProducts.where((p) => (_qtyOf(p) ?? -1) == 0).toList();
//
//     } else if (_filteredProductsType == LIMITED_STOCK_PRODUCTS) {
//       _filteredProducts = _allProducts.where((p) => (_qtyOf(p) ?? -1) == 1).toList();
//
//     } else if (_filteredProductsType == OTHER_PRODUCTS) {
//       _filteredProducts = _allProducts.where((p) {
//         final q = _qtyOf(p);
//         return q == null || (q != 0 && q != 1); // null هم میره تو سایر
//       }).toList();
//
//     } else {
//       _filteredProducts = List<Product>.from(_allProducts);
//     }
//
//     if (showSnack) {
//       SnackBarHelper.showSuccessSnackBar('${_filteredProductsType} retrieved successfully!');
//     }
//
//     notifyListeners();
//   }
//
//   int calculateProductWithQuantity({int? quantity}) {
//     if (quantity == null) return _allProducts.length;
//
//     int total = 0;
//     for (final p in _allProducts) {
//       final q = _qtyOf(p);
//       if (q == quantity) total++;
//     }
//     return total;
//   }
//   int? _tryInt(dynamic v) {
//     if (v == null) return null;
//     if (v is int) return v;
//     final s = v.toString().trim();
//     if (s.isEmpty) return null;
//     return int.tryParse(s);
//   }
//
//   int? _qtyOf(Product p) => _tryInt(p.quantity);
//
//   /// ✅ create/update => بیاد اول (بدون reload)
//   void upsertProductToTop(Product incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allProducts.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allProducts.removeAt(idx);
//
//     _allProducts.insert(0, incoming);
//
//     _hydrateProductsNames([incoming]); // مهم: category/subcategory
//     _applyProductFilter();
//     notifyListeners();
//   }
//
//   /// ✅ حذف محصول از لیست بعد از delete
//   void removeProductById(String id) {
//     final sid = id.trim();
//     if (sid.isEmpty) return;
//     _allProducts.removeWhere((p) => (p.sId ?? '').trim() == sid);
//     _applyProductFilter();
//     notifyListeners();
//   }
//
//   Future<List<Product>> getAllProducts({bool showSnack = false}) async {
//     return loadInitialProducts(showSnack: showSnack);
//   }
//
//   Future<List<Product>> loadInitialProducts({bool showSnack = false}) async {
//     if (_productsLoading) return _filteredProducts;
//
//     _productsLoading = true;
//     _productsLoadingMore = false;
//     _productsHasMore = true;
//     _productsCursorAfter = null;
//
//     _allProducts.clear();
//     _filteredProducts = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         return _filteredProducts;
//       }
//
//       // ✅ برای hydrate نام‌ها
//       await _ensureCategoriesLoadedForProducts();
//       await _ensureSubCategoriesLoadedForProducts();
//
//       final res = await _productsService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _productsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _hydrateProductsNames(items);
//         _allProducts.addAll(items);
//
//         _productsHasMore = items.length >= _productsPageSize;
//         _productsCursorAfter = _productsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyProductFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Products loaded');
//         return _filteredProducts;
//       } else {
//         if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredProducts;
//       }
//     } finally {
//       _productsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Product>> loadMoreProducts({bool showSnack = false}) async {
//     if (_productsLoading || _productsLoadingMore || !_productsHasMore) return _filteredProducts;
//
//     _productsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredProducts;
//
//       await _ensureCategoriesLoadedForProducts();
//       await _ensureSubCategoriesLoadedForProducts();
//
//       final res = await _productsService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _productsPageSize,
//         cursorAfter: _productsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _productsHasMore = false;
//           return _filteredProducts;
//         }
//
//         _hydrateProductsNames(items);
//
//         // ✅ upsert جلوگیری از تکرار
//         for (final p in items) {
//           final id = (p.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allProducts.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allProducts.add(p);
//           } else {
//             _allProducts[idx] = p;
//           }
//         }
//
//         _productsHasMore = items.length >= _productsPageSize;
//         _productsCursorAfter = _productsHasMore ? items.last.sId : null;
//
//         _applyProductFilter();
//         return _filteredProducts;
//       } else {
//         if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredProducts;
//       }
//     } finally {
//       _productsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterProducts(String keyword) {
//     _productKeyword = keyword.trim();
//     _applyProductFilter();
//     notifyListeners();
//   }
//
//   void _applyProductFilter() {
//     _sortAllProducts();
//
//     final kw = _productKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredProducts = List<Product>.from(_allProducts);
//       return;
//     }
//
//     _filteredProducts = _allProducts.where((p) {
//       final name = (p.name ?? '').toLowerCase();
//       final cat = (p.resolvedCategoryName ?? '').toLowerCase();
//       final sub = (p.resolvedSubCategoryName ?? '').toLowerCase();
//       return name.contains(kw) || cat.contains(kw) || sub.contains(kw);
//     }).toList()
//       ..sort((a, b) => _productTs(b).compareTo(_productTs(a)));
//   }
//
// // -------- Hydration (Category/SubCategory names) --------
//
//   Future<void> _ensureCategoriesLoadedForProducts() async {
//     if (_allCategories.isEmpty) {
//       await getAllCategories(showSnack: false);
//     }
//   }
//
//   Future<void> _ensureSubCategoriesLoadedForProducts() async {
//     if (_allSubCategories.isEmpty) {
//       await getAllSubCategories(showSnack: false);
//     }
//   }
//
//   void _hydrateProductsNames(List<Product> products) {
//     if (products.isEmpty) return;
//
//     final catMap = <String, String>{};
//     for (final c in _allCategories) {
//       final id = (c.sId ?? '').trim();
//       if (id.isNotEmpty) catMap[id] = (c.name ?? '').trim();
//     }
//
//     final subMap = <String, String>{};
//     for (final s in _allSubCategories) {
//       final id = (s.sId ?? '').trim();
//       if (id.isNotEmpty) subMap[id] = (s.name ?? '').trim();
//     }
//
//     for (final p in products) {
//       final cid = (p.categoryId ?? '').trim();
//       final sid = (p.subCategoryId ?? '').trim();
//       p.resolvedCategoryName = catMap[cid] ?? '';
//       p.resolvedSubCategoryName = subMap[sid] ?? '';
//     }
//   }
// //////////////////////////////////////////////////Product//////////////////////////////////////////////////
// // ================================
// // ✅ COUPONS (Paging + Shimmer + Updated first)
// // ================================
//   //////////////////////////////////////////////////coupons//////////////////////////////////////////////////
//   static const int _couponsPageSize = 17;
//
//   bool _couponsLoading = false;
//   bool _couponsLoadingMore = false;
//   bool _couponsHasMore = true;
//
//   String? _couponsCursorAfter;
//   String _couponKeyword = '';
//
//   bool get isCouponsLoading => _couponsLoading;
//   bool get isCouponsLoadingMore => _couponsLoadingMore;
//   bool get hasMoreCoupons => _couponsHasMore;
//
//   DateTime _couponTs(Coupon c) {
//     final u = (c.updatedAt ?? '').trim();
//     final cr = (c.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : cr;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllCoupons() {
//     _allCoupons.sort((a, b) => _couponTs(b).compareTo(_couponTs(a)));
//   }
//
//   void _applyCouponFilter() {
//     _sortAllCoupons();
//
//     final kw = _couponKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredCoupons = List<Coupon>.from(_allCoupons);
//       return;
//     }
//
//     _filteredCoupons = _allCoupons
//         .where((c) => (c.couponCode ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _couponTs(b).compareTo(_couponTs(a)));
//   }
//
//   Future<List<Coupon>> getAllCoupons({bool showSnack = false}) async {
//     return loadInitialCoupons(showSnack: showSnack);
//   }
//
//   Future<List<Coupon>> loadInitialCoupons({bool showSnack = false}) async {
//     if (_couponsLoading) return _filteredCoupons;
//
//     _couponsLoading = true;
//     _couponsLoadingMore = false;
//     _couponsHasMore = true;
//     _couponsCursorAfter = null;
//
//     _allCoupons.clear();
//     _filteredCoupons = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredCoupons;
//
//       final res = await _couponService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _couponsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         _allCoupons.addAll(items);
//
//         _couponsHasMore = items.length >= _couponsPageSize;
//         _couponsCursorAfter = _couponsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyCouponFilter();
//         return _filteredCoupons;
//       } else {
//         if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredCoupons;
//       }
//     } finally {
//       _couponsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Coupon>> loadMoreCoupons({bool showSnack = false}) async {
//     if (_couponsLoading || _couponsLoadingMore || !_couponsHasMore) {
//       return _filteredCoupons;
//     }
//
//     _couponsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredCoupons;
//
//       final res = await _couponService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _couponsPageSize,
//         cursorAfter: _couponsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         if (items.isEmpty) {
//           _couponsHasMore = false;
//           return _filteredCoupons;
//         }
//
//         // upsert جلوگیری از تکرار
//         for (final c in items) {
//           final id = (c.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allCoupons.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allCoupons.add(c);
//           } else {
//             _allCoupons[idx] = c;
//           }
//         }
//
//         _couponsHasMore = items.length >= _couponsPageSize;
//         _couponsCursorAfter = _couponsHasMore ? items.last.sId : null;
//
//         _applyCouponFilter();
//         return _filteredCoupons;
//       } else {
//         if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredCoupons;
//       }
//     } finally {
//       _couponsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterCoupons(String keyword) {
//     _couponKeyword = keyword.trim();
//     _applyCouponFilter();
//     notifyListeners();
//   }
//   //////////////////////////////////////////////////coupons//////////////////////////////////////////////////
//
//   //////////////////////////////////////////////////brands//////////////////////////////////////////////////
//
//
//   static const int _brandsPageSize = 17;
//
//   bool _brandsLoading = false;
//   bool _brandsLoadingMore = false;
//   bool _brandsHasMore = true;
//
//   String? _brandsCursorAfter;
//   final Set<String> _loadedBrandIds = {};
//
//   String _brandKeyword = '';
//
//   bool get isBrandsLoading => _brandsLoading;
//   bool get isBrandsLoadingMore => _brandsLoadingMore;
//   bool get hasMoreBrands => _brandsHasMore;
//
// // --- Sort helper: newest updatedAt/createdAt first ---
//   DateTime _brandTs(Brand b) {
//     final u = (b.updatedAt ?? '').trim();
//     final c = (b.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllBrands() {
//     _allBrands.sort((a, b) => _brandTs(b).compareTo(_brandTs(a))); // DESC
//   }
//
//   /// ✅ create/update برند => بیاد اول (بدون reload)
//   void upsertBrandToTop(Brand incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allBrands.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allBrands.removeAt(idx);
//
//     _allBrands.insert(0, incoming);
//
//     _applyBrandFilter();
//     notifyListeners();
//   }
//
//   /// ✅ حذف از لیست (بعد از delete)
//   void removeBrandById(String id) {
//     final sid = id.trim();
//     if (sid.isEmpty) return;
//
//     _allBrands.removeWhere((b) => (b.sId ?? '').trim() == sid);
//     _applyBrandFilter();
//     notifyListeners();
//   }
//
// // -------- SubCategory cache for brands (برای اینکه نام زیر‌دسته همیشه بیاد) --------
//   final Map<String, SubCategory> _scCacheForBrands = {};
//   String? _scCachePhoneForBrands;
//
//   Future<void> _ensureSubCategoryCacheForBrands(String phone, List<Brand> brands) async {
//     if (_scCachePhoneForBrands != phone) {
//       _scCachePhoneForBrands = phone;
//       _scCacheForBrands.clear();
//     }
//
//     // seed from already loaded subcategories
//     for (final sc in _allSubCategories) {
//       final id = (sc.sId ?? '').trim();
//       if (id.isNotEmpty) _scCacheForBrands[id] = sc;
//     }
//
//     final missing = <String>{};
//     for (final b in brands) {
//       final subId = (b.subcategory ?? b.subcategoriesId ?? b.subCategoryId?.sId ?? '').toString().trim();
//       if (subId.isNotEmpty && !_scCacheForBrands.containsKey(subId)) {
//         missing.add(subId);
//       }
//     }
//
//     // fetch missing ones (page size کوچیکه، مشکلی نیست)
//     for (final id in missing) {
//       final res = await _subCategoryService.getById(id);
//       if (res.isSuccess) {
//         final sc = res.requireData();
//         final sid = (sc.sId ?? '').trim();
//         if (sid.isNotEmpty) _scCacheForBrands[sid] = sc;
//       }
//     }
//   }
//
//   void _hydrateBrandsWithSubCategoryNames(List<Brand> brands) {
//     for (final b in brands) {
//       final subId = (b.subcategory ?? b.subcategoriesId ?? b.subCategoryId?.sId ?? '').toString().trim();
//       if (subId.isEmpty) continue;
//
//       final sc = _scCacheForBrands[subId];
//       if (sc == null) continue;
//
//       b.subCategoryId = SubcategoryId(
//         sId: sc.sId,
//         name: sc.name,
//       );
//     }
//   }
//
//   void filterBrands(String keyword) {
//     _brandKeyword = keyword.trim();
//     _applyBrandFilter();
//     notifyListeners();
//   }
//
//   Future<List<Brand>> getAllBrands({bool showSnack = false}) async {
//     return loadInitialBrands(showSnack: showSnack);
//   }
//
//   Future<List<Brand>> loadInitialBrands({bool showSnack = false}) async {
//     if (_brandsLoading) return _filteredBrands;
//
//     _brandsLoading = true;
//     _brandsLoadingMore = false;
//     _brandsHasMore = true;
//     _brandsCursorAfter = null;
//     _loadedBrandIds.clear();
//
//     _allBrands.clear();
//     _filteredBrands = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         return _filteredBrands;
//       }
//
//       // حداقل صفحه اول subcategories برای dropdownها
//       await _ensureSubCategoriesLoadedForBrands();
//
//       final res = await brandsRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _brandsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         await _ensureSubCategoryCacheForBrands(phone.trim(), items);
//         _hydrateBrandsWithSubCategoryNames(items);
//
//         _allBrands.addAll(items);
//
//         _brandsHasMore = items.length >= _brandsPageSize;
//         _brandsCursorAfter = _brandsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyBrandFilter();
//         notifyListeners();
//
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Brands loaded');
//         return _filteredBrands;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredBrands;
//       }
//     } finally {
//       _brandsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Brand>> loadMoreBrands({bool showSnack = false}) async {
//     if (_brandsLoading || _brandsLoadingMore || !_brandsHasMore) return _filteredBrands;
//
//     _brandsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredBrands;
//
//       final res = await brandsRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _brandsPageSize,
//         cursorAfter: _brandsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         if (items.isEmpty) {
//           _brandsHasMore = false;
//           return _filteredBrands;
//         }
//
//         await _ensureSubCategoriesLoadedForBrands();
//         await _ensureSubCategoryCacheForBrands(phone.trim(), items);
//         _hydrateBrandsWithSubCategoryNames(items);
//
//         // upsert + جلوگیری از تکرار
//         for (final b in items) {
//           final id = (b.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allBrands.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allBrands.add(b);
//           } else {
//             _allBrands[idx] = b;
//           }
//           _loadedBrandIds.add(id);
//         }
//
//         _brandsHasMore = items.length >= _brandsPageSize;
//         _brandsCursorAfter = _brandsHasMore ? items.last.sId : null;
//
//         _applyBrandFilter();
//         return _filteredBrands;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredBrands;
//       }
//     } finally {
//       _brandsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   Future<void> _ensureSubCategoriesLoadedForBrands() async {
//     if (_allSubCategories.isEmpty) {
//       await getAllSubCategories(showSnack: false);
//     }
//   }
//
//   void _applyBrandFilter() {
//     _sortAllBrands();
//
//     final kw = _brandKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredBrands = List<Brand>.from(_allBrands);
//       return;
//     }
//
//     _filteredBrands = _allBrands
//         .where((b) => (b.name ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _brandTs(b).compareTo(_brandTs(a)));
//   }
//   //////////////////////////////////////////////////brands//////////////////////////////////////////////////
//
//
//
// //////////////////////////////////////////////////POSTERS//////////////////////////////////////////////////
// // ================================
// // ✅ POSTERS (Paging + Shimmer)
// // ================================
//
// // --- Sort helper: newest updatedAt/createdAt first ---
//   DateTime _posterTs(Poster p) {
//     final u = (p.updatedAt ?? '').trim();
//     final c = (p.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllPosters() {
//     _allPosters.sort((a, b) => _posterTs(b).compareTo(_posterTs(a))); // DESC
//   }
//
//   /// ✅ create/update => بیاد اول (بدون نیاز به reload)
//   void upsertPosterToTop(Poster incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     // اگر updatedAt از سرور نیومده بود، برای نمایش درست
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allPosters.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allPosters.removeAt(idx);
//
//     _allPosters.insert(0, incoming);
//
//     _applyPosterFilter();
//     notifyListeners();
//   }
//
//   static const int _postersPageSize = 17;
//
//   bool _postersLoading = false;
//   bool _postersLoadingMore = false;
//   bool _postersHasMore = true;
//
//   String? _postersCursorAfter;
//   String _posterKeyword = '';
//
//   bool get isPostersLoading => _postersLoading;
//   bool get isPostersLoadingMore => _postersLoadingMore;
//   bool get hasMorePosters => _postersHasMore;
//
//   Future<List<Poster>> getAllPosters({bool showSnack = false}) async {
//     return loadInitialPosters(showSnack: showSnack);
//   }
//
//   Future<List<Poster>> loadInitialPosters({bool showSnack = false}) async {
//     if (_postersLoading) return _filteredPosters;
//
//     _postersLoading = true;
//     _postersLoadingMore = false;
//     _postersHasMore = true;
//     _postersCursorAfter = null;
//
//     _allPosters.clear();
//     _filteredPosters = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//         return _filteredPosters;
//       }
//
//       final res = await _posterService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _postersPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _allPosters.addAll(items);
//
//         _postersHasMore = items.length >= _postersPageSize;
//         _postersCursorAfter =
//         _postersHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyPosterFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('پوسترها لود شدند');
//         return _filteredPosters;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredPosters;
//       }
//     } finally {
//       _postersLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Poster>> loadMorePosters({bool showSnack = false}) async {
//     if (_postersLoading || _postersLoadingMore || !_postersHasMore) {
//       return _filteredPosters;
//     }
//
//     _postersLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredPosters;
//
//       final res = await _posterService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _postersPageSize,
//         cursorAfter: _postersCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _postersHasMore = false;
//           return _filteredPosters;
//         }
//
//         // upsert + جلوگیری از تکرار
//         for (final p in items) {
//           final id = (p.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allPosters.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allPosters.add(p);
//           } else {
//             _allPosters[idx] = p;
//           }
//         }
//
//         _postersHasMore = items.length >= _postersPageSize;
//         _postersCursorAfter = _postersHasMore ? items.last.sId : null;
//
//         _applyPosterFilter();
//         return _filteredPosters;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredPosters;
//       }
//     } finally {
//       _postersLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterPosters(String keyword) {
//     _posterKeyword = keyword.trim();
//     _applyPosterFilter();
//     notifyListeners();
//   }
//
//   void _applyPosterFilter() {
//     _sortAllPosters();
//
//     final kw = _posterKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredPosters = List<Poster>.from(_allPosters);
//       return;
//     }
//
//     _filteredPosters = _allPosters
//         .where((p) => (p.posterName ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _posterTs(b).compareTo(_posterTs(a)));
//   }
// //////////////////////////////////////////////////VARIANTS//////////////////////////////////////////////////
//   // ================================
// // ✅ VARIANTS (Paging + Shimmer + Hydration by VariantTypes)
// // ================================
//   static const int _variantsPageSize = 17;
//
//   bool _variantsLoading = false;
//   bool _variantsLoadingMore = false;
//   bool _variantsHasMore = true;
//
//   String? _variantsCursorAfter;
//   String _variantKeyword = '';
//
//   bool get isVariantsLoading => _variantsLoading;
//   bool get isVariantsLoadingMore => _variantsLoadingMore;
//   bool get hasMoreVariants => _variantsHasMore;
//
// // cache برای map کردن نام تایپ‌ها
//   Map<String, VariantType> _vtMapForVariants = {};
//   String? _vtMapPhoneForVariants;
//
//   Future<void> _ensureVariantTypeMapForVariants(String phone) async {
//     if (_vtMapPhoneForVariants == phone && _vtMapForVariants.isNotEmpty) return;
//
//     final allVts = await _getVariantTypesForHydration(phone);
//     final map = <String, VariantType>{};
//     for (final vt in allVts) {
//       final id = (vt.sId ?? '').trim();
//       if (id.isNotEmpty) map[id] = vt;
//     }
//
//     _vtMapForVariants = map;
//     _vtMapPhoneForVariants = phone;
//   }
//
//   void _hydrateVariantsTypeNames(List<Variant> vars) {
//     if (_vtMapForVariants.isEmpty) return;
//
//     for (final v in vars) {
//       final vtId = (v.variantType ?? v.variantTypeId?.sId ?? '').trim();
//       if (vtId.isEmpty) continue;
//
//       final vt = _vtMapForVariants[vtId];
//       if (vt == null) continue;
//
//       v.variantTypeId = VariantTypeId(
//         sId: vt.sId,
//         name: vt.name,
//         type: vt.type,
//       );
//     }
//   }
//
//   Future<List<Variant>> getAllVariants({bool showSnack = false}) async {
//     return loadInitialVariants(showSnack: showSnack);
//   }
//
//   Future<List<Variant>> loadInitialVariants({bool showSnack = false}) async {
//     if (_variantsLoading) return _filteredVariants;
//
//     _variantsLoading = true;
//     _variantsLoadingMore = false;
//     _variantsHasMore = true;
//     _variantsCursorAfter = null;
//
//     _allVariants.clear();
//     _filteredVariants = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) {
//           SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         }
//         return _filteredVariants;
//       }
//
//       // ✅ برای اینکه اسم تایپ‌ها همیشه درست hydrate بشه (حتی اگر VariantTypes صفحه‌بندی شده باشد)
//       await _ensureVariantTypeMapForVariants(phone.trim());
//
//       final res = await variantsRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _variantsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _hydrateVariantsTypeNames(items);
//
//         _allVariants.addAll(items);
//
//         _variantsHasMore = items.length >= _variantsPageSize;
//         _variantsCursorAfter =
//         _variantsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyVariantFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Variants loaded');
//         return _filteredVariants;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredVariants;
//       }
//     } finally {
//       _variantsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Variant>> loadMoreVariants({bool showSnack = false}) async {
//     if (_variantsLoading || _variantsLoadingMore || !_variantsHasMore) {
//       return _filteredVariants;
//     }
//
//     _variantsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredVariants;
//
//       await _ensureVariantTypeMapForVariants(phone.trim());
//
//       final res = await variantsRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _variantsPageSize,
//         cursorAfter: _variantsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _variantsHasMore = false;
//           return _filteredVariants;
//         }
//
//         _hydrateVariantsTypeNames(items);
//
//         // upsert + جلوگیری از تکرار
//         for (final v in items) {
//           final id = (v.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allVariants.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allVariants.add(v);
//           } else {
//             _allVariants[idx] = v;
//           }
//         }
//
//         _variantsHasMore = items.length >= _variantsPageSize;
//         _variantsCursorAfter = _variantsHasMore ? items.last.sId : null;
//
//         _applyVariantFilter();
//         return _filteredVariants;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredVariants;
//       }
//     } finally {
//       _variantsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
// // ✅ فیلتر (مثل بقیه paging ها)
//   void filterVariants(String keyword) {
//     _variantKeyword = keyword.trim();
//     _applyVariantFilter();
//     notifyListeners();
//   }
//
//   void _applyVariantFilter() {
//     final kw = _variantKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredVariants = List<Variant>.from(_allVariants);
//       return;
//     }
//
//     _filteredVariants = _allVariants
//         .where((v) => (v.name ?? '').toLowerCase().contains(kw))
//         .toList();
//   }
// //////////////////////////////////////////////////VARIANTS//////////////////////////////////////////////////
// //////////////////////////////////////////////////variantTypes//////////////////////////////////////////////////
// // ================================
// // ✅ VARIANT TYPES (Paging + Shimmer + Updated items first)
// // ================================
//   static const int _variantTypesPageSize = 17;
//
//   bool _variantTypesLoading = false;
//   bool _variantTypesLoadingMore = false;
//   bool _variantTypesHasMore = true;
//
//   String? _variantTypesCursorAfter;
//   String _variantTypeKeyword = '';
//
//   bool get isVariantTypesLoading => _variantTypesLoading;
//   bool get isVariantTypesLoadingMore => _variantTypesLoadingMore;
//   bool get hasMoreVariantTypes => _variantTypesHasMore;
//
// // --- Sort helper: newest updatedAt/createdAt first ---
//   DateTime _vtTs(VariantType v) {
//     final u = (v.updatedAt ?? '').trim();
//     final c = (v.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllVariantTypes() {
//     _allVariantTypes.sort((a, b) => _vtTs(b).compareTo(_vtTs(a))); // DESC
//   }
//
//   /// ✅ create/update => بیاد اول (بدون نیاز به reload)
//   void upsertVariantTypeToTop(VariantType incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     // اگر updatedAt از سرور نیومده بود، برای نمایش درست
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allVariantTypes.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allVariantTypes.removeAt(idx);
//
//     _allVariantTypes.insert(0, incoming);
//
//     _applyVariantTypeFilter();
//     notifyListeners();
//   }
//
//   Future<List<VariantType>> getAllVariantTypes({bool showSnack = false}) async {
//     return loadInitialVariantTypes(showSnack: showSnack);
//   }
//
//   Future<List<VariantType>> loadInitialVariantTypes({bool showSnack = false}) async {
//     if (_variantTypesLoading) return _filteredVariantTypes;
//
//     _variantTypesLoading = true;
//     _variantTypesLoadingMore = false;
//     _variantTypesHasMore = true;
//     _variantTypesCursorAfter = null;
//
//     _allVariantTypes.clear();
//     _filteredVariantTypes = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) {
//           SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         }
//         return _filteredVariantTypes;
//       }
//
//       final res = await variantTypesRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _variantTypesPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _allVariantTypes.addAll(items);
//
//         _variantTypesHasMore = items.length >= _variantTypesPageSize;
//         _variantTypesCursorAfter =
//         _variantTypesHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyVariantTypeFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Variant types loaded');
//         return _filteredVariantTypes;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredVariantTypes;
//       }
//     } finally {
//       _variantTypesLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<VariantType>> loadMoreVariantTypes({bool showSnack = false}) async {
//     if (_variantTypesLoading || _variantTypesLoadingMore || !_variantTypesHasMore) {
//       return _filteredVariantTypes;
//     }
//
//     _variantTypesLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredVariantTypes;
//
//       final res = await variantTypesRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _variantTypesPageSize,
//         cursorAfter: _variantTypesCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _variantTypesHasMore = false;
//           return _filteredVariantTypes;
//         }
//
//         // upsert + جلوگیری از تکرار
//         for (final vt in items) {
//           final id = (vt.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allVariantTypes.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allVariantTypes.add(vt);
//           } else {
//             _allVariantTypes[idx] = vt;
//           }
//         }
//
//         _variantTypesHasMore = items.length >= _variantTypesPageSize;
//         _variantTypesCursorAfter = _variantTypesHasMore ? items.last.sId : null;
//
//         _applyVariantTypeFilter();
//         return _filteredVariantTypes;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredVariantTypes;
//       }
//     } finally {
//       _variantTypesLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterVariantTypes(String keyword) {
//     _variantTypeKeyword = keyword.trim();
//     _applyVariantTypeFilter();
//     notifyListeners();
//   }
//
//   void _applyVariantTypeFilter() {
//     _sortAllVariantTypes();
//
//     final kw = _variantTypeKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredVariantTypes = List<VariantType>.from(_allVariantTypes);
//       return;
//     }
//
//     _filteredVariantTypes = _allVariantTypes
//         .where((v) => (v.name ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _vtTs(b).compareTo(_vtTs(a)));
//   }
//
//   /// ✅ برای اینکه mapping داخل getAllVariants خراب نشه (اگر VariantTypes صفحه‌بندی شد)
//   Future<List<VariantType>> _getVariantTypesForHydration(String phone) async {
//     final res = await variantTypesRepoAppwrite.getByPhoneNumberCode(phone);
//     if (res.isSuccess) return res.requireData();
//     return _allVariantTypes;
//   }
//
// // ================================
// // ✅ VARIANT TYPES (Paging + Shimmer + Updated items first)
// // ================================
//
// //////////////////////////////////////////////////variantTypes//////////////////////////////////////////////////
//   //////////////////////////////////////////////////SUBCATEGORIES//////////////////////////////////////////////////
// // ================================
// // ✅ SUBCATEGORIES (Paging + Updated items first)
// // ================================
//   static const int _subCategoriesPageSize = 17;
//
//   bool _subCategoriesLoading = false;
//   bool _subCategoriesLoadingMore = false;
//   bool _subCategoriesHasMore = true;
//
//   String? _subCategoriesCursorAfter;
//   String _subCategoryKeyword = '';
//
//   bool get isSubCategoriesLoading => _subCategoriesLoading;
//   bool get isSubCategoriesLoadingMore => _subCategoriesLoadingMore;
//   bool get hasMoreSubCategories => _subCategoriesHasMore;
//
// // --- Sort helper: newest updatedAt/createdAt first ---
//   DateTime _subTs(SubCategory s) {
//     final raw = (s.updatedAt ?? '').trim().isNotEmpty ? s.updatedAt! : (s.createdAt ?? '');
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllSubCategories() {
//     _allSubCategories.sort((a, b) => _subTs(b).compareTo(_subTs(a))); // DESC
//   }
//
// // ✅ ایجاد یا بروزرسانی زیر‌دسته و آوردن به اول (با مرتب‌سازی بر اساس updatedAt)
//   void upsertSubCategoryToTop(SubCategory incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     // اگر updatedAt از سرور نیومده بود، برای نمایش درست، همین‌جا ست می‌کنیم
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allSubCategories.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allSubCategories.removeAt(idx);
//
//     _allSubCategories.insert(0, incoming);
//
//     _applySubCategoryFilter(); // داخلش sort هم انجام میشه
//     notifyListeners();
//   }
//
// // ✅ (اختیاری ولی کاربردی) create/update که خودش بعد از موفقیت میاره اول
//   Future<void> createSubCategory({
//     required String name,
//     required String categoryId,
//     bool showSnack = false,
//   }) async {
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     if (phone.trim().isEmpty) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//       return;
//     }
//
//     final res = await _subCategoryService.createSubCategory(
//       name: name.trim(),
//       phoneNumberCode: phone.trim(),
//       categoryId: categoryId,
//     );
//
//     if (res.isSuccess) {
//       final saved = res.requireData();
//       upsertSubCategoryToTop(saved);
//       if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategory created');
//     } else {
//       if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//     }
//   }
//
//   Future<void> updateSubCategory({
//     required String documentId,
//     required String name,
//     required String categoryId,
//     bool showSnack = false,
//   }) async {
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     if (phone.trim().isEmpty) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//       return;
//     }
//
//     final res = await _subCategoryService.updateSubCategory(
//       documentId: documentId,
//       name: name.trim(),
//       phoneNumberCode: phone.trim(),
//       categoryId: categoryId,
//     );
//
//     if (res.isSuccess) {
//       final saved = res.requireData();
//       upsertSubCategoryToTop(saved); // ✅ همین باعث میشه آپدیت بیاد اول
//       if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategory updated');
//     } else {
//       if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//     }
//   }
//
//   Future<void> deleteSubCategory(SubCategory sub, {bool showSnack = false}) async {
//     final id = (sub.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     final res = await _subCategoryService.deleteSubCategory(documentId: id);
//     if (res.isSuccess) {
//       _allSubCategories.removeWhere((x) => (x.sId ?? '').trim() == id);
//       _applySubCategoryFilter();
//       notifyListeners();
//       if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategory deleted');
//     } else {
//       if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//     }
//   }
//
// // ✅ لود اولیه
//   Future<List<SubCategory>> getAllSubCategories({bool showSnack = false}) async {
//     return loadInitialSubCategories(showSnack: showSnack);
//   }
//
//   Future<List<SubCategory>> loadInitialSubCategories({bool showSnack = false}) async {
//     if (_subCategoriesLoading) return _filteredSubCategories;
//
//     _subCategoriesLoading = true;
//     _subCategoriesLoadingMore = false;
//     _subCategoriesHasMore = true;
//     _subCategoriesCursorAfter = null;
//
//     _allSubCategories.clear();
//     _filteredSubCategories = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//         return _filteredSubCategories;
//       }
//
//       final result = await _subCategoryService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _subCategoriesPageSize,
//         cursorAfter: null,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//         _allSubCategories.addAll(items);
//
//         _subCategoriesHasMore = items.length >= _subCategoriesPageSize;
//         _subCategoriesCursorAfter =
//         _subCategoriesHasMore ? (items.isNotEmpty ? items.last.sId : null) : null;
//
//         _applySubCategoryFilter(); // ✅ includes sort (updated first)
//         notifyListeners();
//
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategories loaded');
//         return _filteredSubCategories;
//       } else {
//         final err = result.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredSubCategories;
//       }
//     } finally {
//       _subCategoriesLoading = false;
//       notifyListeners();
//     }
//   }
//
// // ✅ لود بیشتر (Paging)
//   Future<List<SubCategory>> loadMoreSubCategories({bool showSnack = false}) async {
//     if (_subCategoriesLoading || _subCategoriesLoadingMore || !_subCategoriesHasMore) {
//       return _filteredSubCategories;
//     }
//
//     _subCategoriesLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredSubCategories;
//
//       final result = await _subCategoryService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _subCategoriesPageSize,
//         cursorAfter: _subCategoriesCursorAfter,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//
//         if (items.isEmpty) {
//           _subCategoriesHasMore = false;
//           return _filteredSubCategories;
//         }
//
//         // upsert (بدون تغییر ترتیب دستی؛ ترتیب با sort درست میشه)
//         for (final s in items) {
//           final id = (s.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allSubCategories.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allSubCategories.add(s);
//           } else {
//             _allSubCategories[idx] = s;
//           }
//         }
//
//         _subCategoriesHasMore = items.length >= _subCategoriesPageSize;
//         _subCategoriesCursorAfter = _subCategoriesHasMore ? items.last.sId : null;
//
//         _applySubCategoryFilter(); // ✅ includes sort (updated first)
//         return _filteredSubCategories;
//       } else {
//         final err = result.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredSubCategories;
//       }
//     } finally {
//       _subCategoriesLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
// // ✅ فیلتر
//   void filterSubCategories(String keyword) {
//     _subCategoryKeyword = keyword.trim();
//     _applySubCategoryFilter();
//     notifyListeners();
//   }
//
// // ✅ اعمال فیلتر + مرتب‌سازی (آپدیت‌ها اول)
//   void _applySubCategoryFilter() {
//     _sortAllSubCategories();
//
//     final kw = _subCategoryKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredSubCategories = List<SubCategory>.from(_allSubCategories);
//       return;
//     }
//
//     _filteredSubCategories = _allSubCategories
//         .where((s) => (s.name ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _subTs(b).compareTo(_subTs(a))); // برای حالت فیلتر هم
//   }
//
//
// // ================================
// // ✅ SUBCATEGORIES PAGING (Appwrite)
// // ================================
//
//   //////////////////////////////////////////////////SUBCATEGORIES//////////////////////////////////////////////////
//   //////////////////////////////////////////////////CATEGORIES//////////////////////////////////////////////////
//
//
//   Future<List<Category>> getAllCategories({bool showSnack = false}) async {
//     return loadInitialCategories(showSnack: showSnack);
//   }
//
//   Future<List<Category>> loadInitialCategories({bool showSnack = false}) async {
//     if (_categoriesLoading) return _filteredCategories;
//
//     _categoriesLoading = true;
//     _categoriesLoadingMore = false;
//     _categoriesHasMore = true;
//     _categoriesCursorAfter = null;
//
//     _allCategories.clear();
//     _filteredCategories = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) {
//           SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//         }
//         return _filteredCategories;
//       }
//
//       final result = await categoriesRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _categoriesPageSize,
//         cursorAfter: null,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//
//         _allCategories.addAll(items);
//
//         _categoriesHasMore = items.length >= _categoriesPageSize;
//         _categoriesCursorAfter =
//         _categoriesHasMore ? (items.isNotEmpty ? items.last.sId : null) : null;
//
//         _applyCategoryFilter();
//         notifyListeners();
//
//         if (showSnack) {
//           SnackBarHelper.showSuccessSnackBar('دسته‌بندی‌ها بروزرسانی شدند');
//         }
//
//         return _filteredCategories;
//       } else {
//         final error = result.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(error.userMessage);
//         return _filteredCategories;
//       }
//     } catch (e) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('خطا در لود دسته‌بندی‌ها: $e');
//       rethrow;
//     } finally {
//       _categoriesLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Category>> loadMoreCategories({bool showSnack = false}) async {
//     if (_categoriesLoading || _categoriesLoadingMore || !_categoriesHasMore) {
//       return _filteredCategories;
//     }
//
//     _categoriesLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredCategories;
//
//       final result = await categoriesRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _categoriesPageSize,
//         cursorAfter: _categoriesCursorAfter,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//
//         if (items.isEmpty) {
//           _categoriesHasMore = false;
//           return _filteredCategories;
//         }
//
//         // جلوگیری از تکرار (simple)
//         for (final c in items) {
//           final id = (c.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allCategories.indexWhere((x) => (x.sId ?? '') == id);
//           if (idx == -1) {
//             _allCategories.add(c);
//           } else {
//             _allCategories[idx] = c;
//           }
//         }
//
//         _categoriesHasMore = items.length >= _categoriesPageSize;
//         _categoriesCursorAfter = _categoriesHasMore ? items.last.sId : null;
//
//         _applyCategoryFilter();
//         return _filteredCategories;
//       } else {
//         final err = result.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredCategories;
//       }
//     } finally {
//       _categoriesLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterCategories(String keyword) {
//     _categoryKeyword = keyword.trim();
//     _applyCategoryFilter();
//     notifyListeners();
//   }
//
//   void _applyCategoryFilter() {
//     final kw = _categoryKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredCategories = List<Category>.from(_allCategories);
//       return;
//     }
//
//     _filteredCategories = _allCategories
//         .where((c) => (c.name ?? '').toLowerCase().contains(kw))
//         .toList();
//   }
//
//
//   static const int _categoriesPageSize = 17;
//
//   bool _categoriesLoading = false;
//   bool _categoriesLoadingMore = false;
//   bool _categoriesHasMore = true;
//
//   String? _categoriesCursorAfter;
//   String _categoryKeyword = '';
//
//   bool get isCategoriesLoading => _categoriesLoading;
//   bool get isCategoriesLoadingMore => _categoriesLoadingMore;
//   bool get hasMoreCategories => _categoriesHasMore;
//
// //////////////////////////////////////////////////CATEGORIES//////////////////////////////////////////////////
//
//
//
// }





//
// import 'package:admin/config/environment.dart';
// import 'package:admin/config/network/realtime_manager.dart';
// import 'package:admin/core/data/appwrite/brands_repository.dart';
// import 'package:admin/core/data/appwrite/coupon_code_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/orders_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/products_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/sub_category_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/variant_types_repository.dart';
// import 'package:admin/core/data/appwrite/variants_repository.dart';
//
// import 'package:admin/utility/User_helper.dart';
// import 'package:admin/utility/snack_bar_helper.dart';
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/foundation.dart' hide Category;
//
//
// import '../../../models/category.dart';
// import '../../models/brand.dart';
// import '../../models/coupon.dart';
//
// import '../../models/order.dart';
// import '../../models/poster.dart';
// import '../../models/product.dart';
// import '../../models/sub_category.dart';
// import '../../models/variant.dart';
// import '../../models/variant_type.dart';
//
// import '../../utility/constants.dart';
// import 'dart:async';
//
//
// import 'appwrite/categories_repository.dart';
// import 'appwrite/poster_appwrite_service.dart';
//
//
//
// import 'package:admin/config/environment.dart';
// import 'package:admin/config/network/realtime_manager.dart';
// import 'package:admin/core/data/appwrite/brands_repository.dart';
// import 'package:admin/core/data/appwrite/coupon_code_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/orders_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/products_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/sub_category_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/variant_types_repository.dart';
// import 'package:admin/core/data/appwrite/variants_repository.dart';
//
// import 'package:admin/utility/User_helper.dart';
// import 'package:admin/utility/snack_bar_helper.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/foundation.dart' hide Category;
//
// import '../../../models/category.dart';
// import '../../models/brand.dart';
// import '../../models/coupon.dart';
// import '../../models/order.dart';
// import '../../models/poster.dart';
// import '../../models/product.dart';
// import '../../models/sub_category.dart';
// import '../../models/variant.dart';
// import '../../models/variant_type.dart';
//
// import '../../utility/constants.dart';
// import 'dart:async';
//
// import 'appwrite/categories_repository.dart';
// import 'appwrite/poster_appwrite_service.dart';
//
// class DataProvider extends ChangeNotifier {
//   bool _initialized = false;
//
//   // ================================================
//   // سفارشات — realtime واحد برای همه وضعیت‌ها
//   // ================================================
//
//   static const String ORDER_STATUS_PAID = 'Paid';
//
//   final List<Order> _inProgressOrders = [];
//   List<Order> get inProgressOrders => List.unmodifiable(_inProgressOrders);
//
//   final List<Order> _paidOrders = [];
//   List<Order> _filteredPaidOrders = [];
//   List<Order> get paidOrders => _filteredPaidOrders;
//
//   StreamSubscription<RealtimeEvent<Order>>? _ordersRealtimeSub;
//
//   // pagination برای پرداخت شده‌ها
//   static const int _paidOrdersPageSize = 17;
//   bool _paidOrdersLoading = false;
//   bool _paidOrdersHasMore = true;
//
//   bool get isPaidOrdersLoading => _paidOrdersLoading;
//   bool get hasMorePaidOrders => _paidOrdersHasMore;
//
//   bool _isPaidStatus(String? status) {
//     return (status ?? '').trim().toLowerCase() == 'paid';
//   }
//
//   String _s(Object? v) => v?.toString().trim() ?? '';
//
//   /// یک realtime واحد برای کل کالکشن orders
//   Future<void> _subscribeToOrdersRealtimeSingle() async {
//     await _ordersRealtimeSub?.cancel();
//     _ordersRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Order>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//       fromJson: _orderFromRealtime,
//     );
//
//     _ordersRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Order>(
//         event,
//         idOf: (o) => (o.sId ?? '').toString(),
//       );
//       if (docId == null || docId.isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _inProgressOrders.removeWhere((o) => _s(o.sId) == docId);
//         _paidOrders.removeWhere((o) => _s(o.sId) == docId);
//         _filteredPaidOrders = List.unmodifiable(_paidOrders);
//         _safeNotify();
//         return;
//       }
//
//       final order = event.data;
//       if (order == null) return;
//
//       if (_s(order.phoneNumberCode) != phoneCode) return;
//
//       final isPaid = _isPaidStatus(order.orderStatus);
//
//       if (isPaid) {
//         // از در جریان حذف
//         _inProgressOrders.removeWhere((o) => _s(o.sId) == docId);
//
//         // upsert در پرداخت شده
//         final idx = _paidOrders.indexWhere((o) => _s(o.sId) == docId);
//         if (idx == -1) {
//           _paidOrders.insert(0, order);
//         } else {
//           _paidOrders[idx] = order;
//         }
//
//         _sortPaidOrders();
//         _filteredPaidOrders = List.unmodifiable(_paidOrders);
//       } else {
//         // از پرداخت شده حذف
//         _paidOrders.removeWhere((o) => _s(o.sId) == docId);
//         _filteredPaidOrders = List.unmodifiable(_paidOrders);
//
//         // upsert در در جریان
//         final idx = _inProgressOrders.indexWhere((o) => _s(o.sId) == docId);
//         if (idx == -1) {
//           _inProgressOrders.insert(0, order);
//         } else {
//           _inProgressOrders[idx] = order;
//         }
//
//         _sortInProgressOrders();
//       }
//
//       _safeNotify();
//     });
//   }
//
//   void _sortInProgressOrders() {
//     final epoch = DateTime.fromMillisecondsSinceEpoch(0);
//     _inProgressOrders.sort((a, b) {
//       final aTime = a.updatedAt ?? a.createdAt ?? epoch;
//       final bTime = b.updatedAt ?? b.createdAt ?? epoch;
//       return bTime.compareTo(aTime);
//     });
//   }
//
//   void _sortPaidOrders() {
//     final epoch = DateTime.fromMillisecondsSinceEpoch(0);
//     _paidOrders.sort((a, b) {
//       final aTime = a.updatedAt ?? a.createdAt ?? epoch;
//       final bTime = b.updatedAt ?? b.createdAt ?? epoch;
//       return bTime.compareTo(aTime);
//     });
//   }
//
//   Future<void> getInProgressOrders({bool showSnack = false}) async {
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return;
//
//       final data = await ordersAppwriteService.fetchAllInProgress(
//         phoneNumberCode: phone.trim(),
//         batchSize: 200,
//       );
//
//       _inProgressOrders
//         ..clear()
//         ..addAll(data);
//
//       _sortInProgressOrders();
//       notifyListeners();
//     } catch (e) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('خطا در دریافت سفارشات در جریان');
//     }
//   }
//
//   Future<void> loadInitialPaidOrders({bool showSnack = false}) async {
//     _paidOrders.clear();
//     _filteredPaidOrders = const [];
//     _paidOrdersHasMore = true;
//     _paidOrdersLoading = true;
//     notifyListeners();
//
//     await _loadPaidOrdersPage(1, showSnack: showSnack);
//   }
//
//   Future<void> loadMorePaidOrders() async {
//     if (_paidOrdersLoading || !_paidOrdersHasMore) return;
//     await _loadPaidOrdersPage(_paidOrders.length ~/ _paidOrdersPageSize + 1);
//   }
//
//   Future<void> _loadPaidOrdersPage(int page, {bool showSnack = false}) async {
//     _paidOrdersLoading = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return;
//
//       final res = await ordersAppwriteService.fetchPaidPaged(
//         phoneNumberCode: phone.trim(),
//         page: page,
//         perPage: _paidOrdersPageSize,
//       );
//
//       if (page == 1) _paidOrders.clear();
//
//       // upsert برای جلوگیری از تکراری با realtime
//       for (final o in res.orders) {
//         final id = _s(o.sId);
//         if (id.isEmpty) continue;
//
//         final idx = _paidOrders.indexWhere((x) => _s(x.sId) == id);
//         if (idx == -1) {
//           _paidOrders.add(o);
//         } else {
//           _paidOrders[idx] = o;
//         }
//       }
//
//       _sortPaidOrders();
//       _filteredPaidOrders = List.unmodifiable(_paidOrders);
//       _paidOrdersHasMore = res.hasMore;
//     } catch (e) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('خطا در دریافت سفارشات پرداخت شده');
//     } finally {
//       _paidOrdersLoading = false;
//       notifyListeners();
//     }
//   }
//
//   // ================================================
//   // Realtime برای بقیه بخش‌ها
//   // ================================================
//
//   StreamSubscription<RealtimeEvent<Product>>? _productsRealtimeSub;
//   StreamSubscription<RealtimeEvent<Brand>>? _brandsRealtimeSub;
//   StreamSubscription<RealtimeEvent<Coupon>>? _couponsRealtimeSub;
//   StreamSubscription<RealtimeEvent<Poster>>? _postersRealtimeSub;
//   StreamSubscription<RealtimeEvent<Variant>>? _variantsRealtimeSub;
//   StreamSubscription<RealtimeEvent<VariantType>>? _variantTypesRealtimeSub;
//   StreamSubscription<RealtimeEvent<SubCategory>>? _subCategoriesRealtimeSub;
//   StreamSubscription<RealtimeEvent<Category>>? _categoriesRealtimeSub;
//
//   // Helperهای realtime
//   String? _extractDocIdFromEvents(List<String>? events) {
//     if (events == null || events.isEmpty) return null;
//     for (final e in events) {
//       final i = e.indexOf('.documents.');
//       if (i == -1) continue;
//       final tail = e.substring(i + '.documents.'.length);
//       final dot = tail.indexOf('.');
//       if (dot == -1) continue;
//       final id = tail.substring(0, dot).trim();
//       if (id.isNotEmpty) return id;
//     }
//     return null;
//   }
//
//   bool _isDeleteEvent<T>(RealtimeEvent<T> event) {
//     return event.action == RealtimeAction.delete ||
//         event.events.any((e) => e.endsWith('.delete'));
//   }
//
//   String? _getDocumentIdGeneric<T>(
//       RealtimeEvent<T> event, {
//         required String Function(T data) idOf,
//       }) {
//     final direct = event.documentId?.toString().trim() ?? '';
//     if (direct.isNotEmpty) return direct;
//
//     final fromEvents = _extractDocIdFromEvents(event.events);
//     if (fromEvents != null && fromEvents.isNotEmpty) return fromEvents;
//
//     final data = event.data;
//     if (data != null) {
//       final fallback = idOf(data).trim();
//       if (fallback.isNotEmpty) return fallback;
//     }
//
//     return null;
//   }
//
//   Map<String, dynamic> _normalizeOrderRealtimeJson(Map<String, dynamic> json) {
//     final m = Map<String, dynamic>.from(json);
//     m['id'] ??= m[r'$id'];
//     m['sId'] ??= m['id'];
//     m['created'] ??= m[r'$createdAt'];
//     m['createdAt'] ??= m[r'$createdAt'];
//     m['updatedAt'] ??= m[r'$updatedAt'];
//     return m;
//   }
//
//   Order _orderFromRealtime(Map<String, dynamic> json) {
//     return Order.fromJson(_normalizeOrderRealtimeJson(json));
//   }
//
//   // بقیه realtimeها (محصولات، برندها، کوپن‌ها، پوسترها، واریانت‌ها، کتگوری‌ها، ساب‌کتگوری‌ها)
//   // این‌ها دقیقاً مثل نسخه قبلی‌ات که کار می‌کردن — فقط اینجا خلاصه می‌نویسم تا کد طولانی نشه
//   // (تو فایل واقعی‌ات، این متدها رو نگه دار — فقط بخش سفارشات رو با این جایگزین کن)
//
//   Future<void> _subscribeToProductsRealtime() async { /* همان کد قبلی */ }
//   Future<void> _subscribeToBrandsRealtime() async { /* همان کد قبلی */ }
//   Future<void> _subscribeToCouponsRealtime() async { /* همان کد قبلی */ }
//   Future<void> _subscribeToPostersRealtime() async { /* همان کد قبلی */ }
//   Future<void> _subscribeToVariantsRealtime() async { /* همان کد قبلی */ }
//   Future<void> _subscribeToVariantTypesRealtime() async { /* همان کد قبلی */ }
//   Future<void> _subscribeToSubCategoriesRealtime() async { /* همان کد قبلی */ }
//   Future<void> _subscribeToCategoriesRealtime() async { /* همان کد قبلی */ }
//
//   Future<void> _bootRealtimeCommon() async {
//     await _subscribeToProductsRealtime();
//     await _subscribeToBrandsRealtime();
//     await _subscribeToPostersRealtime();
//     await _subscribeToVariantsRealtime();
//     await _subscribeToVariantTypesRealtime();
//     await _subscribeToSubCategoriesRealtime();
//     await _subscribeToCategoriesRealtime();
//   }
//
//   Future<void> _bootRealtimeOrdersAndCoupons() async {
//     await _subscribeToOrdersRealtimeSingle();
//     await _subscribeToCouponsRealtime();
//   }
//
//   // ================================================
//   // boot سفارشات
//   // ================================================
//
//   Future<void> _bootOrders() async {
//     await getInProgressOrders(showSnack: false);
//     await loadInitialPaidOrders(showSnack: false);
//   }
//
//   // ================================================
//   // initAll — کامل و بدون placeholder
//   // ================================================
//
//   Future<void> initAll() async {
//     if (_initialized) return;
//     _initialized = true;
//
//     await Future.wait([
//       getAllProducts(),
//       getAllCategories(),
//       getAllSubCategories(),
//       getAllBrands(),
//       getAllVariantTypes(),
//       getAllVariants(),
//       getAllPosters(),
//       getAllCoupons(),
//     ]);
//
//     final bool isFullMenu = await _isFullMenu();
//
//     await _bootRealtimeCommon(); // همیشه فعال
//
//     if (isFullMenu) {
//       await _bootOrders();
//       await _bootRealtimeOrdersAndCoupons();
//     } else {
//       _inProgressOrders.clear();
//       _paidOrders.clear();
//       _filteredPaidOrders = const [];
//       _allCoupons.clear();
//       _filteredCoupons = const [];
//
//       await _ordersRealtimeSub?.cancel();
//       _ordersRealtimeSub = null;
//
//       RealtimeManager.instance.unsubscribeCollection(
//         databaseId: Environment.databaseIdMenuMita,
//         collectionId: Environment.collectionIdOrders,
//       );
//
//       notifyListeners();
//     }
//   }
//
//   // ================================================
//   // dispose و logout — کامل
//   // ================================================
//
//   Timer? _notifyDebounce;
//
//   void _safeNotify() {
//     _notifyDebounce?.cancel();
//     _notifyDebounce = Timer(const Duration(milliseconds: 120), notifyListeners);
//   }
//
//   @override
//   void dispose() {
//     _ordersRealtimeSub?.cancel();
//     _productsRealtimeSub?.cancel();
//     _brandsRealtimeSub?.cancel();
//     _couponsRealtimeSub?.cancel();
//     _postersRealtimeSub?.cancel();
//     _variantsRealtimeSub?.cancel();
//     _variantTypesRealtimeSub?.cancel();
//     _subCategoriesRealtimeSub?.cancel();
//     _categoriesRealtimeSub?.cancel();
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//     );
//
//     _notifyDebounce?.cancel();
//     super.dispose();
//   }
//
//   Future<void> logoutCleanup() async {
//     _ordersRealtimeSub?.cancel();
//     _ordersRealtimeSub = null;
//     _productsRealtimeSub?.cancel();
//     _brandsRealtimeSub?.cancel();
//     _couponsRealtimeSub?.cancel();
//     _postersRealtimeSub?.cancel();
//     _variantsRealtimeSub?.cancel();
//     _variantTypesRealtimeSub?.cancel();
//     _subCategoriesRealtimeSub?.cancel();
//     _categoriesRealtimeSub?.cancel();
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//     );
//
//     _notifyDebounce?.cancel();
//     _notifyDebounce = null;
//
//     _initialized = false;
//
//     _inProgressOrders.clear();
//     _paidOrders.clear();
//     _filteredPaidOrders = const [];
//     _allCoupons.clear();
//     _filteredCoupons = const [];
//     _allProducts.clear();
//     _filteredProducts = const [];
//     _allBrands.clear();
//     _filteredBrands = const [];
//     _allCategories.clear();
//     _filteredCategories = const [];
//     _allSubCategories.clear();
//     _filteredSubCategories = const [];
//     _allVariantTypes.clear();
//     _filteredVariantTypes = const [];
//     _allVariants.clear();
//     _filteredVariants = const [];
//     _allPosters.clear();
//     _filteredPosters = const [];
//
//     notifyListeners();
//   }
//
//   // ================================================
//   // چک menu_type
//   // ================================================
//   Future<bool> _isFullMenu() async {
//     try {
//       final info = await UserSaveHelper.getUserInfo(showError: false);
//       final menuType = (info?['menu_type'] ?? '').toString().trim().toLowerCase();
//       return menuType != 'menu_one';
//     } catch (_) {
//       return true;
//     }
//   }
//
//   // ================================================
//   // شورت‌کات‌ها برای UI
//   // ================================================
//   List<Order> get allsOrders => inProgressOrders;
//   List<Order> get orders => paidOrders;
//
//   bool get isOrdersLoading => isPaidOrdersLoading;
//   bool get hasMoreOrders => hasMorePaidOrders;
//
//   Future<void> getAllsOrders({bool showSnack = false}) async => await getInProgressOrders(showSnack: showSnack);
//   Future<void> loadInitialOrders({bool showSnack = false}) async => await loadInitialPaidOrders(showSnack: showSnack);
//   Future<void> loadMoreOrders() async => await loadMorePaidOrders();
//
// // بقیه متدها (pagination محصولات، برندها، کوپن‌ها و ...) دقیقاً مثل نسخه فعلی‌ات بماند
//
// // ================================================
// // Realtime برای سفارشات پرداخت شده
// // ================================================
//
//   StreamSubscription<RealtimeEvent<Order>>? _paidOrdersRealtimeSub;
//
//   Future<void> initAfterLogin() async {
//     await initAll();
//   }
//
//
//   int calculateOrdersWithStatus({String? status}) {
//     if (status == null) return inProgressOrders.length;
//     return inProgressOrders.where((o) => o.orderStatus == status).length;
//   }
//
//   void filterAllOrders(String status) => notifyListeners();
//   void searchAllOrders(String query) => notifyListeners();
//   void searchOrders(String query) => notifyListeners();
//
//   final OrdersAppwriteService ordersAppwriteService = OrdersAppwriteService();
//
//
//
//
//
//
//   //////////////////////////////////////////////////ORDERS//////////////////////////////////////////////////
//
//
//
//   //////////////////////////////////////////////////ORDERS//////////////////////////////////////////////////
//
//   final CategoriesRepository categoriesRepoAppwrite = CategoriesRepository();
//
//   final BrandsRepository brandsRepoAppwrite = BrandsRepository();
//
//
//   final SubCategoryAppwriteService _subCategoryService = SubCategoryAppwriteService();
//
//
//   final VariantTypesRepository variantTypesRepoAppwrite = VariantTypesRepository();
//
//
//   final VariantsRepository variantsRepoAppwrite = VariantsRepository();
//
//   final ProductsAppwriteService _productsService = ProductsAppwriteService();
//
//   final PosterAppwriteService _posterService = PosterAppwriteService();
//
//
//   final CouponCodeAppwriteService _couponService = CouponCodeAppwriteService();
//
//
//   List<Category> _allCategories = [];
//   List<Category> _filteredCategories = [];
//
//   List<Category> get categories => _filteredCategories;
//
//   List<SubCategory> _allSubCategories = [];
//   List<SubCategory> _filteredSubCategories = [];
//
//   List<SubCategory> get subCategories => _filteredSubCategories;
//
//   List<Brand> _allBrands = [];
//   List<Brand> _filteredBrands = [];
//
//   List<Brand> get brands => _filteredBrands;
//
//   List<VariantType> _allVariantTypes = [];
//   List<VariantType> _filteredVariantTypes = [];
//
//   List<VariantType> get variantTypes => _filteredVariantTypes;
//
//   List<Variant> _allVariants = [];
//   List<Variant> _filteredVariants = [];
//
//   List<Variant> get variants => _filteredVariants;
//
//   List<Product> _allProducts = [];
//   List<Product> _filteredProducts = [];
//
//   List<Product> get products => _filteredProducts;
//
//   String _filteredProductsType = ALL_PRODUCTS;
//
//   String get productsType => _filteredProductsType;
//
//   List<Coupon> _allCoupons = [];
//   List<Coupon> _filteredCoupons = [];
//
//   List<Coupon> get coupons => _filteredCoupons;
//
//   List<Poster> _allPosters = [];
//   List<Poster> _filteredPosters = [];
//
//   List<Poster> get posters => _filteredPosters;
//
//
//
//
//
//
//
//
//
//
// //////////////////////////////////////////////////Product//////////////////////////////////////////////////
//   static const int _productsPageSize = 3;
//
//   bool _productsLoading = false;
//   bool _productsLoadingMore = false;
//   bool _productsHasMore = true;
//
//   String? _productsCursorAfter;
//   String _productKeyword = '';
//
//   bool get isProductsLoading => _productsLoading;
//   bool get isProductsLoadingMore => _productsLoadingMore;
//   bool get hasMoreProducts => _productsHasMore;
//
// // --- sort helper: newest updatedAt/createdAt first ---
//   DateTime _productTs(Product p) {
//     final u = (p.updatedAt ?? '').trim();
//     final c = (p.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllProducts() {
//     _allProducts.sort((a, b) => _productTs(b).compareTo(_productTs(a))); // DESC
//   }
//
//
//   void filterProductsByQuantity(String productQntType, {bool showSnack = false}) {
//     _filteredProductsType = productQntType.isEmpty ? ALL_PRODUCTS : productQntType;
//
//     if (_filteredProductsType == ALL_PRODUCTS) {
//       _filteredProducts = List<Product>.from(_allProducts);
//
//     } else if (_filteredProductsType == STOCK_OUT_PRODUCTS) {
//       _filteredProducts = _allProducts.where((p) => (_qtyOf(p) ?? -1) == 0).toList();
//
//     } else if (_filteredProductsType == LIMITED_STOCK_PRODUCTS) {
//       _filteredProducts = _allProducts.where((p) => (_qtyOf(p) ?? -1) == 1).toList();
//
//     } else if (_filteredProductsType == OTHER_PRODUCTS) {
//       _filteredProducts = _allProducts.where((p) {
//         final q = _qtyOf(p);
//         return q == null || (q != 0 && q != 1); // null هم میره تو سایر
//       }).toList();
//
//     } else {
//       _filteredProducts = List<Product>.from(_allProducts);
//     }
//
//     if (showSnack) {
//       SnackBarHelper.showSuccessSnackBar('${_filteredProductsType} retrieved successfully!');
//     }
//
//     notifyListeners();
//   }
//
//   int calculateProductWithQuantity({int? quantity}) {
//     if (quantity == null) return _allProducts.length;
//
//     int total = 0;
//     for (final p in _allProducts) {
//       final q = _qtyOf(p);
//       if (q == quantity) total++;
//     }
//     return total;
//   }
//   int? _tryInt(dynamic v) {
//     if (v == null) return null;
//     if (v is int) return v;
//     final s = v.toString().trim();
//     if (s.isEmpty) return null;
//     return int.tryParse(s);
//   }
//
//   int? _qtyOf(Product p) => _tryInt(p.quantity);
//
//   /// ✅ create/update => بیاد اول (بدون reload)
//   void upsertProductToTop(Product incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allProducts.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allProducts.removeAt(idx);
//
//     _allProducts.insert(0, incoming);
//
//     _hydrateProductsNames([incoming]); // مهم: category/subcategory
//     _applyProductFilter();
//     notifyListeners();
//   }
//
//   /// ✅ حذف محصول از لیست بعد از delete
//   void removeProductById(String id) {
//     final sid = id.trim();
//     if (sid.isEmpty) return;
//     _allProducts.removeWhere((p) => (p.sId ?? '').trim() == sid);
//     _applyProductFilter();
//     notifyListeners();
//   }
//
//   Future<List<Product>> getAllProducts({bool showSnack = false}) async {
//     return loadInitialProducts(showSnack: showSnack);
//   }
//
//   Future<List<Product>> loadInitialProducts({bool showSnack = false}) async {
//     if (_productsLoading) return _filteredProducts;
//
//     _productsLoading = true;
//     _productsLoadingMore = false;
//     _productsHasMore = true;
//     _productsCursorAfter = null;
//
//     _allProducts.clear();
//     _filteredProducts = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         return _filteredProducts;
//       }
//
//       // ✅ برای hydrate نام‌ها
//       await _ensureCategoriesLoadedForProducts();
//       await _ensureSubCategoriesLoadedForProducts();
//
//       final res = await _productsService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _productsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _hydrateProductsNames(items);
//         _allProducts.addAll(items);
//
//         _productsHasMore = items.length >= _productsPageSize;
//         _productsCursorAfter = _productsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyProductFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Products loaded');
//         return _filteredProducts;
//       } else {
//         if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredProducts;
//       }
//     } finally {
//       _productsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Product>> loadMoreProducts({bool showSnack = false}) async {
//     if (_productsLoading || _productsLoadingMore || !_productsHasMore) return _filteredProducts;
//
//     _productsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredProducts;
//
//       await _ensureCategoriesLoadedForProducts();
//       await _ensureSubCategoriesLoadedForProducts();
//
//       final res = await _productsService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _productsPageSize,
//         cursorAfter: _productsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _productsHasMore = false;
//           return _filteredProducts;
//         }
//
//         _hydrateProductsNames(items);
//
//         // ✅ upsert جلوگیری از تکرار
//         for (final p in items) {
//           final id = (p.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allProducts.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allProducts.add(p);
//           } else {
//             _allProducts[idx] = p;
//           }
//         }
//
//         _productsHasMore = items.length >= _productsPageSize;
//         _productsCursorAfter = _productsHasMore ? items.last.sId : null;
//
//         _applyProductFilter();
//         return _filteredProducts;
//       } else {
//         if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredProducts;
//       }
//     } finally {
//       _productsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterProducts(String keyword) {
//     _productKeyword = keyword.trim();
//     _applyProductFilter();
//     notifyListeners();
//   }
//
//   void _applyProductFilter() {
//     _sortAllProducts();
//
//     final kw = _productKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredProducts = List<Product>.from(_allProducts);
//       return;
//     }
//
//     _filteredProducts = _allProducts.where((p) {
//       final name = (p.name ?? '').toLowerCase();
//       final cat = (p.resolvedCategoryName ?? '').toLowerCase();
//       final sub = (p.resolvedSubCategoryName ?? '').toLowerCase();
//       return name.contains(kw) || cat.contains(kw) || sub.contains(kw);
//     }).toList()
//       ..sort((a, b) => _productTs(b).compareTo(_productTs(a)));
//   }
//
// // -------- Hydration (Category/SubCategory names) --------
//
//   Future<void> _ensureCategoriesLoadedForProducts() async {
//     if (_allCategories.isEmpty) {
//       await getAllCategories(showSnack: false);
//     }
//   }
//
//   Future<void> _ensureSubCategoriesLoadedForProducts() async {
//     if (_allSubCategories.isEmpty) {
//       await getAllSubCategories(showSnack: false);
//     }
//   }
//
//   void _hydrateProductsNames(List<Product> products) {
//     if (products.isEmpty) return;
//
//     final catMap = <String, String>{};
//     for (final c in _allCategories) {
//       final id = (c.sId ?? '').trim();
//       if (id.isNotEmpty) catMap[id] = (c.name ?? '').trim();
//     }
//
//     final subMap = <String, String>{};
//     for (final s in _allSubCategories) {
//       final id = (s.sId ?? '').trim();
//       if (id.isNotEmpty) subMap[id] = (s.name ?? '').trim();
//     }
//
//     for (final p in products) {
//       final cid = (p.categoryId ?? '').trim();
//       final sid = (p.subCategoryId ?? '').trim();
//       p.resolvedCategoryName = catMap[cid] ?? '';
//       p.resolvedSubCategoryName = subMap[sid] ?? '';
//     }
//   }
// //////////////////////////////////////////////////Product//////////////////////////////////////////////////
// // ================================
// // ✅ COUPONS (Paging + Shimmer + Updated first)
// // ================================
//   //////////////////////////////////////////////////coupons//////////////////////////////////////////////////
//   static const int _couponsPageSize = 17;
//
//   bool _couponsLoading = false;
//   bool _couponsLoadingMore = false;
//   bool _couponsHasMore = true;
//
//   String? _couponsCursorAfter;
//   String _couponKeyword = '';
//
//   bool get isCouponsLoading => _couponsLoading;
//   bool get isCouponsLoadingMore => _couponsLoadingMore;
//   bool get hasMoreCoupons => _couponsHasMore;
//
//   DateTime _couponTs(Coupon c) {
//     final u = (c.updatedAt ?? '').trim();
//     final cr = (c.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : cr;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllCoupons() {
//     _allCoupons.sort((a, b) => _couponTs(b).compareTo(_couponTs(a)));
//   }
//
//   void _applyCouponFilter() {
//     _sortAllCoupons();
//
//     final kw = _couponKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredCoupons = List<Coupon>.from(_allCoupons);
//       return;
//     }
//
//     _filteredCoupons = _allCoupons
//         .where((c) => (c.couponCode ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _couponTs(b).compareTo(_couponTs(a)));
//   }
//
//   Future<List<Coupon>> getAllCoupons({bool showSnack = false}) async {
//     return loadInitialCoupons(showSnack: showSnack);
//   }
//
//   Future<List<Coupon>> loadInitialCoupons({bool showSnack = false}) async {
//     if (_couponsLoading) return _filteredCoupons;
//
//     _couponsLoading = true;
//     _couponsLoadingMore = false;
//     _couponsHasMore = true;
//     _couponsCursorAfter = null;
//
//     _allCoupons.clear();
//     _filteredCoupons = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredCoupons;
//
//       final res = await _couponService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _couponsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         _allCoupons.addAll(items);
//
//         _couponsHasMore = items.length >= _couponsPageSize;
//         _couponsCursorAfter = _couponsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyCouponFilter();
//         return _filteredCoupons;
//       } else {
//         if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredCoupons;
//       }
//     } finally {
//       _couponsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Coupon>> loadMoreCoupons({bool showSnack = false}) async {
//     if (_couponsLoading || _couponsLoadingMore || !_couponsHasMore) {
//       return _filteredCoupons;
//     }
//
//     _couponsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredCoupons;
//
//       final res = await _couponService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _couponsPageSize,
//         cursorAfter: _couponsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         if (items.isEmpty) {
//           _couponsHasMore = false;
//           return _filteredCoupons;
//         }
//
//         // upsert جلوگیری از تکرار
//         for (final c in items) {
//           final id = (c.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allCoupons.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allCoupons.add(c);
//           } else {
//             _allCoupons[idx] = c;
//           }
//         }
//
//         _couponsHasMore = items.length >= _couponsPageSize;
//         _couponsCursorAfter = _couponsHasMore ? items.last.sId : null;
//
//         _applyCouponFilter();
//         return _filteredCoupons;
//       } else {
//         if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredCoupons;
//       }
//     } finally {
//       _couponsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterCoupons(String keyword) {
//     _couponKeyword = keyword.trim();
//     _applyCouponFilter();
//     notifyListeners();
//   }
//   //////////////////////////////////////////////////coupons//////////////////////////////////////////////////
//
//   //////////////////////////////////////////////////brands//////////////////////////////////////////////////
//
//
//   static const int _brandsPageSize = 17;
//
//   bool _brandsLoading = false;
//   bool _brandsLoadingMore = false;
//   bool _brandsHasMore = true;
//
//   String? _brandsCursorAfter;
//   final Set<String> _loadedBrandIds = {};
//
//   String _brandKeyword = '';
//
//   bool get isBrandsLoading => _brandsLoading;
//   bool get isBrandsLoadingMore => _brandsLoadingMore;
//   bool get hasMoreBrands => _brandsHasMore;
//
// // --- Sort helper: newest updatedAt/createdAt first ---
//   DateTime _brandTs(Brand b) {
//     final u = (b.updatedAt ?? '').trim();
//     final c = (b.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllBrands() {
//     _allBrands.sort((a, b) => _brandTs(b).compareTo(_brandTs(a))); // DESC
//   }
//
//   /// ✅ create/update برند => بیاد اول (بدون reload)
//   void upsertBrandToTop(Brand incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allBrands.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allBrands.removeAt(idx);
//
//     _allBrands.insert(0, incoming);
//
//     _applyBrandFilter();
//     notifyListeners();
//   }
//
//   /// ✅ حذف از لیست (بعد از delete)
//   void removeBrandById(String id) {
//     final sid = id.trim();
//     if (sid.isEmpty) return;
//
//     _allBrands.removeWhere((b) => (b.sId ?? '').trim() == sid);
//     _applyBrandFilter();
//     notifyListeners();
//   }
//
// // -------- SubCategory cache for brands (برای اینکه نام زیر‌دسته همیشه بیاد) --------
//   final Map<String, SubCategory> _scCacheForBrands = {};
//   String? _scCachePhoneForBrands;
//
//   Future<void> _ensureSubCategoryCacheForBrands(String phone, List<Brand> brands) async {
//     if (_scCachePhoneForBrands != phone) {
//       _scCachePhoneForBrands = phone;
//       _scCacheForBrands.clear();
//     }
//
//     // seed from already loaded subcategories
//     for (final sc in _allSubCategories) {
//       final id = (sc.sId ?? '').trim();
//       if (id.isNotEmpty) _scCacheForBrands[id] = sc;
//     }
//
//     final missing = <String>{};
//     for (final b in brands) {
//       final subId = (b.subcategory ?? b.subcategoriesId ?? b.subCategoryId?.sId ?? '').toString().trim();
//       if (subId.isNotEmpty && !_scCacheForBrands.containsKey(subId)) {
//         missing.add(subId);
//       }
//     }
//
//     // fetch missing ones (page size کوچیکه، مشکلی نیست)
//     for (final id in missing) {
//       final res = await _subCategoryService.getById(id);
//       if (res.isSuccess) {
//         final sc = res.requireData();
//         final sid = (sc.sId ?? '').trim();
//         if (sid.isNotEmpty) _scCacheForBrands[sid] = sc;
//       }
//     }
//   }
//
//   void _hydrateBrandsWithSubCategoryNames(List<Brand> brands) {
//     for (final b in brands) {
//       final subId = (b.subcategory ?? b.subcategoriesId ?? b.subCategoryId?.sId ?? '').toString().trim();
//       if (subId.isEmpty) continue;
//
//       final sc = _scCacheForBrands[subId];
//       if (sc == null) continue;
//
//       b.subCategoryId = SubcategoryId(
//         sId: sc.sId,
//         name: sc.name,
//       );
//     }
//   }
//
//   void filterBrands(String keyword) {
//     _brandKeyword = keyword.trim();
//     _applyBrandFilter();
//     notifyListeners();
//   }
//
//   Future<List<Brand>> getAllBrands({bool showSnack = false}) async {
//     return loadInitialBrands(showSnack: showSnack);
//   }
//
//   Future<List<Brand>> loadInitialBrands({bool showSnack = false}) async {
//     if (_brandsLoading) return _filteredBrands;
//
//     _brandsLoading = true;
//     _brandsLoadingMore = false;
//     _brandsHasMore = true;
//     _brandsCursorAfter = null;
//     _loadedBrandIds.clear();
//
//     _allBrands.clear();
//     _filteredBrands = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         return _filteredBrands;
//       }
//
//       // حداقل صفحه اول subcategories برای dropdownها
//       await _ensureSubCategoriesLoadedForBrands();
//
//       final res = await brandsRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _brandsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         await _ensureSubCategoryCacheForBrands(phone.trim(), items);
//         _hydrateBrandsWithSubCategoryNames(items);
//
//         _allBrands.addAll(items);
//
//         _brandsHasMore = items.length >= _brandsPageSize;
//         _brandsCursorAfter = _brandsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyBrandFilter();
//         notifyListeners();
//
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Brands loaded');
//         return _filteredBrands;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredBrands;
//       }
//     } finally {
//       _brandsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Brand>> loadMoreBrands({bool showSnack = false}) async {
//     if (_brandsLoading || _brandsLoadingMore || !_brandsHasMore) return _filteredBrands;
//
//     _brandsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredBrands;
//
//       final res = await brandsRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _brandsPageSize,
//         cursorAfter: _brandsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         if (items.isEmpty) {
//           _brandsHasMore = false;
//           return _filteredBrands;
//         }
//
//         await _ensureSubCategoriesLoadedForBrands();
//         await _ensureSubCategoryCacheForBrands(phone.trim(), items);
//         _hydrateBrandsWithSubCategoryNames(items);
//
//         // upsert + جلوگیری از تکرار
//         for (final b in items) {
//           final id = (b.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allBrands.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allBrands.add(b);
//           } else {
//             _allBrands[idx] = b;
//           }
//           _loadedBrandIds.add(id);
//         }
//
//         _brandsHasMore = items.length >= _brandsPageSize;
//         _brandsCursorAfter = _brandsHasMore ? items.last.sId : null;
//
//         _applyBrandFilter();
//         return _filteredBrands;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredBrands;
//       }
//     } finally {
//       _brandsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   Future<void> _ensureSubCategoriesLoadedForBrands() async {
//     if (_allSubCategories.isEmpty) {
//       await getAllSubCategories(showSnack: false);
//     }
//   }
//
//   void _applyBrandFilter() {
//     _sortAllBrands();
//
//     final kw = _brandKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredBrands = List<Brand>.from(_allBrands);
//       return;
//     }
//
//     _filteredBrands = _allBrands
//         .where((b) => (b.name ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _brandTs(b).compareTo(_brandTs(a)));
//   }
//   //////////////////////////////////////////////////brands//////////////////////////////////////////////////
//
//
//
// //////////////////////////////////////////////////POSTERS//////////////////////////////////////////////////
// // ================================
// // ✅ POSTERS (Paging + Shimmer)
// // ================================
//
// // --- Sort helper: newest updatedAt/createdAt first ---
//   DateTime _posterTs(Poster p) {
//     final u = (p.updatedAt ?? '').trim();
//     final c = (p.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllPosters() {
//     _allPosters.sort((a, b) => _posterTs(b).compareTo(_posterTs(a))); // DESC
//   }
//
//   /// ✅ create/update => بیاد اول (بدون نیاز به reload)
//   void upsertPosterToTop(Poster incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     // اگر updatedAt از سرور نیومده بود، برای نمایش درست
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allPosters.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allPosters.removeAt(idx);
//
//     _allPosters.insert(0, incoming);
//
//     _applyPosterFilter();
//     notifyListeners();
//   }
//
//   static const int _postersPageSize = 17;
//
//   bool _postersLoading = false;
//   bool _postersLoadingMore = false;
//   bool _postersHasMore = true;
//
//   String? _postersCursorAfter;
//   String _posterKeyword = '';
//
//   bool get isPostersLoading => _postersLoading;
//   bool get isPostersLoadingMore => _postersLoadingMore;
//   bool get hasMorePosters => _postersHasMore;
//
//   Future<List<Poster>> getAllPosters({bool showSnack = false}) async {
//     return loadInitialPosters(showSnack: showSnack);
//   }
//
//   Future<List<Poster>> loadInitialPosters({bool showSnack = false}) async {
//     if (_postersLoading) return _filteredPosters;
//
//     _postersLoading = true;
//     _postersLoadingMore = false;
//     _postersHasMore = true;
//     _postersCursorAfter = null;
//
//     _allPosters.clear();
//     _filteredPosters = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//         return _filteredPosters;
//       }
//
//       final res = await _posterService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _postersPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _allPosters.addAll(items);
//
//         _postersHasMore = items.length >= _postersPageSize;
//         _postersCursorAfter =
//         _postersHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyPosterFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('پوسترها لود شدند');
//         return _filteredPosters;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredPosters;
//       }
//     } finally {
//       _postersLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Poster>> loadMorePosters({bool showSnack = false}) async {
//     if (_postersLoading || _postersLoadingMore || !_postersHasMore) {
//       return _filteredPosters;
//     }
//
//     _postersLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredPosters;
//
//       final res = await _posterService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _postersPageSize,
//         cursorAfter: _postersCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _postersHasMore = false;
//           return _filteredPosters;
//         }
//
//         // upsert + جلوگیری از تکرار
//         for (final p in items) {
//           final id = (p.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allPosters.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allPosters.add(p);
//           } else {
//             _allPosters[idx] = p;
//           }
//         }
//
//         _postersHasMore = items.length >= _postersPageSize;
//         _postersCursorAfter = _postersHasMore ? items.last.sId : null;
//
//         _applyPosterFilter();
//         return _filteredPosters;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredPosters;
//       }
//     } finally {
//       _postersLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterPosters(String keyword) {
//     _posterKeyword = keyword.trim();
//     _applyPosterFilter();
//     notifyListeners();
//   }
//
//   void _applyPosterFilter() {
//     _sortAllPosters();
//
//     final kw = _posterKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredPosters = List<Poster>.from(_allPosters);
//       return;
//     }
//
//     _filteredPosters = _allPosters
//         .where((p) => (p.posterName ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _posterTs(b).compareTo(_posterTs(a)));
//   }
// //////////////////////////////////////////////////VARIANTS//////////////////////////////////////////////////
//   // ================================
// // ✅ VARIANTS (Paging + Shimmer + Hydration by VariantTypes)
// // ================================
//   static const int _variantsPageSize = 17;
//
//   bool _variantsLoading = false;
//   bool _variantsLoadingMore = false;
//   bool _variantsHasMore = true;
//
//   String? _variantsCursorAfter;
//   String _variantKeyword = '';
//
//   bool get isVariantsLoading => _variantsLoading;
//   bool get isVariantsLoadingMore => _variantsLoadingMore;
//   bool get hasMoreVariants => _variantsHasMore;
//
// // cache برای map کردن نام تایپ‌ها
//   Map<String, VariantType> _vtMapForVariants = {};
//   String? _vtMapPhoneForVariants;
//
//   Future<void> _ensureVariantTypeMapForVariants(String phone) async {
//     if (_vtMapPhoneForVariants == phone && _vtMapForVariants.isNotEmpty) return;
//
//     final allVts = await _getVariantTypesForHydration(phone);
//     final map = <String, VariantType>{};
//     for (final vt in allVts) {
//       final id = (vt.sId ?? '').trim();
//       if (id.isNotEmpty) map[id] = vt;
//     }
//
//     _vtMapForVariants = map;
//     _vtMapPhoneForVariants = phone;
//   }
//
//   void _hydrateVariantsTypeNames(List<Variant> vars) {
//     if (_vtMapForVariants.isEmpty) return;
//
//     for (final v in vars) {
//       final vtId = (v.variantType ?? v.variantTypeId?.sId ?? '').trim();
//       if (vtId.isEmpty) continue;
//
//       final vt = _vtMapForVariants[vtId];
//       if (vt == null) continue;
//
//       v.variantTypeId = VariantTypeId(
//         sId: vt.sId,
//         name: vt.name,
//         type: vt.type,
//       );
//     }
//   }
//
//   Future<List<Variant>> getAllVariants({bool showSnack = false}) async {
//     return loadInitialVariants(showSnack: showSnack);
//   }
//
//   Future<List<Variant>> loadInitialVariants({bool showSnack = false}) async {
//     if (_variantsLoading) return _filteredVariants;
//
//     _variantsLoading = true;
//     _variantsLoadingMore = false;
//     _variantsHasMore = true;
//     _variantsCursorAfter = null;
//
//     _allVariants.clear();
//     _filteredVariants = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) {
//           SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         }
//         return _filteredVariants;
//       }
//
//       // ✅ برای اینکه اسم تایپ‌ها همیشه درست hydrate بشه (حتی اگر VariantTypes صفحه‌بندی شده باشد)
//       await _ensureVariantTypeMapForVariants(phone.trim());
//
//       final res = await variantsRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _variantsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _hydrateVariantsTypeNames(items);
//
//         _allVariants.addAll(items);
//
//         _variantsHasMore = items.length >= _variantsPageSize;
//         _variantsCursorAfter =
//         _variantsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyVariantFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Variants loaded');
//         return _filteredVariants;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredVariants;
//       }
//     } finally {
//       _variantsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Variant>> loadMoreVariants({bool showSnack = false}) async {
//     if (_variantsLoading || _variantsLoadingMore || !_variantsHasMore) {
//       return _filteredVariants;
//     }
//
//     _variantsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredVariants;
//
//       await _ensureVariantTypeMapForVariants(phone.trim());
//
//       final res = await variantsRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _variantsPageSize,
//         cursorAfter: _variantsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _variantsHasMore = false;
//           return _filteredVariants;
//         }
//
//         _hydrateVariantsTypeNames(items);
//
//         // upsert + جلوگیری از تکرار
//         for (final v in items) {
//           final id = (v.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allVariants.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allVariants.add(v);
//           } else {
//             _allVariants[idx] = v;
//           }
//         }
//
//         _variantsHasMore = items.length >= _variantsPageSize;
//         _variantsCursorAfter = _variantsHasMore ? items.last.sId : null;
//
//         _applyVariantFilter();
//         return _filteredVariants;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredVariants;
//       }
//     } finally {
//       _variantsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
// // ✅ فیلتر (مثل بقیه paging ها)
//   void filterVariants(String keyword) {
//     _variantKeyword = keyword.trim();
//     _applyVariantFilter();
//     notifyListeners();
//   }
//
//   void _applyVariantFilter() {
//     final kw = _variantKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredVariants = List<Variant>.from(_allVariants);
//       return;
//     }
//
//     _filteredVariants = _allVariants
//         .where((v) => (v.name ?? '').toLowerCase().contains(kw))
//         .toList();
//   }
// //////////////////////////////////////////////////VARIANTS//////////////////////////////////////////////////
// //////////////////////////////////////////////////variantTypes//////////////////////////////////////////////////
// // ================================
// // ✅ VARIANT TYPES (Paging + Shimmer + Updated items first)
// // ================================
//   static const int _variantTypesPageSize = 17;
//
//   bool _variantTypesLoading = false;
//   bool _variantTypesLoadingMore = false;
//   bool _variantTypesHasMore = true;
//
//   String? _variantTypesCursorAfter;
//   String _variantTypeKeyword = '';
//
//   bool get isVariantTypesLoading => _variantTypesLoading;
//   bool get isVariantTypesLoadingMore => _variantTypesLoadingMore;
//   bool get hasMoreVariantTypes => _variantTypesHasMore;
//
// // --- Sort helper: newest updatedAt/createdAt first ---
//   DateTime _vtTs(VariantType v) {
//     final u = (v.updatedAt ?? '').trim();
//     final c = (v.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllVariantTypes() {
//     _allVariantTypes.sort((a, b) => _vtTs(b).compareTo(_vtTs(a))); // DESC
//   }
//
//   /// ✅ create/update => بیاد اول (بدون نیاز به reload)
//   void upsertVariantTypeToTop(VariantType incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     // اگر updatedAt از سرور نیومده بود، برای نمایش درست
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allVariantTypes.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allVariantTypes.removeAt(idx);
//
//     _allVariantTypes.insert(0, incoming);
//
//     _applyVariantTypeFilter();
//     notifyListeners();
//   }
//
//   Future<List<VariantType>> getAllVariantTypes({bool showSnack = false}) async {
//     return loadInitialVariantTypes(showSnack: showSnack);
//   }
//
//   Future<List<VariantType>> loadInitialVariantTypes({bool showSnack = false}) async {
//     if (_variantTypesLoading) return _filteredVariantTypes;
//
//     _variantTypesLoading = true;
//     _variantTypesLoadingMore = false;
//     _variantTypesHasMore = true;
//     _variantTypesCursorAfter = null;
//
//     _allVariantTypes.clear();
//     _filteredVariantTypes = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) {
//           SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         }
//         return _filteredVariantTypes;
//       }
//
//       final res = await variantTypesRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _variantTypesPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _allVariantTypes.addAll(items);
//
//         _variantTypesHasMore = items.length >= _variantTypesPageSize;
//         _variantTypesCursorAfter =
//         _variantTypesHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyVariantTypeFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Variant types loaded');
//         return _filteredVariantTypes;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredVariantTypes;
//       }
//     } finally {
//       _variantTypesLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<VariantType>> loadMoreVariantTypes({bool showSnack = false}) async {
//     if (_variantTypesLoading || _variantTypesLoadingMore || !_variantTypesHasMore) {
//       return _filteredVariantTypes;
//     }
//
//     _variantTypesLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredVariantTypes;
//
//       final res = await variantTypesRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _variantTypesPageSize,
//         cursorAfter: _variantTypesCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _variantTypesHasMore = false;
//           return _filteredVariantTypes;
//         }
//
//         // upsert + جلوگیری از تکرار
//         for (final vt in items) {
//           final id = (vt.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allVariantTypes.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allVariantTypes.add(vt);
//           } else {
//             _allVariantTypes[idx] = vt;
//           }
//         }
//
//         _variantTypesHasMore = items.length >= _variantTypesPageSize;
//         _variantTypesCursorAfter = _variantTypesHasMore ? items.last.sId : null;
//
//         _applyVariantTypeFilter();
//         return _filteredVariantTypes;
//       } else {
//         final err = res.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredVariantTypes;
//       }
//     } finally {
//       _variantTypesLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterVariantTypes(String keyword) {
//     _variantTypeKeyword = keyword.trim();
//     _applyVariantTypeFilter();
//     notifyListeners();
//   }
//
//   void _applyVariantTypeFilter() {
//     _sortAllVariantTypes();
//
//     final kw = _variantTypeKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredVariantTypes = List<VariantType>.from(_allVariantTypes);
//       return;
//     }
//
//     _filteredVariantTypes = _allVariantTypes
//         .where((v) => (v.name ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _vtTs(b).compareTo(_vtTs(a)));
//   }
//
//   /// ✅ برای اینکه mapping داخل getAllVariants خراب نشه (اگر VariantTypes صفحه‌بندی شد)
//   Future<List<VariantType>> _getVariantTypesForHydration(String phone) async {
//     final res = await variantTypesRepoAppwrite.getByPhoneNumberCode(phone);
//     if (res.isSuccess) return res.requireData();
//     return _allVariantTypes;
//   }
//
// // ================================
// // ✅ VARIANT TYPES (Paging + Shimmer + Updated items first)
// // ================================
//
// //////////////////////////////////////////////////variantTypes//////////////////////////////////////////////////
//   //////////////////////////////////////////////////SUBCATEGORIES//////////////////////////////////////////////////
// // ================================
// // ✅ SUBCATEGORIES (Paging + Updated items first)
// // ================================
//   static const int _subCategoriesPageSize = 17;
//
//   bool _subCategoriesLoading = false;
//   bool _subCategoriesLoadingMore = false;
//   bool _subCategoriesHasMore = true;
//
//   String? _subCategoriesCursorAfter;
//   String _subCategoryKeyword = '';
//
//   bool get isSubCategoriesLoading => _subCategoriesLoading;
//   bool get isSubCategoriesLoadingMore => _subCategoriesLoadingMore;
//   bool get hasMoreSubCategories => _subCategoriesHasMore;
//
// // --- Sort helper: newest updatedAt/createdAt first ---
//   DateTime _subTs(SubCategory s) {
//     final raw = (s.updatedAt ?? '').trim().isNotEmpty ? s.updatedAt! : (s.createdAt ?? '');
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllSubCategories() {
//     _allSubCategories.sort((a, b) => _subTs(b).compareTo(_subTs(a))); // DESC
//   }
//
// // ✅ ایجاد یا بروزرسانی زیر‌دسته و آوردن به اول (با مرتب‌سازی بر اساس updatedAt)
//   void upsertSubCategoryToTop(SubCategory incoming) {
//     final id = (incoming.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     // اگر updatedAt از سرور نیومده بود، برای نمایش درست، همین‌جا ست می‌کنیم
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allSubCategories.indexWhere((x) => (x.sId ?? '').trim() == id);
//     if (idx != -1) _allSubCategories.removeAt(idx);
//
//     _allSubCategories.insert(0, incoming);
//
//     _applySubCategoryFilter(); // داخلش sort هم انجام میشه
//     notifyListeners();
//   }
//
// // ✅ (اختیاری ولی کاربردی) create/update که خودش بعد از موفقیت میاره اول
//   Future<void> createSubCategory({
//     required String name,
//     required String categoryId,
//     bool showSnack = false,
//   }) async {
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     if (phone.trim().isEmpty) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//       return;
//     }
//
//     final res = await _subCategoryService.createSubCategory(
//       name: name.trim(),
//       phoneNumberCode: phone.trim(),
//       categoryId: categoryId,
//     );
//
//     if (res.isSuccess) {
//       final saved = res.requireData();
//       upsertSubCategoryToTop(saved);
//       if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategory created');
//     } else {
//       if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//     }
//   }
//
//   Future<void> updateSubCategory({
//     required String documentId,
//     required String name,
//     required String categoryId,
//     bool showSnack = false,
//   }) async {
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     if (phone.trim().isEmpty) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//       return;
//     }
//
//     final res = await _subCategoryService.updateSubCategory(
//       documentId: documentId,
//       name: name.trim(),
//       phoneNumberCode: phone.trim(),
//       categoryId: categoryId,
//     );
//
//     if (res.isSuccess) {
//       final saved = res.requireData();
//       upsertSubCategoryToTop(saved); // ✅ همین باعث میشه آپدیت بیاد اول
//       if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategory updated');
//     } else {
//       if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//     }
//   }
//
//   Future<void> deleteSubCategory(SubCategory sub, {bool showSnack = false}) async {
//     final id = (sub.sId ?? '').trim();
//     if (id.isEmpty) return;
//
//     final res = await _subCategoryService.deleteSubCategory(documentId: id);
//     if (res.isSuccess) {
//       _allSubCategories.removeWhere((x) => (x.sId ?? '').trim() == id);
//       _applySubCategoryFilter();
//       notifyListeners();
//       if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategory deleted');
//     } else {
//       if (showSnack) SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//     }
//   }
//
// // ✅ لود اولیه
//   Future<List<SubCategory>> getAllSubCategories({bool showSnack = false}) async {
//     return loadInitialSubCategories(showSnack: showSnack);
//   }
//
//   Future<List<SubCategory>> loadInitialSubCategories({bool showSnack = false}) async {
//     if (_subCategoriesLoading) return _filteredSubCategories;
//
//     _subCategoriesLoading = true;
//     _subCategoriesLoadingMore = false;
//     _subCategoriesHasMore = true;
//     _subCategoriesCursorAfter = null;
//
//     _allSubCategories.clear();
//     _filteredSubCategories = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//         return _filteredSubCategories;
//       }
//
//       final result = await _subCategoryService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _subCategoriesPageSize,
//         cursorAfter: null,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//         _allSubCategories.addAll(items);
//
//         _subCategoriesHasMore = items.length >= _subCategoriesPageSize;
//         _subCategoriesCursorAfter =
//         _subCategoriesHasMore ? (items.isNotEmpty ? items.last.sId : null) : null;
//
//         _applySubCategoryFilter(); // ✅ includes sort (updated first)
//         notifyListeners();
//
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategories loaded');
//         return _filteredSubCategories;
//       } else {
//         final err = result.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredSubCategories;
//       }
//     } finally {
//       _subCategoriesLoading = false;
//       notifyListeners();
//     }
//   }
//
// // ✅ لود بیشتر (Paging)
//   Future<List<SubCategory>> loadMoreSubCategories({bool showSnack = false}) async {
//     if (_subCategoriesLoading || _subCategoriesLoadingMore || !_subCategoriesHasMore) {
//       return _filteredSubCategories;
//     }
//
//     _subCategoriesLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredSubCategories;
//
//       final result = await _subCategoryService.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _subCategoriesPageSize,
//         cursorAfter: _subCategoriesCursorAfter,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//
//         if (items.isEmpty) {
//           _subCategoriesHasMore = false;
//           return _filteredSubCategories;
//         }
//
//         // upsert (بدون تغییر ترتیب دستی؛ ترتیب با sort درست میشه)
//         for (final s in items) {
//           final id = (s.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allSubCategories.indexWhere((x) => (x.sId ?? '').trim() == id);
//           if (idx == -1) {
//             _allSubCategories.add(s);
//           } else {
//             _allSubCategories[idx] = s;
//           }
//         }
//
//         _subCategoriesHasMore = items.length >= _subCategoriesPageSize;
//         _subCategoriesCursorAfter = _subCategoriesHasMore ? items.last.sId : null;
//
//         _applySubCategoryFilter(); // ✅ includes sort (updated first)
//         return _filteredSubCategories;
//       } else {
//         final err = result.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredSubCategories;
//       }
//     } finally {
//       _subCategoriesLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
// // ✅ فیلتر
//   void filterSubCategories(String keyword) {
//     _subCategoryKeyword = keyword.trim();
//     _applySubCategoryFilter();
//     notifyListeners();
//   }
//
// // ✅ اعمال فیلتر + مرتب‌سازی (آپدیت‌ها اول)
//   void _applySubCategoryFilter() {
//     _sortAllSubCategories();
//
//     final kw = _subCategoryKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredSubCategories = List<SubCategory>.from(_allSubCategories);
//       return;
//     }
//
//     _filteredSubCategories = _allSubCategories
//         .where((s) => (s.name ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _subTs(b).compareTo(_subTs(a))); // برای حالت فیلتر هم
//   }
//
//
// // ================================
// // ✅ SUBCATEGORIES PAGING (Appwrite)
// // ================================
//
//   //////////////////////////////////////////////////SUBCATEGORIES//////////////////////////////////////////////////
//   //////////////////////////////////////////////////CATEGORIES//////////////////////////////////////////////////
//
//
//   Future<List<Category>> getAllCategories({bool showSnack = false}) async {
//     return loadInitialCategories(showSnack: showSnack);
//   }
//
//   Future<List<Category>> loadInitialCategories({bool showSnack = false}) async {
//     if (_categoriesLoading) return _filteredCategories;
//
//     _categoriesLoading = true;
//     _categoriesLoadingMore = false;
//     _categoriesHasMore = true;
//     _categoriesCursorAfter = null;
//
//     _allCategories.clear();
//     _filteredCategories = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) {
//         if (showSnack) {
//           SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//         }
//         return _filteredCategories;
//       }
//
//       final result = await categoriesRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _categoriesPageSize,
//         cursorAfter: null,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//
//         _allCategories.addAll(items);
//
//         _categoriesHasMore = items.length >= _categoriesPageSize;
//         _categoriesCursorAfter =
//         _categoriesHasMore ? (items.isNotEmpty ? items.last.sId : null) : null;
//
//         _applyCategoryFilter();
//         notifyListeners();
//
//         if (showSnack) {
//           SnackBarHelper.showSuccessSnackBar('دسته‌بندی‌ها بروزرسانی شدند');
//         }
//
//         return _filteredCategories;
//       } else {
//         final error = result.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(error.userMessage);
//         return _filteredCategories;
//       }
//     } catch (e) {
//       if (showSnack) SnackBarHelper.showErrorSnackBar('خطا در لود دسته‌بندی‌ها: $e');
//       rethrow;
//     } finally {
//       _categoriesLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Category>> loadMoreCategories({bool showSnack = false}) async {
//     if (_categoriesLoading || _categoriesLoadingMore || !_categoriesHasMore) {
//       return _filteredCategories;
//     }
//
//     _categoriesLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       if (phone.trim().isEmpty) return _filteredCategories;
//
//       final result = await categoriesRepoAppwrite.getPagedByPhoneNumberCode(
//         phone.trim(),
//         limit: _categoriesPageSize,
//         cursorAfter: _categoriesCursorAfter,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//
//         if (items.isEmpty) {
//           _categoriesHasMore = false;
//           return _filteredCategories;
//         }
//
//         // جلوگیری از تکرار (simple)
//         for (final c in items) {
//           final id = (c.sId ?? '').trim();
//           if (id.isEmpty) continue;
//
//           final idx = _allCategories.indexWhere((x) => (x.sId ?? '') == id);
//           if (idx == -1) {
//             _allCategories.add(c);
//           } else {
//             _allCategories[idx] = c;
//           }
//         }
//
//         _categoriesHasMore = items.length >= _categoriesPageSize;
//         _categoriesCursorAfter = _categoriesHasMore ? items.last.sId : null;
//
//         _applyCategoryFilter();
//         return _filteredCategories;
//       } else {
//         final err = result.requireError();
//         if (showSnack) SnackBarHelper.showErrorSnackBar(err.userMessage);
//         return _filteredCategories;
//       }
//     } finally {
//       _categoriesLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterCategories(String keyword) {
//     _categoryKeyword = keyword.trim();
//     _applyCategoryFilter();
//     notifyListeners();
//   }
//
//   void _applyCategoryFilter() {
//     final kw = _categoryKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredCategories = List<Category>.from(_allCategories);
//       return;
//     }
//
//     _filteredCategories = _allCategories
//         .where((c) => (c.name ?? '').toLowerCase().contains(kw))
//         .toList();
//   }
//
//
//   static const int _categoriesPageSize = 17;
//
//   bool _categoriesLoading = false;
//   bool _categoriesLoadingMore = false;
//   bool _categoriesHasMore = true;
//
//   String? _categoriesCursorAfter;
//   String _categoryKeyword = '';
//
//   bool get isCategoriesLoading => _categoriesLoading;
//   bool get isCategoriesLoadingMore => _categoriesLoadingMore;
//   bool get hasMoreCategories => _categoriesHasMore;
//
// //////////////////////////////////////////////////CATEGORIES//////////////////////////////////////////////////
//
//
//
// }

//
// import 'package:admin/config/environment.dart';
// import 'package:admin/config/network/realtime_manager.dart';
// import 'package:admin/core/data/appwrite/brands_repository.dart';
// import 'package:admin/core/data/appwrite/coupon_code_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/orders_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/products_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/sub_category_appwrite_service.dart';
// import 'package:admin/core/data/appwrite/variant_types_repository.dart';
// import 'package:admin/core/data/appwrite/variants_repository.dart';
// import 'package:admin/utility/User_helper.dart';
// import 'package:admin/utility/snack_bar_helper.dart';
// import 'package:flutter/foundation.dart' hide Category;
// import '../../../models/category.dart';
// import '../../models/brand.dart';
// import '../../models/coupon.dart';
// import '../../models/order.dart';
// import '../../models/poster.dart';
// import '../../models/product.dart';
// import '../../models/sub_category.dart';
// import '../../models/variant.dart';
// import '../../models/variant_type.dart';
// import '../../utility/constants.dart';
// import 'dart:async';
// import 'appwrite/categories_repository.dart';
// import 'appwrite/poster_appwrite_service.dart';
//
// class DataProvider extends ChangeNotifier {
//   // =========================================================
//   // Utils
//   // =========================================================
//   String _s(Object? v) => (v ?? '').toString().trim();
//
//   int? _tryInt(dynamic v) {
//     if (v == null) return null;
//     if (v is int) return v;
//     final s = v.toString().trim();
//     if (s.isEmpty) return null;
//     return int.tryParse(s);
//   }
//
//   // =========================================================
//   // Debounced notify
//   // =========================================================
//   Timer? _notifyDebounce;
//
//   void _safeNotify() {
//     _notifyDebounce?.cancel();
//     _notifyDebounce = Timer(const Duration(milliseconds: 120), notifyListeners);
//   }
//
//   // =========================================================
//   // Realtime helpers (robust)
//   // =========================================================
//   String? _extractDocIdFromEvents(List<String>? events) {
//     if (events == null || events.isEmpty) return null;
//     for (final e in events) {
//       final i = e.indexOf('.documents.');
//       if (i == -1) continue;
//       final tail = e.substring(i + '.documents.'.length);
//       final dot = tail.indexOf('.');
//       if (dot == -1) continue;
//       final id = tail.substring(0, dot).trim();
//       if (id.isNotEmpty) return id;
//     }
//     return null;
//   }
//
//   bool _isDeleteEvent<T>(RealtimeEvent<T> event) {
//     return event.action == RealtimeAction.delete ||
//         event.events.any((e) => e.endsWith('.delete'));
//   }
//
//   String? _getDocumentIdGeneric<T>(
//       RealtimeEvent<T> event, {
//         required String Function(T data) idOf,
//       }) {
//     final direct = _s(event.documentId);
//     if (direct.isNotEmpty) return direct;
//
//     final fromEvents = _extractDocIdFromEvents(event.events);
//     if (_s(fromEvents).isNotEmpty) return fromEvents!.trim();
//
//     final data = event.data;
//     if (data != null) {
//       final fallback = _s(idOf(data));
//       if (fallback.isNotEmpty) return fallback;
//     }
//     return null;
//   }
//   DataProvider() {
//     initAll(); // ✅ همین خط همه چیز رو حل می‌کنه
//   }
//   // =========================================================
//   // Normalization for Order realtime JSON
//   // =========================================================
//   Map<String, dynamic> _normalizeOrderRealtimeJson(Map<String, dynamic> json) {
//     final m = Map<String, dynamic>.from(json);
//     m['id'] ??= m[r'$id'];
//     m['sId'] ??= m['id'];
//     m['created'] ??= m[r'$createdAt'];
//     m['createdAt'] ??= m[r'$createdAt'];
//     m['updatedAt'] ??= m[r'$updatedAt'];
//     return m;
//   }
//
//   Order _orderFromRealtime(Map<String, dynamic> json) {
//     return Order.fromJson(_normalizeOrderRealtimeJson(json));
//   }
//
//   bool _isPaidStatus(String? s) => (s ?? '').trim().toLowerCase() == 'paid';
//
//   // =========================================================
//   // Services / Repos
//   // =========================================================
//   final OrdersAppwriteService ordersAppwriteService = OrdersAppwriteService();
//
//   final CategoriesRepository categoriesRepoAppwrite = CategoriesRepository();
//   final BrandsRepository brandsRepoAppwrite = BrandsRepository();
//   final SubCategoryAppwriteService _subCategoryService =
//   SubCategoryAppwriteService();
//   final VariantTypesRepository variantTypesRepoAppwrite =
//   VariantTypesRepository();
//   final VariantsRepository variantsRepoAppwrite = VariantsRepository();
//   final ProductsAppwriteService _productsService = ProductsAppwriteService();
//   final PosterAppwriteService _posterService = PosterAppwriteService();
//   final CouponCodeAppwriteService _couponService = CouponCodeAppwriteService();
//
//   // =========================================================
//   // Init gating
//   // =========================================================
//   bool _initialized = false;
//
//   Future<void> initAfterLogin() async => initAll();
//
//   Future<bool> _isFullMenu() async {
//     try {
//       final info = await UserSaveHelper.getUserInfo(showError: false);
//       final menuType =
//       (info?['menu_type'] ?? '').toString().trim().toLowerCase();
//       return menuType != 'menu_one';
//     } catch (_) {
//       return true;
//     }
//   }
//
//   // =========================================================
//   // ORDERS (Single realtime -> 2 lists)
//   // =========================================================
//
//   final List<Order> _inProgressOrders = [];
//
//   List<Order> get inProgressOrders => List.unmodifiable(_inProgressOrders);
//
//   final List<Order> _paidOrders = [];
//   List<Order> _filteredPaidOrders = const [];
//
//   List<Order> get paidOrders => _filteredPaidOrders;
//
//   static const int _paidOrdersPageSize = 17;
//   bool _paidOrdersLoading = false;
//   bool _paidOrdersHasMore = true;
//   int _paidOrdersNextPage = 1;
//
//   bool get isPaidOrdersLoading => _paidOrdersLoading;
//
//   bool get hasMorePaidOrders => _paidOrdersHasMore;
//
//   void _sortInProgressOrders() {
//     final epoch = DateTime.fromMillisecondsSinceEpoch(0);
//     _inProgressOrders.sort((a, b) {
//       final aTime = a.updatedAt ?? a.createdAt ?? epoch;
//       final bTime = b.updatedAt ?? b.createdAt ?? epoch;
//       return bTime.compareTo(aTime);
//     });
//   }
//
//   void _sortPaidOrders() {
//     final epoch = DateTime.fromMillisecondsSinceEpoch(0);
//     _paidOrders.sort((a, b) {
//       final aTime = a.updatedAt ?? a.createdAt ?? epoch;
//       final bTime = b.updatedAt ?? b.createdAt ?? epoch;
//       return bTime.compareTo(aTime);
//     });
//   }
//
//   Future<void> getInProgressOrders({bool showSnack = false}) async {
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return;
//
//       final data = await ordersAppwriteService.fetchAllInProgress(
//         phoneNumberCode: phoneCode,
//         batchSize: 200,
//       );
//
//       _inProgressOrders
//         ..clear()
//         ..addAll(data);
//
//       _sortInProgressOrders();
//       notifyListeners();
//     } catch (_) {
//       if (showSnack)
//         SnackBarHelper.showErrorSnackBar('خطا در دریافت سفارشات در جریان');
//     }
//   }
//
//   Future<void> loadInitialPaidOrders({bool showSnack = false}) async {
//     _paidOrders.clear();
//     _filteredPaidOrders = const [];
//     _paidOrdersHasMore = true;
//     _paidOrdersLoading = true;
//     _paidOrdersNextPage = 1;
//     notifyListeners();
//
//     await _loadPaidOrdersPage(_paidOrdersNextPage, showSnack: showSnack);
//   }
//
//   Future<void> loadMorePaidOrders() async {
//     if (_paidOrdersLoading || !_paidOrdersHasMore) return;
//     await _loadPaidOrdersPage(_paidOrdersNextPage);
//   }
//
//   Future<void> _loadPaidOrdersPage(int page, {bool showSnack = false}) async {
//     _paidOrdersLoading = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return;
//
//       final res = await ordersAppwriteService.fetchPaidPaged(
//         phoneNumberCode: phoneCode,
//         page: page,
//         perPage: _paidOrdersPageSize,
//       );
//
//       if (page == 1) _paidOrders.clear();
//
//       // ✅ Upsert برای جلوگیری از تکرار (با realtime)
//       for (final o in res.orders) {
//         final id = _s(o.sId);
//         if (id.isEmpty) continue;
//         final idx = _paidOrders.indexWhere((x) => _s(x.sId) == id);
//         if (idx == -1) {
//           _paidOrders.add(o);
//         } else {
//           _paidOrders[idx] = o;
//         }
//       }
//
//       _sortPaidOrders();
//       _filteredPaidOrders = List.unmodifiable(_paidOrders);
//
//       _paidOrdersHasMore = res.hasMore;
//
//       // ✅ بهتر: فقط وقتی hasMore هست صفحه بعدی
//       _paidOrdersNextPage = _paidOrdersHasMore ? page + 1 : page;
//     } catch (_) {
//       if (showSnack)
//         SnackBarHelper.showErrorSnackBar('خطا در دریافت سفارشات پرداخت شده');
//     } finally {
//       _paidOrdersLoading = false;
//       notifyListeners();
//     }
//   }
//
//   StreamSubscription<RealtimeEvent<Order>>? _ordersRealtimeSub;
//
//   Future<void> _subscribeToOrdersRealtimeSingle() async {
//     await _ordersRealtimeSub?.cancel();
//     _ordersRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Order>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//       fromJson: _orderFromRealtime,
//     );
//
//     _ordersRealtimeSub = stream.listen(
//           (event) {
//         final docId = _getDocumentIdGeneric<Order>(
//           event,
//           idOf: (o) => _s(o.sId),
//         );
//         if (_s(docId).isEmpty) return;
//
//         final id = docId!.trim();
//
//         if (_isDeleteEvent(event)) {
//           _inProgressOrders.removeWhere((o) => _s(o.sId) == id);
//           _paidOrders.removeWhere((o) => _s(o.sId) == id);
//           _filteredPaidOrders = List.unmodifiable(_paidOrders);
//           _safeNotify();
//           return;
//         }
//
//         final order = event.data;
//         if (order == null) return;
//
//         if (_s(order.phoneNumberCode) != phoneCode) return;
//
//         final isPaid = _isPaidStatus(order.orderStatus);
//
//         if (isPaid) {
//           _inProgressOrders.removeWhere((o) => _s(o.sId) == id);
//
//           // ✅ upsert to top (remove + insert)
//           final idx = _paidOrders.indexWhere((o) => _s(o.sId) == id);
//           if (idx != -1) _paidOrders.removeAt(idx);
//           _paidOrders.insert(0, order);
//
//           _sortPaidOrders();
//           _filteredPaidOrders = List.unmodifiable(_paidOrders);
//         } else {
//           _paidOrders.removeWhere((o) => _s(o.sId) == id);
//           _filteredPaidOrders = List.unmodifiable(_paidOrders);
//
//           final idx = _inProgressOrders.indexWhere((o) => _s(o.sId) == id);
//           if (idx == -1) {
//             _inProgressOrders.insert(0, order);
//           } else {
//             _inProgressOrders[idx] = order;
//           }
//
//           _sortInProgressOrders();
//         }
//
//         _safeNotify();
//       },
//       onError: (e, st) {
//         if (kDebugMode) debugPrint('Realtime error (orders): $e\n$st');
//       },
//       cancelOnError: false,
//     );
//   }
//
//   // =========================================================
//   // Realtime for other collections
//   // =========================================================
//   StreamSubscription<RealtimeEvent<Product>>? _productsRealtimeSub;
//   StreamSubscription<RealtimeEvent<Brand>>? _brandsRealtimeSub;
//   StreamSubscription<RealtimeEvent<Coupon>>? _couponsRealtimeSub;
//   StreamSubscription<RealtimeEvent<Poster>>? _postersRealtimeSub;
//   StreamSubscription<RealtimeEvent<Variant>>? _variantsRealtimeSub;
//   StreamSubscription<RealtimeEvent<VariantType>>? _variantTypesRealtimeSub;
//   StreamSubscription<RealtimeEvent<SubCategory>>? _subCategoriesRealtimeSub;
//   StreamSubscription<RealtimeEvent<Category>>? _categoriesRealtimeSub;
//
//   Future<void> _subscribeToProductsRealtime() async {
//     await _productsRealtimeSub?.cancel();
//     _productsRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdProducts,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Product>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdProducts,
//       fromJson: (json) => Product.fromJson(json),
//     );
//
//     _productsRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Product>(
//         event,
//         idOf: (p) => _s(p.sId),
//       );
//       if (_s(docId).isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         removeProductById(docId!);
//         return;
//       }
//
//       final product = event.data;
//       if (product == null) return;
//
//       if (_s(product.phoneNumberCode) != phoneCode) return;
//
//       upsertProductToTop(product);
//     });
//   }
//
//   Future<void> _subscribeToBrandsRealtime() async {
//     await _brandsRealtimeSub?.cancel();
//     _brandsRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdBrands,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Brand>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdBrands,
//       fromJson: (json) => Brand.fromJson(json),
//     );
//
//     _brandsRealtimeSub = stream.listen((event) async {
//       final docId = _getDocumentIdGeneric<Brand>(
//         event,
//         idOf: (b) => _s(b.sId),
//       );
//       if (_s(docId).isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         removeBrandById(docId!);
//         return;
//       }
//
//       final brand = event.data;
//       if (brand == null) return;
//
//       if (_s(brand.phoneNumberCode) != phoneCode) return;
//
//       await _ensureSubCategoriesLoadedForBrands();
//       await _ensureSubCategoryCacheForBrands(phoneCode, [brand]);
//       _hydrateBrandsWithSubCategoryNames([brand]);
//
//       upsertBrandToTop(brand);
//     });
//   }
//
//   Future<void> _subscribeToCouponsRealtime() async {
//     await _couponsRealtimeSub?.cancel();
//     _couponsRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCouponCode,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Coupon>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCouponCode,
//       fromJson: (json) => Coupon.fromJson(json),
//     );
//
//     _couponsRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Coupon>(
//         event,
//         idOf: (c) => _s(c.sId),
//       );
//       if (_s(docId).isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allCoupons.removeWhere((c) => _s(c.sId) == docId);
//         _applyCouponFilter();
//         _safeNotify();
//         return;
//       }
//
//       final coupon = event.data;
//       if (coupon == null) return;
//
//       if (_s(coupon.phoneNumberCode) != phoneCode) return;
//
//       // ✅ یکدست با بقیه: remove + insert(0)
//       final idx = _allCoupons.indexWhere((c) => _s(c.sId) == docId);
//       if (idx != -1) _allCoupons.removeAt(idx);
//       _allCoupons.insert(0, coupon);
//
//       _applyCouponFilter();
//       _safeNotify();
//     });
//   }
//
//   Future<void> _subscribeToPostersRealtime() async {
//     await _postersRealtimeSub?.cancel();
//     _postersRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdPosters,
//     );
//
//     final stream = RealtimeManager.instance.subscribeCollection<Poster>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdPosters,
//       fromJson: (json) => Poster.fromJson(json),
//     );
//
//     _postersRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Poster>(
//         event,
//         idOf: (p) => _s(p.sId),
//       );
//       if (_s(docId).isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allPosters.removeWhere((p) => _s(p.sId) == docId);
//         _applyPosterFilter();
//         _safeNotify();
//         return;
//       }
//
//       final poster = event.data;
//       if (poster == null) return;
//
//       upsertPosterToTop(poster);
//     });
//   }
//
//   Future<void> _subscribeToVariantsRealtime() async {
//     await _variantsRealtimeSub?.cancel();
//     _variantsRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariants,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     await _ensureVariantTypeMapForVariants(phoneCode);
//
//     final stream = RealtimeManager.instance.subscribeCollection<Variant>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariants,
//       fromJson: (json) => Variant.fromJson(json),
//     );
//
//     _variantsRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Variant>(
//         event,
//         idOf: (v) => _s(v.sId),
//       );
//       if (_s(docId).isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allVariants.removeWhere((v) => _s(v.sId) == docId);
//         _applyVariantFilter();
//         _safeNotify();
//         return;
//       }
//
//       final variant = event.data;
//       if (variant == null) return;
//
//       if (_s(variant.phoneNumberCode) != phoneCode) return;
//
//       final idx = _allVariants.indexWhere((v) => _s(v.sId) == docId);
//       if (idx != -1) _allVariants.removeAt(idx);
//       _allVariants.insert(0, variant);
//
//       _hydrateVariantsTypeNames([variant]);
//       _applyVariantFilter();
//       _safeNotify();
//     });
//   }
//
//   Future<void> _subscribeToVariantTypesRealtime() async {
//     await _variantTypesRealtimeSub?.cancel();
//     _variantTypesRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariantTypes,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<VariantType>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariantTypes,
//       fromJson: (json) => VariantType.fromJson(json),
//     );
//
//     _variantTypesRealtimeSub = stream.listen((event) async {
//       final docId = _getDocumentIdGeneric<VariantType>(
//         event,
//         idOf: (vt) => _s(vt.sId),
//       );
//       if (_s(docId).isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allVariantTypes.removeWhere((vt) => _s(vt.sId) == docId);
//         _applyVariantTypeFilter();
//
//         await _ensureVariantTypeMapForVariants(phoneCode);
//         _hydrateVariantsTypeNames(_allVariants);
//         _applyVariantFilter();
//
//         _safeNotify();
//         return;
//       }
//
//       final vt = event.data;
//       if (vt == null) return;
//
//       if (_s(vt.phoneNumberCode) != phoneCode) return;
//
//       upsertVariantTypeToTop(vt);
//
//       await _ensureVariantTypeMapForVariants(phoneCode);
//       _hydrateVariantsTypeNames(_allVariants);
//       _applyVariantFilter();
//       _safeNotify();
//     });
//   }
//
//   Future<void> _subscribeToSubCategoriesRealtime() async {
//     await _subCategoriesRealtimeSub?.cancel();
//     _subCategoriesRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdSubcategories,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<SubCategory>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdSubcategories,
//       fromJson: (json) => SubCategory.fromJson(json),
//     );
//
//     _subCategoriesRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<SubCategory>(
//         event,
//         idOf: (sc) => _s(sc.sId),
//       );
//       if (_s(docId).isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allSubCategories.removeWhere((sc) => _s(sc.sId) == docId);
//         _applySubCategoryFilter();
//         _safeNotify();
//         return;
//       }
//
//       final sub = event.data;
//       if (sub == null) return;
//
//       if (_s(sub.phoneNumberCode) != phoneCode) return;
//
//       upsertSubCategoryToTop(sub);
//     });
//   }
//
//   Future<void> _subscribeToCategoriesRealtime() async {
//     await _categoriesRealtimeSub?.cancel();
//     _categoriesRealtimeSub = null;
//
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCategories,
//     );
//
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) return;
//
//     final stream = RealtimeManager.instance.subscribeCollection<Category>(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCategories,
//       fromJson: (json) => Category.fromJson(json),
//     );
//
//     _categoriesRealtimeSub = stream.listen((event) {
//       final docId = _getDocumentIdGeneric<Category>(
//         event,
//         idOf: (c) => _s(c.sId),
//       );
//       if (_s(docId).isEmpty) return;
//
//       if (_isDeleteEvent(event)) {
//         _allCategories.removeWhere((c) => _s(c.sId) == docId);
//         _applyCategoryFilter();
//         _safeNotify();
//         return;
//       }
//
//       final cat = event.data;
//       if (cat == null) return;
//
//       if (_s(cat.phoneNumberCode) != phoneCode) return;
//
//       final idx = _allCategories.indexWhere((c) => _s(c.sId) == docId);
//       if (idx != -1) _allCategories.removeAt(idx);
//       _allCategories.insert(0, cat);
//
//       _applyCategoryFilter();
//       _safeNotify();
//     });
//   }
//
//   // =========================================================
//   // Boot / initAll
//   // =========================================================
//   Future<void> initAll() async {
//     if (_initialized) return;
//     _initialized = true;
//
//     final bool isFullMenu = await _isFullMenu();
//
//     await Future.wait([
//       getAllProducts(),
//       getAllCategories(),
//       getAllSubCategories(),
//       getAllBrands(),
//       getAllVariantTypes(),
//       getAllVariants(),
//       getAllPosters(),
//       if (isFullMenu) getAllCoupons(),
//     ]);
//
//     await _bootRealtimeCommon();
//
//     if (isFullMenu) {
//       await _bootOrders();
//       await _bootRealtimeOrdersAndCoupons();
//     } else {
//       _inProgressOrders.clear();
//       _paidOrders.clear();
//       _filteredPaidOrders = const [];
//       _allCoupons.clear();
//       _filteredCoupons = const [];
//
//       _paidOrdersHasMore = true;
//       _paidOrdersLoading = false;
//       _paidOrdersNextPage = 1;
//
//       await _ordersRealtimeSub?.cancel();
//       _ordersRealtimeSub = null;
//
//       RealtimeManager.instance.unsubscribeCollection(
//         databaseId: Environment.databaseIdMenuMita,
//         collectionId: Environment.collectionIdOrders,
//       );
//       RealtimeManager.instance.unsubscribeCollection(
//         databaseId: Environment.databaseIdMenuMita,
//         collectionId: Environment.collectionIdCouponCode,
//       );
//
//       notifyListeners();
//     }
//   }
//
//   Future<void> _bootOrders() async {
//     await getInProgressOrders(showSnack: false);
//     await loadInitialPaidOrders(showSnack: false);
//
//     if (_allCoupons.isEmpty) {
//       await getAllCoupons(showSnack: false);
//     }
//   }
//
//   Future<void> _bootRealtimeCommon() async {
//     await _subscribeToProductsRealtime();
//     await _subscribeToBrandsRealtime();
//     await _subscribeToPostersRealtime();
//     await _subscribeToVariantsRealtime();
//     await _subscribeToVariantTypesRealtime();
//     await _subscribeToSubCategoriesRealtime();
//     await _subscribeToCategoriesRealtime();
//   }
//
//   Future<void> _bootRealtimeOrdersAndCoupons() async {
//     await _subscribeToOrdersRealtimeSingle();
//     await _subscribeToCouponsRealtime();
//   }
//
//   // =========================================================
//   // Dispose / Logout cleanup
//   // =========================================================
//   void _unsubscribeAllRealtimeCollections() {
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdOrders,
//     );
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdProducts,
//     );
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdBrands,
//     );
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCouponCode,
//     );
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdPosters,
//     );
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariants,
//     );
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdVariantTypes,
//     );
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdSubcategories,
//     );
//     RealtimeManager.instance.unsubscribeCollection(
//       databaseId: Environment.databaseIdMenuMita,
//       collectionId: Environment.collectionIdCategories,
//     );
//   }
//
//   @override
//   void dispose() {
//     _ordersRealtimeSub?.cancel();
//     _productsRealtimeSub?.cancel();
//     _brandsRealtimeSub?.cancel();
//     _couponsRealtimeSub?.cancel();
//     _postersRealtimeSub?.cancel();
//     _variantsRealtimeSub?.cancel();
//     _variantTypesRealtimeSub?.cancel();
//     _subCategoriesRealtimeSub?.cancel();
//     _categoriesRealtimeSub?.cancel();
//
//     _unsubscribeAllRealtimeCollections();
//
//     _notifyDebounce?.cancel();
//     super.dispose();
//   }
//
//   Future<void> logoutCleanup() async {
//     _ordersRealtimeSub?.cancel();
//     _ordersRealtimeSub = null;
//
//     _productsRealtimeSub?.cancel();
//     _brandsRealtimeSub?.cancel();
//     _couponsRealtimeSub?.cancel();
//     _postersRealtimeSub?.cancel();
//     _variantsRealtimeSub?.cancel();
//     _variantTypesRealtimeSub?.cancel();
//     _subCategoriesRealtimeSub?.cancel();
//     _categoriesRealtimeSub?.cancel();
//
//     _notifyDebounce?.cancel();
//     _notifyDebounce = null;
//
//     _unsubscribeAllRealtimeCollections();
//
//     _initialized = false;
//
//     _inProgressOrders.clear();
//     _paidOrders.clear();
//     _filteredPaidOrders = const [];
//     _paidOrdersLoading = false;
//     _paidOrdersHasMore = true;
//     _paidOrdersNextPage = 1;
//
//     _allCoupons.clear();
//     _filteredCoupons = const [];
//     _allProducts.clear();
//     _filteredProducts = const [];
//     _allBrands.clear();
//     _filteredBrands = const [];
//     _allCategories.clear();
//     _filteredCategories = const [];
//     _allSubCategories.clear();
//     _filteredSubCategories = const [];
//     _allVariantTypes.clear();
//     _filteredVariantTypes = const [];
//     _allVariants.clear();
//     _filteredVariants = const [];
//     _allPosters.clear();
//     _filteredPosters = const [];
//     _notifyDebounce?.cancel();
//     _notifyDebounce = null;
//
//     _unsubscribeAllRealtimeCollections();
//
//     _initialized = false; // ← این خط جدیده
//
//     // پاکسازی لیست‌ها مثل قبل
//     _inProgressOrders.clear();
//     _paidOrders.clear();
//     // ... بقیه clearها
//     notifyListeners();
//   }
//
//   // =========================================================
//   // Compatibility shortcuts (UI قدیمی)
//   // =========================================================
//   List<Order> get allsOrders => inProgressOrders;
//
//   List<Order> get orders => paidOrders;
//
//   bool get isOrdersLoading => isPaidOrdersLoading;
//
//   bool get hasMoreOrders => hasMorePaidOrders;
//
//   Future<void> getAllsOrders({bool showSnack = false}) async =>
//       getInProgressOrders(showSnack: showSnack);
//
//   Future<void> loadInitialOrders({bool showSnack = false}) async =>
//       loadInitialPaidOrders(showSnack: showSnack);
//
//   Future<void> loadMoreOrders() async => loadMorePaidOrders();
//
//   int calculateOrdersWithStatus({String? status}) {
//     if (status == null) return inProgressOrders.length;
//     return inProgressOrders.where((o) => o.orderStatus == status).length;
//   }
//
//   void filterAllOrders(String status) => notifyListeners();
//
//   void searchAllOrders(String query) => notifyListeners();
//
//   void searchOrders(String query) => notifyListeners();
//
//   // =========================================================
//   // Data lists
//   // =========================================================
//   List<Category> _allCategories = [];
//   List<Category> _filteredCategories = [];
//
//   List<Category> get categories => _filteredCategories;
//
//   List<SubCategory> _allSubCategories = [];
//   List<SubCategory> _filteredSubCategories = [];
//
//   List<SubCategory> get subCategories => _filteredSubCategories;
//
//   List<Brand> _allBrands = [];
//   List<Brand> _filteredBrands = [];
//
//   List<Brand> get brands => _filteredBrands;
//
//   List<VariantType> _allVariantTypes = [];
//   List<VariantType> _filteredVariantTypes = [];
//
//   List<VariantType> get variantTypes => _filteredVariantTypes;
//
//   List<Variant> _allVariants = [];
//   List<Variant> _filteredVariants = [];
//
//   List<Variant> get variants => _filteredVariants;
//
//   List<Product> _allProducts = [];
//   List<Product> _filteredProducts = [];
//
//   List<Product> get products => _filteredProducts;
//
//   List<Coupon> _allCoupons = [];
//   List<Coupon> _filteredCoupons = [];
//
//   List<Coupon> get coupons => _filteredCoupons;
//
//   List<Poster> _allPosters = [];
//   List<Poster> _filteredPosters = [];
//
//   List<Poster> get posters => _filteredPosters;
//
//   // =========================================================
//   // PRODUCTS (Paging + realtime friendly)
//   // =========================================================
//   static const int _productsPageSize = 3;
//   bool _productsLoading = false;
//   bool _productsLoadingMore = false;
//   bool _productsHasMore = true;
//   String? _productsCursorAfter;
//   String _productKeyword = '';
//   String _filteredProductsType = ALL_PRODUCTS;
//
//   bool get isProductsLoading => _productsLoading;
//
//   bool get isProductsLoadingMore => _productsLoadingMore;
//
//   bool get hasMoreProducts => _productsHasMore;
//
//   String get productsType => _filteredProductsType;
//
//   DateTime _productTs(Product p) {
//     final u = (p.updatedAt ?? '').trim();
//     final c = (p.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllProducts() {
//     _allProducts.sort((a, b) => _productTs(b).compareTo(_productTs(a)));
//   }
//
//   int? _qtyOf(Product p) => _tryInt(p.quantity);
//
//   Future<List<Product>> getAllProducts({bool showSnack = false}) async =>
//       loadInitialProducts(showSnack: showSnack);
//
//   Future<List<Product>> loadInitialProducts({bool showSnack = false}) async {
//     if (_productsLoading) return _filteredProducts;
//
//     _productsLoading = true;
//     _productsLoadingMore = false;
//     _productsHasMore = true;
//     _productsCursorAfter = null;
//
//     _allProducts.clear();
//     _filteredProducts = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         return _filteredProducts;
//       }
//
//       await _ensureCategoriesLoadedForProducts();
//       await _ensureSubCategoriesLoadedForProducts();
//
//       final res = await _productsService.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _productsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _hydrateProductsNames(items);
//         _allProducts.addAll(items);
//
//         _productsHasMore = items.length >= _productsPageSize;
//         _productsCursorAfter =
//         _productsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyProductFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Products loaded');
//         return _filteredProducts;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredProducts;
//       }
//     } finally {
//       _productsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Product>> loadMoreProducts({bool showSnack = false}) async {
//     if (_productsLoading || _productsLoadingMore || !_productsHasMore)
//       return _filteredProducts;
//
//     _productsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredProducts;
//
//       await _ensureCategoriesLoadedForProducts();
//       await _ensureSubCategoriesLoadedForProducts();
//
//       final res = await _productsService.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _productsPageSize,
//         cursorAfter: _productsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         if (items.isEmpty) {
//           _productsHasMore = false;
//           return _filteredProducts;
//         }
//
//         _hydrateProductsNames(items);
//
//         for (final p in items) {
//           final id = _s(p.sId);
//           if (id.isEmpty) continue;
//
//           final idx = _allProducts.indexWhere((x) => _s(x.sId) == id);
//           if (idx == -1) {
//             _allProducts.add(p);
//           } else {
//             _allProducts[idx] = p;
//           }
//         }
//
//         _productsHasMore = items.length >= _productsPageSize;
//         _productsCursorAfter = _productsHasMore ? items.last.sId : null;
//
//         _applyProductFilter();
//         return _filteredProducts;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredProducts;
//       }
//     } finally {
//       _productsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterProducts(String keyword) {
//     _productKeyword = keyword.trim();
//     _applyProductFilter();
//     notifyListeners();
//   }
//
//   void filterProductsByQuantity(String productQntType,
//       {bool showSnack = false}) {
//     _filteredProductsType =
//     productQntType.isEmpty ? ALL_PRODUCTS : productQntType;
//
//     if (_filteredProductsType == ALL_PRODUCTS) {
//       _filteredProducts = List<Product>.from(_allProducts);
//     } else if (_filteredProductsType == STOCK_OUT_PRODUCTS) {
//       _filteredProducts =
//           _allProducts.where((p) => (_qtyOf(p) ?? -1) == 0).toList();
//     } else if (_filteredProductsType == LIMITED_STOCK_PRODUCTS) {
//       _filteredProducts =
//           _allProducts.where((p) => (_qtyOf(p) ?? -1) == 1).toList();
//     } else if (_filteredProductsType == OTHER_PRODUCTS) {
//       _filteredProducts = _allProducts.where((p) {
//         final q = _qtyOf(p);
//         return q == null || (q != 0 && q != 1);
//       }).toList();
//     } else {
//       _filteredProducts = List<Product>.from(_allProducts);
//     }
//
//     if (showSnack) {
//       SnackBarHelper.showSuccessSnackBar(
//           '${_filteredProductsType} retrieved successfully!');
//     }
//
//     notifyListeners();
//   }
//
//   int calculateProductWithQuantity({int? quantity}) {
//     if (quantity == null) return _allProducts.length;
//     int total = 0;
//     for (final p in _allProducts) {
//       final q = _qtyOf(p);
//       if (q == quantity) total++;
//     }
//     return total;
//   }
//
//   void upsertProductToTop(Product incoming) {
//     final id = _s(incoming.sId);
//     if (id.isEmpty) return;
//
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allProducts.indexWhere((x) => _s(x.sId) == id);
//     if (idx != -1) _allProducts.removeAt(idx);
//
//     _allProducts.insert(0, incoming);
//
//     _hydrateProductsNames([incoming]);
//     _applyProductFilter();
//     notifyListeners();
//   }
//
//   void removeProductById(String id) {
//     final sid = id.trim();
//     if (sid.isEmpty) return;
//     _allProducts.removeWhere((p) => _s(p.sId) == sid);
//     _applyProductFilter();
//     notifyListeners();
//   }
//
//   void _applyProductFilter() {
//     _sortAllProducts();
//
//     final kw = _productKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredProducts = List<Product>.from(_allProducts);
//       return;
//     }
//
//     _filteredProducts = _allProducts.where((p) {
//       final name = (p.name ?? '').toLowerCase();
//       final cat = (p.resolvedCategoryName ?? '').toLowerCase();
//       final sub = (p.resolvedSubCategoryName ?? '').toLowerCase();
//       return name.contains(kw) || cat.contains(kw) || sub.contains(kw);
//     }).toList()
//       ..sort((a, b) => _productTs(b).compareTo(_productTs(a)));
//   }
//
//   Future<void> _ensureCategoriesLoadedForProducts() async {
//     if (_allCategories.isEmpty) {
//       await getAllCategories(showSnack: false);
//     }
//   }
//
//   Future<void> _ensureSubCategoriesLoadedForProducts() async {
//     if (_allSubCategories.isEmpty) {
//       await getAllSubCategories(showSnack: false);
//     }
//   }
//
//   void _hydrateProductsNames(List<Product> products) {
//     if (products.isEmpty) return;
//
//     final catMap = <String, String>{};
//     for (final c in _allCategories) {
//       final id = _s(c.sId);
//       if (id.isNotEmpty) catMap[id] = _s(c.name);
//     }
//
//     final subMap = <String, String>{};
//     for (final s in _allSubCategories) {
//       final id = _s(s.sId);
//       if (id.isNotEmpty) subMap[id] = _s(s.name);
//     }
//
//     for (final p in products) {
//       final cid = _s(p.categoryId);
//       final sid = _s(p.subCategoryId);
//       p.resolvedCategoryName = catMap[cid] ?? '';
//       p.resolvedSubCategoryName = subMap[sid] ?? '';
//     }
//   }
//
//   // =========================================================
//   // COUPONS (Paging)
//   // =========================================================
//   static const int _couponsPageSize = 17;
//   bool _couponsLoading = false;
//   bool _couponsLoadingMore = false;
//   bool _couponsHasMore = true;
//   String? _couponsCursorAfter;
//   String _couponKeyword = '';
//
//   bool get isCouponsLoading => _couponsLoading;
//
//   bool get isCouponsLoadingMore => _couponsLoadingMore;
//
//   bool get hasMoreCoupons => _couponsHasMore;
//
//   DateTime _couponTs(Coupon c) {
//     final u = (c.updatedAt ?? '').trim();
//     final cr = (c.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : cr;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllCoupons() {
//     _allCoupons.sort((a, b) => _couponTs(b).compareTo(_couponTs(a)));
//   }
//
//   void _applyCouponFilter() {
//     _sortAllCoupons();
//     final kw = _couponKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredCoupons = List<Coupon>.from(_allCoupons);
//       return;
//     }
//     _filteredCoupons = _allCoupons
//         .where((c) => (c.couponCode ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _couponTs(b).compareTo(_couponTs(a)));
//   }
//
//   Future<List<Coupon>> getAllCoupons({bool showSnack = false}) async =>
//       loadInitialCoupons(showSnack: showSnack);
//
//   Future<List<Coupon>> loadInitialCoupons({bool showSnack = false}) async {
//     if (_couponsLoading) return _filteredCoupons;
//
//     _couponsLoading = true;
//     _couponsLoadingMore = false;
//     _couponsHasMore = true;
//     _couponsCursorAfter = null;
//
//     _allCoupons.clear();
//     _filteredCoupons = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredCoupons;
//
//       final res = await _couponService.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _couponsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         _allCoupons.addAll(items);
//
//         _couponsHasMore = items.length >= _couponsPageSize;
//         _couponsCursorAfter =
//         _couponsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyCouponFilter();
//         return _filteredCoupons;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredCoupons;
//       }
//     } finally {
//       _couponsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Coupon>> loadMoreCoupons({bool showSnack = false}) async {
//     if (_couponsLoading || _couponsLoadingMore || !_couponsHasMore)
//       return _filteredCoupons;
//
//     _couponsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredCoupons;
//
//       final res = await _couponService.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _couponsPageSize,
//         cursorAfter: _couponsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         if (items.isEmpty) {
//           _couponsHasMore = false;
//           return _filteredCoupons;
//         }
//
//         for (final c in items) {
//           final id = _s(c.sId);
//           if (id.isEmpty) continue;
//
//           final idx = _allCoupons.indexWhere((x) => _s(x.sId) == id);
//           if (idx == -1)
//             _allCoupons.add(c);
//           else
//             _allCoupons[idx] = c;
//         }
//
//         _couponsHasMore = items.length >= _couponsPageSize;
//         _couponsCursorAfter = _couponsHasMore ? items.last.sId : null;
//
//         _applyCouponFilter();
//         return _filteredCoupons;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredCoupons;
//       }
//     } finally {
//       _couponsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterCoupons(String keyword) {
//     _couponKeyword = keyword.trim();
//     _applyCouponFilter();
//     notifyListeners();
//   }
//
//   // =========================================================
//   // BRANDS (Paging + hydration)
//   // =========================================================
//   static const int _brandsPageSize = 17;
//   bool _brandsLoading = false;
//   bool _brandsLoadingMore = false;
//   bool _brandsHasMore = true;
//   String? _brandsCursorAfter;
//   String _brandKeyword = '';
//
//   bool get isBrandsLoading => _brandsLoading;
//
//   bool get isBrandsLoadingMore => _brandsLoadingMore;
//
//   bool get hasMoreBrands => _brandsHasMore;
//
//   DateTime _brandTs(Brand b) {
//     final u = (b.updatedAt ?? '').trim();
//     final c = (b.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllBrands() {
//     _allBrands.sort((a, b) => _brandTs(b).compareTo(_brandTs(a)));
//   }
//
//   void _applyBrandFilter() {
//     _sortAllBrands();
//     final kw = _brandKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredBrands = List<Brand>.from(_allBrands);
//       return;
//     }
//     _filteredBrands = _allBrands
//         .where((b) => (b.name ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _brandTs(b).compareTo(_brandTs(a)));
//   }
//
//   void filterBrands(String keyword) {
//     _brandKeyword = keyword.trim();
//     _applyBrandFilter();
//     notifyListeners();
//   }
//
//   void upsertBrandToTop(Brand incoming) {
//     final id = _s(incoming.sId);
//     if (id.isEmpty) return;
//
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allBrands.indexWhere((x) => _s(x.sId) == id);
//     if (idx != -1) _allBrands.removeAt(idx);
//
//     _allBrands.insert(0, incoming);
//     _applyBrandFilter();
//     notifyListeners();
//   }
//
//   void removeBrandById(String id) {
//     final sid = id.trim();
//     if (sid.isEmpty) return;
//     _allBrands.removeWhere((b) => _s(b.sId) == sid);
//     _applyBrandFilter();
//     notifyListeners();
//   }
//
//   Future<List<Brand>> getAllBrands({bool showSnack = false}) async {
//     return loadInitialBrands(showSnack: showSnack);
//   }
//
//   Future<List<Brand>> loadInitialBrands({bool showSnack = false}) async {
//     if (_brandsLoading) return _filteredBrands;
//
//     _brandsLoading = true;
//     _brandsLoadingMore = false;
//     _brandsHasMore = true;
//     _brandsCursorAfter = null;
//
//     _allBrands.clear();
//     _filteredBrands = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         return _filteredBrands;
//       }
//
//       await _ensureSubCategoriesLoadedForBrands();
//
//       final res = await brandsRepoAppwrite.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _brandsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         await _ensureSubCategoryCacheForBrands(phoneCode, items);
//         _hydrateBrandsWithSubCategoryNames(items);
//
//         _allBrands.addAll(items);
//
//         _brandsHasMore = items.length >= _brandsPageSize;
//         _brandsCursorAfter =
//         _brandsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyBrandFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Brands loaded');
//         return _filteredBrands;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredBrands;
//       }
//     } finally {
//       _brandsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Brand>> loadMoreBrands({bool showSnack = false}) async {
//     if (_brandsLoading || _brandsLoadingMore || !_brandsHasMore)
//       return _filteredBrands;
//
//     _brandsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredBrands;
//
//       final res = await brandsRepoAppwrite.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _brandsPageSize,
//         cursorAfter: _brandsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//         if (items.isEmpty) {
//           _brandsHasMore = false;
//           return _filteredBrands;
//         }
//
//         await _ensureSubCategoriesLoadedForBrands();
//         await _ensureSubCategoryCacheForBrands(phoneCode, items);
//         _hydrateBrandsWithSubCategoryNames(items);
//
//         for (final b in items) {
//           final id = _s(b.sId);
//           if (id.isEmpty) continue;
//
//           final idx = _allBrands.indexWhere((x) => _s(x.sId) == id);
//           if (idx == -1)
//             _allBrands.add(b);
//           else
//             _allBrands[idx] = b;
//         }
//
//         _brandsHasMore = items.length >= _brandsPageSize;
//         _brandsCursorAfter = _brandsHasMore ? items.last.sId : null;
//
//         _applyBrandFilter();
//         return _filteredBrands;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredBrands;
//       }
//     } finally {
//       _brandsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   // ----- brand hydration via SubCategory -----
//   final Map<String, SubCategory> _scCacheForBrands = {};
//   String? _scCachePhoneForBrands;
//
//   Future<void> _ensureSubCategoriesLoadedForBrands() async {
//     if (_allSubCategories.isEmpty) {
//       await getAllSubCategories(showSnack: false);
//     }
//   }
//
//   Future<void> _ensureSubCategoryCacheForBrands(
//       String phone, List<Brand> brands) async {
//     if (_scCachePhoneForBrands != phone) {
//       _scCachePhoneForBrands = phone;
//       _scCacheForBrands.clear();
//     }
//
//     for (final sc in _allSubCategories) {
//       final id = _s(sc.sId);
//       if (id.isNotEmpty) _scCacheForBrands[id] = sc;
//     }
//
//     final missing = <String>{};
//     for (final b in brands) {
//       final subId =
//       _s(b.subcategory ?? b.subcategoriesId ?? b.subCategoryId?.sId ?? '');
//       if (subId.isNotEmpty && !_scCacheForBrands.containsKey(subId)) {
//         missing.add(subId);
//       }
//     }
//
//     for (final id in missing) {
//       final res = await _subCategoryService.getById(id);
//       if (res.isSuccess) {
//         final sc = res.requireData();
//         final sid = _s(sc.sId);
//         if (sid.isNotEmpty) _scCacheForBrands[sid] = sc;
//       }
//     }
//   }
//
//   void _hydrateBrandsWithSubCategoryNames(List<Brand> brands) {
//     for (final b in brands) {
//       final subId =
//       _s(b.subcategory ?? b.subcategoriesId ?? b.subCategoryId?.sId ?? '');
//       if (subId.isEmpty) continue;
//
//       final sc = _scCacheForBrands[subId];
//       if (sc == null) continue;
//
//       b.subCategoryId = SubcategoryId(
//         sId: sc.sId,
//         name: sc.name,
//       );
//     }
//   }
//
//   // =========================================================
//   // POSTERS (Paging + realtime friendly)
//   // =========================================================
//   static const int _postersPageSize = 17;
//
//   bool _postersLoading = false;
//   bool _postersLoadingMore = false;
//   bool _postersHasMore = true;
//
//   String? _postersCursorAfter;
//   String _posterKeyword = '';
//
//   bool get isPostersLoading => _postersLoading;
//
//   bool get isPostersLoadingMore => _postersLoadingMore;
//
//   bool get hasMorePosters => _postersHasMore;
//
//   DateTime _posterTs(Poster p) {
//     final u = (p.updatedAt ?? '').trim();
//     final c = (p.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllPosters() {
//     _allPosters.sort((a, b) => _posterTs(b).compareTo(_posterTs(a)));
//   }
//
//   void upsertPosterToTop(Poster incoming) {
//     final id = _s(incoming.sId);
//     if (id.isEmpty) return;
//
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allPosters.indexWhere((x) => _s(x.sId) == id);
//     if (idx != -1) _allPosters.removeAt(idx);
//
//     _allPosters.insert(0, incoming);
//
//     _applyPosterFilter();
//     notifyListeners();
//   }
//
//   Future<List<Poster>> getAllPosters({bool showSnack = false}) async {
//     return loadInitialPosters(showSnack: showSnack);
//   }
//
//   Future<List<Poster>> loadInitialPosters({bool showSnack = false}) async {
//     if (_postersLoading) return _filteredPosters;
//
//     _postersLoading = true;
//     _postersLoadingMore = false;
//     _postersHasMore = true;
//     _postersCursorAfter = null;
//
//     _allPosters.clear();
//     _filteredPosters = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//         return _filteredPosters;
//       }
//
//       final res = await _posterService.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _postersPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _allPosters.addAll(items);
//
//         _postersHasMore = items.length >= _postersPageSize;
//         _postersCursorAfter =
//         _postersHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyPosterFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('پوسترها لود شدند');
//         return _filteredPosters;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredPosters;
//       }
//     } finally {
//       _postersLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Poster>> loadMorePosters({bool showSnack = false}) async {
//     if (_postersLoading || _postersLoadingMore || !_postersHasMore) {
//       return _filteredPosters;
//     }
//
//     _postersLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredPosters;
//
//       final res = await _posterService.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _postersPageSize,
//         cursorAfter: _postersCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _postersHasMore = false;
//           return _filteredPosters;
//         }
//
//         for (final p in items) {
//           final id = _s(p.sId);
//           if (id.isEmpty) continue;
//
//           final idx = _allPosters.indexWhere((x) => _s(x.sId) == id);
//           if (idx == -1)
//             _allPosters.add(p);
//           else
//             _allPosters[idx] = p;
//         }
//
//         _postersHasMore = items.length >= _postersPageSize;
//         _postersCursorAfter = _postersHasMore ? items.last.sId : null;
//
//         _applyPosterFilter();
//         return _filteredPosters;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredPosters;
//       }
//     } finally {
//       _postersLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterPosters(String keyword) {
//     _posterKeyword = keyword.trim();
//     _applyPosterFilter();
//     notifyListeners();
//   }
//
//   void _applyPosterFilter() {
//     _sortAllPosters();
//
//     final kw = _posterKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredPosters = List<Poster>.from(_allPosters);
//       return;
//     }
//
//     _filteredPosters = _allPosters
//         .where((p) => (p.posterName ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _posterTs(b).compareTo(_posterTs(a)));
//   }
//
//   // =========================================================
//   // VARIANTS (Paging + hydration by VariantTypes)
//   // =========================================================
//   static const int _variantsPageSize = 17;
//
//   bool _variantsLoading = false;
//   bool _variantsLoadingMore = false;
//   bool _variantsHasMore = true;
//
//   String? _variantsCursorAfter;
//   String _variantKeyword = '';
//
//   bool get isVariantsLoading => _variantsLoading;
//
//   bool get isVariantsLoadingMore => _variantsLoadingMore;
//
//   bool get hasMoreVariants => _variantsHasMore;
//
//   Map<String, VariantType> _vtMapForVariants = {};
//   String? _vtMapPhoneForVariants;
//
//   Future<void> _ensureVariantTypeMapForVariants(String phone) async {
//     if (_vtMapPhoneForVariants == phone && _vtMapForVariants.isNotEmpty) return;
//
//     final allVts = await _getVariantTypesForHydration(phone);
//     final map = <String, VariantType>{};
//     for (final vt in allVts) {
//       final id = _s(vt.sId);
//       if (id.isNotEmpty) map[id] = vt;
//     }
//
//     _vtMapForVariants = map;
//     _vtMapPhoneForVariants = phone;
//   }
//
//   void _hydrateVariantsTypeNames(List<Variant> vars) {
//     if (_vtMapForVariants.isEmpty) return;
//
//     for (final v in vars) {
//       final vtId = _s(v.variantType ?? v.variantTypeId?.sId ?? '');
//       if (vtId.isEmpty) continue;
//
//       final vt = _vtMapForVariants[vtId];
//       if (vt == null) continue;
//
//       v.variantTypeId = VariantTypeId(
//         sId: vt.sId,
//         name: vt.name,
//         type: vt.type,
//       );
//     }
//   }
//
//   Future<List<Variant>> getAllVariants({bool showSnack = false}) async {
//     return loadInitialVariants(showSnack: showSnack);
//   }
//
//   Future<List<Variant>> loadInitialVariants({bool showSnack = false}) async {
//     if (_variantsLoading) return _filteredVariants;
//
//     _variantsLoading = true;
//     _variantsLoadingMore = false;
//     _variantsHasMore = true;
//     _variantsCursorAfter = null;
//
//     _allVariants.clear();
//     _filteredVariants = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         return _filteredVariants;
//       }
//
//       await _ensureVariantTypeMapForVariants(phoneCode);
//
//       final res = await variantsRepoAppwrite.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _variantsPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _hydrateVariantsTypeNames(items);
//
//         _allVariants.addAll(items);
//
//         _variantsHasMore = items.length >= _variantsPageSize;
//         _variantsCursorAfter =
//         _variantsHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyVariantFilter();
//         if (showSnack) SnackBarHelper.showSuccessSnackBar('Variants loaded');
//         return _filteredVariants;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredVariants;
//       }
//     } finally {
//       _variantsLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Variant>> loadMoreVariants({bool showSnack = false}) async {
//     if (_variantsLoading || _variantsLoadingMore || !_variantsHasMore) {
//       return _filteredVariants;
//     }
//
//     _variantsLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredVariants;
//
//       await _ensureVariantTypeMapForVariants(phoneCode);
//
//       final res = await variantsRepoAppwrite.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _variantsPageSize,
//         cursorAfter: _variantsCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _variantsHasMore = false;
//           return _filteredVariants;
//         }
//
//         _hydrateVariantsTypeNames(items);
//
//         for (final v in items) {
//           final id = _s(v.sId);
//           if (id.isEmpty) continue;
//
//           final idx = _allVariants.indexWhere((x) => _s(x.sId) == id);
//           if (idx == -1)
//             _allVariants.add(v);
//           else
//             _allVariants[idx] = v;
//         }
//
//         _variantsHasMore = items.length >= _variantsPageSize;
//         _variantsCursorAfter = _variantsHasMore ? items.last.sId : null;
//
//         _applyVariantFilter();
//         return _filteredVariants;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredVariants;
//       }
//     } finally {
//       _variantsLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterVariants(String keyword) {
//     _variantKeyword = keyword.trim();
//     _applyVariantFilter();
//     notifyListeners();
//   }
//
//   void _applyVariantFilter() {
//     final kw = _variantKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredVariants = List<Variant>.from(_allVariants);
//       return;
//     }
//
//     _filteredVariants = _allVariants
//         .where((v) => (v.name ?? '').toLowerCase().contains(kw))
//         .toList();
//   }
//
//   // =========================================================
//   // VARIANT TYPES (Paging)
//   // =========================================================
//   static const int _variantTypesPageSize = 17;
//
//   bool _variantTypesLoading = false;
//   bool _variantTypesLoadingMore = false;
//   bool _variantTypesHasMore = true;
//
//   String? _variantTypesCursorAfter;
//   String _variantTypeKeyword = '';
//
//   bool get isVariantTypesLoading => _variantTypesLoading;
//
//   bool get isVariantTypesLoadingMore => _variantTypesLoadingMore;
//
//   bool get hasMoreVariantTypes => _variantTypesHasMore;
//
//   DateTime _vtTs(VariantType v) {
//     final u = (v.updatedAt ?? '').trim();
//     final c = (v.createdAt ?? '').trim();
//     final raw = u.isNotEmpty ? u : c;
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllVariantTypes() {
//     _allVariantTypes.sort((a, b) => _vtTs(b).compareTo(_vtTs(a)));
//   }
//
//   void upsertVariantTypeToTop(VariantType incoming) {
//     final id = _s(incoming.sId);
//     if (id.isEmpty) return;
//
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allVariantTypes.indexWhere((x) => _s(x.sId) == id);
//     if (idx != -1) _allVariantTypes.removeAt(idx);
//
//     _allVariantTypes.insert(0, incoming);
//
//     _applyVariantTypeFilter();
//     notifyListeners();
//   }
//
//   Future<List<VariantType>> getAllVariantTypes({bool showSnack = false}) async {
//     return loadInitialVariantTypes(showSnack: showSnack);
//   }
//
//   Future<List<VariantType>> loadInitialVariantTypes(
//       {bool showSnack = false}) async {
//     if (_variantTypesLoading) return _filteredVariantTypes;
//
//     _variantTypesLoading = true;
//     _variantTypesLoadingMore = false;
//     _variantTypesHasMore = true;
//     _variantTypesCursorAfter = null;
//
//     _allVariantTypes.clear();
//     _filteredVariantTypes = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar('شماره تلفن/کد در حافظه یافت نشد!');
//         return _filteredVariantTypes;
//       }
//
//       final res = await variantTypesRepoAppwrite.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _variantTypesPageSize,
//         cursorAfter: null,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         _allVariantTypes.addAll(items);
//
//         _variantTypesHasMore = items.length >= _variantTypesPageSize;
//         _variantTypesCursorAfter =
//         _variantTypesHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyVariantTypeFilter();
//         if (showSnack)
//           SnackBarHelper.showSuccessSnackBar('Variant types loaded');
//         return _filteredVariantTypes;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredVariantTypes;
//       }
//     } finally {
//       _variantTypesLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<VariantType>> loadMoreVariantTypes(
//       {bool showSnack = false}) async {
//     if (_variantTypesLoading ||
//         _variantTypesLoadingMore ||
//         !_variantTypesHasMore) {
//       return _filteredVariantTypes;
//     }
//
//     _variantTypesLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredVariantTypes;
//
//       final res = await variantTypesRepoAppwrite.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _variantTypesPageSize,
//         cursorAfter: _variantTypesCursorAfter,
//       );
//
//       if (res.isSuccess) {
//         final items = res.requireData();
//
//         if (items.isEmpty) {
//           _variantTypesHasMore = false;
//           return _filteredVariantTypes;
//         }
//
//         for (final vt in items) {
//           final id = _s(vt.sId);
//           if (id.isEmpty) continue;
//
//           final idx = _allVariantTypes.indexWhere((x) => _s(x.sId) == id);
//           if (idx == -1)
//             _allVariantTypes.add(vt);
//           else
//             _allVariantTypes[idx] = vt;
//         }
//
//         _variantTypesHasMore = items.length >= _variantTypesPageSize;
//         _variantTypesCursorAfter = _variantTypesHasMore ? items.last.sId : null;
//
//         _applyVariantTypeFilter();
//         return _filteredVariantTypes;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//         return _filteredVariantTypes;
//       }
//     } finally {
//       _variantTypesLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterVariantTypes(String keyword) {
//     _variantTypeKeyword = keyword.trim();
//     _applyVariantTypeFilter();
//     notifyListeners();
//   }
//
//   void _applyVariantTypeFilter() {
//     _sortAllVariantTypes();
//
//     final kw = _variantTypeKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredVariantTypes = List<VariantType>.from(_allVariantTypes);
//       return;
//     }
//
//     _filteredVariantTypes = _allVariantTypes
//         .where((v) => (v.name ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _vtTs(b).compareTo(_vtTs(a)));
//   }
//
//   Future<List<VariantType>> _getVariantTypesForHydration(String phone) async {
//     final res = await variantTypesRepoAppwrite.getByPhoneNumberCode(phone);
//     if (res.isSuccess) return res.requireData();
//     return _allVariantTypes;
//   }
//
//   // =========================================================
//   // SUBCATEGORIES (Paging + CRUD)
//   // =========================================================
//   static const int _subCategoriesPageSize = 17;
//   bool _subCategoriesLoading = false;
//   bool _subCategoriesLoadingMore = false;
//   bool _subCategoriesHasMore = true;
//   String? _subCategoriesCursorAfter;
//   String _subCategoryKeyword = '';
//
//   bool get isSubCategoriesLoading => _subCategoriesLoading;
//
//   bool get isSubCategoriesLoadingMore => _subCategoriesLoadingMore;
//
//   bool get hasMoreSubCategories => _subCategoriesHasMore;
//
//   DateTime _subTs(SubCategory s) {
//     final raw = (s.updatedAt ?? '').trim().isNotEmpty
//         ? s.updatedAt!
//         : (s.createdAt ?? '');
//     final dt = DateTime.tryParse(raw);
//     return dt ?? DateTime.fromMillisecondsSinceEpoch(0);
//   }
//
//   void _sortAllSubCategories() {
//     _allSubCategories.sort((a, b) => _subTs(b).compareTo(_subTs(a)));
//   }
//
//   void _applySubCategoryFilter() {
//     _sortAllSubCategories();
//
//     final kw = _subCategoryKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredSubCategories = List<SubCategory>.from(_allSubCategories);
//       return;
//     }
//
//     _filteredSubCategories = _allSubCategories
//         .where((s) => (s.name ?? '').toLowerCase().contains(kw))
//         .toList()
//       ..sort((a, b) => _subTs(b).compareTo(_subTs(a)));
//   }
//
//   Future<List<SubCategory>> getAllSubCategories(
//       {bool showSnack = false}) async =>
//       loadInitialSubCategories(showSnack: showSnack);
//
//   Future<List<SubCategory>> loadInitialSubCategories(
//       {bool showSnack = false}) async {
//     if (_subCategoriesLoading) return _filteredSubCategories;
//
//     _subCategoriesLoading = true;
//     _subCategoriesLoadingMore = false;
//     _subCategoriesHasMore = true;
//     _subCategoriesCursorAfter = null;
//
//     _allSubCategories.clear();
//     _filteredSubCategories = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredSubCategories;
//
//       final result = await _subCategoryService.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _subCategoriesPageSize,
//         cursorAfter: null,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//         _allSubCategories.addAll(items);
//
//         _subCategoriesHasMore = items.length >= _subCategoriesPageSize;
//         _subCategoriesCursorAfter =
//         _subCategoriesHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applySubCategoryFilter();
//         return _filteredSubCategories;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(result.requireError().userMessage);
//         return _filteredSubCategories;
//       }
//     } finally {
//       _subCategoriesLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<SubCategory>> loadMoreSubCategories(
//       {bool showSnack = false}) async {
//     if (_subCategoriesLoading ||
//         _subCategoriesLoadingMore ||
//         !_subCategoriesHasMore) {
//       return _filteredSubCategories;
//     }
//
//     _subCategoriesLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredSubCategories;
//
//       final result = await _subCategoryService.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _subCategoriesPageSize,
//         cursorAfter: _subCategoriesCursorAfter,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//
//         if (items.isEmpty) {
//           _subCategoriesHasMore = false;
//           return _filteredSubCategories;
//         }
//
//         for (final s in items) {
//           final id = _s(s.sId);
//           if (id.isEmpty) continue;
//
//           final idx = _allSubCategories.indexWhere((x) => _s(x.sId) == id);
//           if (idx == -1)
//             _allSubCategories.add(s);
//           else
//             _allSubCategories[idx] = s;
//         }
//
//         _subCategoriesHasMore = items.length >= _subCategoriesPageSize;
//         _subCategoriesCursorAfter =
//         _subCategoriesHasMore ? items.last.sId : null;
//
//         _applySubCategoryFilter();
//         return _filteredSubCategories;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(result.requireError().userMessage);
//         return _filteredSubCategories;
//       }
//     } finally {
//       _subCategoriesLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterSubCategories(String keyword) {
//     _subCategoryKeyword = keyword.trim();
//     _applySubCategoryFilter();
//     notifyListeners();
//   }
//
//   void upsertSubCategoryToTop(SubCategory incoming) {
//     final id = _s(incoming.sId);
//     if (id.isEmpty) return;
//
//     incoming.updatedAt ??= DateTime.now().toIso8601String();
//
//     final idx = _allSubCategories.indexWhere((x) => _s(x.sId) == id);
//     if (idx != -1) _allSubCategories.removeAt(idx);
//
//     _allSubCategories.insert(0, incoming);
//     _applySubCategoryFilter();
//     notifyListeners();
//   }
//
//   Future<void> createSubCategory({
//     required String name,
//     required String categoryId,
//     bool showSnack = false,
//   }) async {
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) {
//       if (showSnack)
//         SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//       return;
//     }
//
//     final res = await _subCategoryService.createSubCategory(
//       name: name.trim(),
//       phoneNumberCode: phoneCode,
//       categoryId: categoryId,
//     );
//
//     if (res.isSuccess) {
//       final saved = res.requireData();
//       upsertSubCategoryToTop(saved);
//       if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategory created');
//     } else {
//       if (showSnack)
//         SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//     }
//   }
//
//   Future<void> updateSubCategory({
//     required String documentId,
//     required String name,
//     required String categoryId,
//     bool showSnack = false,
//   }) async {
//     final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//     final phoneCode = phone.trim();
//     if (phoneCode.isEmpty) {
//       if (showSnack)
//         SnackBarHelper.showErrorSnackBar('شماره تلفن در حافظه یافت نشد!');
//       return;
//     }
//
//     final res = await _subCategoryService.updateSubCategory(
//       documentId: documentId,
//       name: name.trim(),
//       phoneNumberCode: phoneCode,
//       categoryId: categoryId,
//     );
//
//     if (res.isSuccess) {
//       final saved = res.requireData();
//       upsertSubCategoryToTop(saved);
//       if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategory updated');
//     } else {
//       if (showSnack)
//         SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//     }
//   }
//
//   Future<void> deleteSubCategory(SubCategory sub,
//       {bool showSnack = false}) async {
//     final id = _s(sub.sId);
//     if (id.isEmpty) return;
//
//     final res = await _subCategoryService.deleteSubCategory(documentId: id);
//     if (res.isSuccess) {
//       _allSubCategories.removeWhere((x) => _s(x.sId) == id);
//       _applySubCategoryFilter();
//       notifyListeners();
//       if (showSnack) SnackBarHelper.showSuccessSnackBar('Subcategory deleted');
//     } else {
//       if (showSnack)
//         SnackBarHelper.showErrorSnackBar(res.requireError().userMessage);
//     }
//   }
//
//   // =========================================================
//   // CATEGORIES (Paging)
//   // =========================================================
//   static const int _categoriesPageSize = 17;
//   bool _categoriesLoading = false;
//   bool _categoriesLoadingMore = false;
//   bool _categoriesHasMore = true;
//   String? _categoriesCursorAfter;
//   String _categoryKeyword = '';
//
//   bool get isCategoriesLoading => _categoriesLoading;
//
//   bool get isCategoriesLoadingMore => _categoriesLoadingMore;
//
//   bool get hasMoreCategories => _categoriesHasMore;
//
//   Future<List<Category>> getAllCategories({bool showSnack = false}) async =>
//       loadInitialCategories(showSnack: showSnack);
//
//   Future<List<Category>> loadInitialCategories({bool showSnack = false}) async {
//     if (_categoriesLoading) return _filteredCategories;
//
//     _categoriesLoading = true;
//     _categoriesLoadingMore = false;
//     _categoriesHasMore = true;
//     _categoriesCursorAfter = null;
//
//     _allCategories.clear();
//     _filteredCategories = const [];
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredCategories;
//
//       final result = await categoriesRepoAppwrite.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _categoriesPageSize,
//         cursorAfter: null,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//         _allCategories.addAll(items);
//
//         _categoriesHasMore = items.length >= _categoriesPageSize;
//         _categoriesCursorAfter =
//         _categoriesHasMore && items.isNotEmpty ? items.last.sId : null;
//
//         _applyCategoryFilter();
//         return _filteredCategories;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(result.requireError().userMessage);
//         return _filteredCategories;
//       }
//     } finally {
//       _categoriesLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<List<Category>> loadMoreCategories({bool showSnack = false}) async {
//     if (_categoriesLoading || _categoriesLoadingMore || !_categoriesHasMore) {
//       return _filteredCategories;
//     }
//
//     _categoriesLoadingMore = true;
//     notifyListeners();
//
//     try {
//       final phone = await UserSaveHelper.getPhoneNumber(showError: false) ?? '';
//       final phoneCode = phone.trim();
//       if (phoneCode.isEmpty) return _filteredCategories;
//
//       final result = await categoriesRepoAppwrite.getPagedByPhoneNumberCode(
//         phoneCode,
//         limit: _categoriesPageSize,
//         cursorAfter: _categoriesCursorAfter,
//       );
//
//       if (result.isSuccess) {
//         final items = result.requireData();
//
//         if (items.isEmpty) {
//           _categoriesHasMore = false;
//           return _filteredCategories;
//         }
//
//         for (final c in items) {
//           final id = _s(c.sId);
//           if (id.isEmpty) continue;
//
//           final idx = _allCategories.indexWhere((x) => _s(x.sId) == id);
//           if (idx == -1)
//             _allCategories.add(c);
//           else
//             _allCategories[idx] = c;
//         }
//
//         _categoriesHasMore = items.length >= _categoriesPageSize;
//         _categoriesCursorAfter = _categoriesHasMore ? items.last.sId : null;
//
//         _applyCategoryFilter();
//         return _filteredCategories;
//       } else {
//         if (showSnack)
//           SnackBarHelper.showErrorSnackBar(result.requireError().userMessage);
//         return _filteredCategories;
//       }
//     } finally {
//       _categoriesLoadingMore = false;
//       notifyListeners();
//     }
//   }
//
//   void filterCategories(String keyword) {
//     _categoryKeyword = keyword.trim();
//     _applyCategoryFilter();
//     notifyListeners();
//   }
//
//   void _applyCategoryFilter() {
//     final kw = _categoryKeyword.trim().toLowerCase();
//     if (kw.isEmpty) {
//       _filteredCategories = List<Category>.from(_allCategories);
//       return;
//     }
//     _filteredCategories = _allCategories
//         .where((c) => (c.name ?? '').toLowerCase().contains(kw))
//         .toList();
//   }
//
//   static const String ORDER_STATUS_PAID = 'Paid';
// }
