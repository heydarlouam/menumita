import 'package:admin/screens/orderpaid/provider/order_provider_paid.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';

import '../core/data/data_provider.dart';
import '../screens/brands/provider/brand_provider.dart';
import '../screens/category/provider/category_provider.dart';
import '../screens/coupon_code/provider/coupon_code_provider.dart';
import '../screens/dashboard/provider/dash_board_provider.dart';
import '../screens/main/provider/main_screen_provider.dart';

import '../screens/order/provider/order_provider.dart';
import '../screens/posters/provider/poster_provider.dart';
import '../screens/sub_category/provider/sub_category_provider.dart';
import '../screens/variants/provider/variant_provider.dart';
import '../screens/variants_type/provider/variant_type_provider.dart';


extension Providers on BuildContext {
  T readOf<T>() => read<T>(); // اگر دوست دارید یک helper هم داشته باشید

  DataProvider get dataProvider => read<DataProvider>();
  MainScreenProvider get mainScreenProvider => read<MainScreenProvider>();
  CategoryProvider get categoryProvider => read<CategoryProvider>();
  SubCategoryProvider get subCategoryProvider => read<SubCategoryProvider>();
  BrandProvider get brandProvider => read<BrandProvider>();
  VariantsTypeProvider get variantTypeProvider => read<VariantsTypeProvider>();
  VariantsProvider get variantProvider => read<VariantsProvider>();
  DashBoardProvider get dashBoardProvider => read<DashBoardProvider>();
  CouponCodeProvider get couponCodeProvider => read<CouponCodeProvider>();
  PosterProvider get posterProvider => read<PosterProvider>();
  OrderProvider get orderProvider => read<OrderProvider>();
  OrderPaidProvider get orderPaidProvider => read<OrderPaidProvider>();
}
