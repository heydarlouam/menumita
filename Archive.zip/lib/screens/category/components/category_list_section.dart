

import 'package:admin/config/environment.dart';
import 'package:admin/utility/User_helper.dart';
import 'package:admin/utility/dialog_helper.dart';
import 'package:admin/utility/extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/data/data_provider.dart';
import '../../../models/category.dart';
import '../../../utility/constants.dart';
import '../../../utility/functions.dart';
import 'add_category_form.dart';

class CategoryListSection extends StatelessWidget {
  const CategoryListSection({Key? key}) : super(key: key);

  String _imgUrl(String? u) {
    if (u == null || u.isEmpty) return '';
    if (u.startsWith('http')) return u;
    if (u.startsWith('/')) return Environment.appwriteEndpoint + u;
    return '${Environment.appwriteEndpoint}/$u';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(defaultPadding),
      decoration: const BoxDecoration(
        color: secondaryColor,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),

      child: LayoutBuilder(
        builder: (_, cons) {
          final w = cons.maxWidth; // عرض واقعی همین کارت
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: ConstrainedBox(
              constraints: BoxConstraints(minWidth: w), // حداقل = عرض کارت
              child: Selector<DataProvider, List<Category>>(
                selector: (_, dp) => dp.categories,
                builder: (context, categories, child) {
                  return DataTable(
                    columnSpacing: defaultPadding,
                    columns: const [
                      DataColumn(label: Text("نام دسته‌بندی")),
                      DataColumn(label: Text("تاریخ افزودن")),
                      DataColumn(label: Text("ویرایش")),
                      DataColumn(label: Text("حذف")),
                    ],
                    rows: List.generate(
                      categories.length,
                          (index) => categoryDataRow(
                        context,
                        categories[index],
                        delete: () {
                          context.categoryProvider.deleteCategory(categories[index]);
                        },
                        edit: () {
                          showAddCategoryForm(
                            context,
                            categories[index],
                            'ویرایش دسته‌بندی',
                          );
                        },
                        buildImageUrl: _imgUrl,
                      ),
                    ),
                  );
                },
              ),
            ),
          );
        },
      ),

    );
  }
}

DataRow categoryDataRow(
    BuildContext context,
    Category catInfo, {
      required String Function(String?) buildImageUrl,
      Function? edit,
      Function? delete,
    }) {
  return DataRow(
    cells: [
      DataCell(
        Row(
          children: [
            Image.network(
              buildImageUrl(catInfo.image),
              height: 30,
              width: 30,
              errorBuilder: (BuildContext context, Object exception, StackTrace? stackTrace) {
                return const Icon(Icons.error);
              },
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return const SizedBox(
                  width: 30,
                  height: 30,
                  child: CircularProgressIndicator(strokeWidth: 2),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
              child: Text(catInfo.name ?? ''),
            ),
          ],
        ),
      ),
      DataCell(Text(formatTimestamp(context, catInfo.createdAt))),
      DataCell(IconButton(

        onPressed: () async {
          if (await UserSaveHelper.isExpired()) {
            DialogHelper.showExpiredDialog(context);
            return;
          }
          edit?.call();
        },

        icon: const Icon(Icons.edit, color: Colors.white),
      )),
      DataCell(IconButton(
        onPressed: () async {
          if (await UserSaveHelper.isExpired()) {
            DialogHelper.showExpiredDialog(context);
            return;
          }
          delete?.call();
        },

        icon: const Icon(Icons.delete, color: Colors.red),
      )),
    ],
  );
}
