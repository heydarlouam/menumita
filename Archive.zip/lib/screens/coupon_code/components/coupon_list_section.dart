import 'package:admin/utility/User_helper.dart';
import 'package:admin/utility/dialog_helper.dart';
import 'package:admin/utility/extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/data/data_provider.dart';
import '../../../models/coupon.dart';
import '../../../utility/color_list.dart';
import '../../../utility/constants.dart';
import 'add_coupon_form.dart';


class CouponListSection extends StatelessWidget {
  const CouponListSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(defaultPadding),
      decoration: const BoxDecoration(
        color: secondaryColor,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: SizedBox(
        width: double.infinity,
        child: Selector<DataProvider, List<Coupon>>(
          selector: (_, dp) => dp.coupons,
          builder: (context, coupons, _) {
            return DataTable(
              columnSpacing: defaultPadding,
              columns: const [
                DataColumn(label: Text("کد کوپن")),
                DataColumn(label: Text("وضعیت")),
                DataColumn(label: Text("نوع تخفیف")),
                DataColumn(label: Text("مقدار تخفیف")),
                DataColumn(label: Text("ویرایش")),
                DataColumn(label: Text("حذف")),
              ],
              rows: List.generate(
                coupons.length,
                    (index) => _couponDataRow(
                  context,
                  coupons[index],
                  index + 1,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  DataRow _couponDataRow(BuildContext context, Coupon coupon, int index) {
    return DataRow(
      cells: [
        DataCell(
          Row(
            children: [
              Container(
                height: 24,
                width: 24,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: colors[index % colors.length],
                  shape: BoxShape.circle,
                ),
                child: Text(
                  '$index',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
              const SizedBox(width: defaultPadding),
              Text(coupon.couponCode ?? ''),
            ],
          ),
        ),
        DataCell(Text(coupon.status ?? '')),
        DataCell(Text(coupon.discountType ?? '')),
        DataCell(Text('${coupon.discountAmount ?? ''}')),
        DataCell(
          IconButton(
            onPressed: () async {
              if (await UserSaveHelper.isExpired()) {
                DialogHelper.showExpiredDialog(context);
                return;
              }
              showAddCouponForm(context, coupon);
            },

            tooltip: 'ویرایش کوپن',

            icon: const Icon(Icons.edit, color: Colors.white),
          ),
        ),
        DataCell(
          IconButton(
            onPressed: () async {
              if (await UserSaveHelper.isExpired()) {
                DialogHelper.showExpiredDialog(context);
                return;
              }
              context.couponCodeProvider.deleteCoupon(coupon);
            },
            tooltip: 'حذف کوپن',

            icon: const Icon(Icons.delete, color: Colors.red),
          ),
        ),
      ],
    );
  }
}

